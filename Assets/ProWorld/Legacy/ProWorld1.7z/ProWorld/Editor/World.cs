﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using UnityEditor;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace ProWorldEditor
{
    /// <summary>
    /// Class that holds all our data
    /// </summary>
    [Serializable]
    public class World : ISerializable, IClean
    {
        //public string Name = string.Empty;
        public uint Version = 2;

        public const float FadeSize = 0.04f;

        #region Data

        public float WaterLevel = 0.1f;
        public GameObject Water;

        // Terrain
        public int SizeOfTerrain = 2000;
        public int HeightOfTerrain = 200;

        // World
        public int WorldHmRes;
        public float[,] WorldHeightMap;
        public MapEditorData Map;

        // Assets
        public List<TextureSplat> Textures = new List<TextureSplat>();
        public List<TreeData> Trees = new List<TreeData>();

        // SectionsWithFade
        private int _numSections = 1;

        public int NumSections
        {
            get { return _numSections; }
            private set { _numSections = value; }
        }

        private int _sectionHmRes = 513;

        public int SectionHmRes
        {
            get { return _sectionHmRes; }
            private set { _sectionHmRes = value; }
        }

        public Section[] Sections;

        #endregion

        #region Constructor

        public World()
        {
            Map = new MapEditorData();
            Map.Nodes = new List<NodeData>();
            Map.Output = null;

            Setup();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Method to setup all data based off Section HeightMap Resolution and the Number of sections
        /// </summary>

        public void Setup()
        {
            UpdateRes();
            SetSections();
            SetWorldHeightmap();
        }

        public void Clean()
        {
            WorldHeightMap = null;
            if (Map != null)
                Map.Clean();
            Map = null;

            if (Textures != null)
            foreach(var t in Textures)
            {
                t.Clean();
            }
            Textures = null;

            if (Trees != null)
            foreach (var t in Trees)
            {
                t.Clean();
            }
            Trees = null;

            if (Sections != null)
            foreach (var s in Sections)
            {
                s.Clean();
            }
            Sections = null;
        }

        public void SetSections()
        {
            var size = NumSections*NumSections;
            Sections = new Section[size];
            for (var index = 0; index < size; index++)
            {
                Sections[index] = new Section(this);
            }
        }

        public void SetWorldHeightmap()
        {
            WorldHeightMap = new float[WorldHmRes,WorldHmRes];
        }

        private void UpdateRes()
        {
            WorldHmRes = SectionHmRes*NumSections;
            Map.Size = WorldHmRes;
        }

        public void SetSections(int sections)
        {
            NumSections = sections;
            UpdateRes();
        }

        public void SetMapResolution(int resolution)
        {
            SectionHmRes = resolution;
            UpdateRes();
        }

        /// <summary>
        /// Method to generate each section Heightmap from the World Height Map
        /// </summary>
        public void UpdateSections()
        {
            var offsetx = 0;
            var offsety = 0;

            // Loop through each section
            for (var t = 0; t < NumSections; t++)
            {
                for (var s = 0; s < NumSections; s++)
                {
                    var index = t*NumSections + s;
                    Sections[index].SectionHeightMap = new float[SectionHmRes,SectionHmRes];

                    var left = NeighbourOnLeft(index);
                    var bottom = NeighbourOnBottom(index);

                    // Loop through each data point
                    for (var j = 0; j < SectionHmRes; j++)
                    {
                        for (var i = 0; i < SectionHmRes; i++)
                        {
                            var stitchX = 0;
                            var stitchY = 0;

                            if (left && i == 0) stitchX = -1;
                            if (bottom && j == 0) stitchY = -1;

                            Sections[index].SectionHeightMap[j, i] = WorldHeightMap[j + offsety + stitchY, i + offsetx + stitchX];
                            Sections[index].SectionSteepness = null;
                        }
                    }

                    //Sections[index].SplitAreas();

                    offsetx += SectionHmRes;
                }
                offsety += SectionHmRes;
                offsetx = 0;
            }
        }
        private bool NeighbourOnLeft(int index)
        {
            return index % NumSections - 1 >= 0;
        }
        private bool NeighbourOnBottom(int index)
        {
            return index - NumSections >= 0;
        }
        public void SplitAreas()
        {
            foreach(var section in Sections)
            {
                section.SplitAreas();
            }
        }

        #endregion

        #region ISerializable

        public World(SerializationInfo info, StreamingContext context)
        {
            //Name = info.GetString("Name");
            Version = info.GetUInt32("Version");

            SizeOfTerrain = info.GetInt32("SizeOfTerrain");
            HeightOfTerrain = info.GetInt32("HeightOfTerrain");

            WaterLevel = (float) info.GetValue("WaterLevel", typeof (float));

            var path = info.GetString("Water");
            try
            {
                Water = (GameObject) AssetDatabase.LoadAssetAtPath(path, typeof (GameObject));
            }
            catch (Exception) // If texture missing just set a blank texture
            {
                Debug.Log("No gameobject found at " + path + "\nSetting null");
                Water = null;
            }

            WorldHmRes = info.GetInt32("WorldHmRes");
            Map = (MapEditorData) info.GetValue("Map", typeof (MapEditorData));
            WorldHeightMap = (float[,]) info.GetValue("WorldHeightMap", typeof (float[,]));

            NumSections = info.GetInt32("NumSections");
            SectionHmRes = info.GetInt32("SectionHmRes");
            Sections = (Section[]) info.GetValue("SectionsWithFade", typeof (Section[]));

            Textures = (List<TextureSplat>) info.GetValue("Textures", typeof (List<TextureSplat>));
            Trees = (List<TreeData>) info.GetValue("Trees", typeof (List<TreeData>));

            UpdateSections();
        }

        public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //info.AddValue("Name", Name);
            info.AddValue("Version", Version);

            info.AddValue("SizeOfTerrain", SizeOfTerrain);
            info.AddValue("HeightOfTerrain", HeightOfTerrain);

            info.AddValue("WaterLevel", WaterLevel);
            info.AddValue("Water", AssetDatabase.GetAssetPath(Water));

            info.AddValue("WorldHmRes", WorldHmRes);
            info.AddValue("Map", Map);
            info.AddValue("WorldHeightMap", WorldHeightMap);

            // SectionsWithFade
            info.AddValue("NumSections", NumSections);
            info.AddValue("SectionHmRes", SectionHmRes);
            info.AddValue("SectionsWithFade", Sections);

            info.AddValue("Textures", Textures);
            info.AddValue("Trees", Trees);

        }

        #endregion
    }

    [Serializable]
    public class Section : ISerializable, IClean
    {
        public int TextureResolution = 512;

        public int Areas = 3;

        public List<TextureEditorData> TextureEditorData = new List<TextureEditorData>();
        public List<TreeSectionData> TreeSection = new List<TreeSectionData>();

        public List<float> Cutoffs = new List<float>();

        [NonSerialized] public float[,] SectionSteepness;
        [NonSerialized] public float[,] SectionHeightMap;
        // Area data
        [NonSerialized] public List<bool[,]> Sections = new List<bool[,]>();
        [NonSerialized] public List<bool[,]> SectionsWithFade = new List<bool[,]>();

        public Section(World world)
        {
            var size = world.SectionHmRes;
            SectionHeightMap = new float[size,size];

            CreateAreas();
        }

        // Generates the various areas within the section
        public void SplitAreas()
        {
            var size = SectionHeightMap.GetLength(0);

            Sections = new List<bool[,]>();
            SectionsWithFade = new List<bool[,]>();

            for (var i = 0; i < Cutoffs.Count; i++)
            {
                //var b = new bool[size, size];
                var nofade = new bool[size,size];
                var fade = new bool[size,size];

                var min = i - 1 >= 0 ? Cutoffs[i - 1] : 0.00f;
                var max = i + 1 < Cutoffs.Count ? Cutoffs[i] : 1.01f;
                var minFade = i - 1 >= 0 ? Cutoffs[i - 1] - World.FadeSize : 0.00f;
                var maxFade = i + 1 < Cutoffs.Count ? Cutoffs[i] + World.FadeSize : 1.01f;

                for (var y = 0; y < size; y++)
                {
                    for (var x = 0; x < size; x++)
                    {
                        var d = SectionHeightMap[y, x];

                        nofade[y, x] = d >= min && d < max;
                        fade[y, x] = d >= minFade && d <= maxFade;
                    }
                }

                Sections.Add(nofade);
                SectionsWithFade.Add(fade);
            }
        }

        public void CreateAreas()
        {
            // TODO REMOVE
            Cutoffs = new List<float>();
            for (var i = 0; i < Areas; i++)
            {
                Cutoffs.Add((i + 1) / (float)Areas);
            }

            SplitAreas();

            //TextureSections = new List<bool[,]>();
            TextureEditorData = new List<TextureEditorData>();
            TreeSection = new List<TreeSectionData>();

            for (var i = 0; i < Cutoffs.Count; i++)
            {
                //var t = Util.ResizeArray(SectionsWithFade[i], TextureResolution);
                TextureEditorData.Add(new TextureEditorData(SectionsWithFade[i], TextureResolution));
                TreeSection.Add(new TreeSectionData());
            }
        }

        public void GenerateSteepness()
        {
            var size = SectionHeightMap.GetLength(0);
            SectionSteepness = new float[size,size];

            var td = new TerrainData();
            td.heightmapResolution = size;
            td.size = new Vector3(ProWorld.World.SizeOfTerrain, ProWorld.World.HeightOfTerrain, ProWorld.World.SizeOfTerrain);
            td.SetHeights(0, 0, SectionHeightMap);

            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    SectionSteepness[y, x] = td.GetSteepness(x/(float) size, y/(float) size);
                }
            }

            UnityEngine.Object.DestroyImmediate(td);
        }

        public void Clean()
        {
            foreach(var ted in TextureEditorData)
            {
                ted.Clean();
            }
            TextureEditorData = null;
            foreach (var ts in TreeSection)
            {
                ts.Clean();
            }
            TreeSection = null;

            Cutoffs = null;
            SectionSteepness = null;
            SectionHeightMap = null;
            Sections = null;
            SectionsWithFade = null;
        }

        #region ISerializable

        public Section(SerializationInfo info, StreamingContext context)
        {
            //Name = info.GetString("Name");
            TextureResolution = info.GetInt32("TextureResolution");
            Areas = info.GetInt32("Areas");
            TextureEditorData = (List<TextureEditorData>) info.GetValue("TextureEditorData", typeof (List<TextureEditorData>));
            TreeSection = (List<TreeSectionData>)info.GetValue("TreeSection", typeof(List<TreeSectionData>));
            Cutoffs = (List<float>)info.GetValue("Cutoffs", typeof(List<float>));

            SplitAreas();
        }

        public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("TextureResolution", TextureResolution);
            info.AddValue("Areas", Areas);
            info.AddValue("TextureEditorData", TextureEditorData);
            info.AddValue("TreeSection", TreeSection);
            info.AddValue("Cutoffs", Cutoffs);
        }

        #endregion
    }
}