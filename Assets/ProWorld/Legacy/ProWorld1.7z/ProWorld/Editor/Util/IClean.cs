﻿namespace ProWorldEditor
{
	interface IClean
	{
	    void Clean();
	}
}
