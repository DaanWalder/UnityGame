﻿
public static class WindowID
{
    public static int ID = 1;
}