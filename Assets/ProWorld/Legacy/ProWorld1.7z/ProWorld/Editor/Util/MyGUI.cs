﻿using System;
using UnityEngine;


    public static class MyGUI
    {
        public static float LogSlider(float value, float min, float max, params GUILayoutOption[] option)
        {
            var power = Mathf.Log10(value);
            power = GUILayout.HorizontalSlider(power, min, max, option);
            return Mathf.Pow(10, power);
        }

        public static int RoundSlider(int index, int min, int max, params GUILayoutOption[] options)
        {
            var mode = GUILayout.HorizontalSlider(index, min, max, options);
            return Mathf.RoundToInt(mode);

        }

        public static int EnumSlider(int index, int max, params GUILayoutOption[] options)
        {
            var mode = GUILayout.HorizontalSlider(index, 0, max, options);
            return Mathf.RoundToInt(mode);

        }

        public static int EnumButton(int e, string[] names, int width)
        {
            var output = e;
            var bwidth = width/names.Length;

            GUILayout.BeginHorizontal();
            for (var i = 0; i < names.Length; i++)
            {
                GUI.color = i == e ? Color.red : Color.white;

                if (GUILayout.Button("", GUILayout.Width(bwidth)))
                {
                    output = i;
                }
            }
            GUILayout.EndHorizontal();

            GUI.color = Color.white;

            return output;
        }

        public static bool HorizontalSliderC(float value, float leftValue, float rightValue, out float result,
                                             params GUILayoutOption[] options)
        {
            result = GUILayout.HorizontalSlider(value, leftValue, rightValue, options);

            return Math.Abs(result - value) > float.Epsilon;
        }

        public static bool HorizontalSliderC(int value, int leftValue, int rightValue, out int result,
                                             params GUILayoutOption[] options)
        {
            result = (int) GUILayout.HorizontalSlider(value, leftValue, rightValue, options);

            return result != value;
        }
    }