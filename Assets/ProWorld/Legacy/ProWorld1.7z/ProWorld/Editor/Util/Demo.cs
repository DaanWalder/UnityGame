﻿using System;
using UnityEngine;
using Random = UnityEngine.Random;

namespace ProWorldEditor
{
    public static class Demo
    {
        public static MapEditorData Island(int size)
        {
            Random.seed = Environment.TickCount;

            var med = new MapEditorData
                          {
                              Size = size,
                              Dirty = true,
                              Output = new NodeData(typeof (OutputNode))
                                           {
                                               InputConnections = new OutputLink[1],
                                               Inputs = new float[1][,],
                                               WindowRect = new Rect(645, 100, 75, 107)
                                           }
                          };

            var seed = Random.Range(0, 100);

            var fbm1 = new FractalBrownianMotionData(typeof (FractalBrownianMotionNode))
                           {
                               InputConnections = new OutputLink[0],
                               Inputs = new float[0][,],
                               WindowRect = new Rect(15, 60, 75, 126),
                               Seed = seed,
                               Range = Util.RandomVar(6.06f),
                           };
            fbm1.fBm.H = Util.RandomVar(2);
            fbm1.fBm.Gain = Util.RandomVar(0.5f);
            fbm1.fBm.Lacunarity = Util.RandomVar(2.0f);
            fbm1.fBm.SetSeed(seed);
            med.Nodes.Add(fbm1);

            var circle = new CircleData(typeof (CircleNode))
                             {
                                 InputConnections = new OutputLink[0],
                                 Inputs = new float[0][,],
                                 WindowRect = new Rect(15, 200, 75, 126),
                                 Size = Util.Vec2RandomVar(new Vector2(0.5f, 0.5f))
                             };
            med.Nodes.Add(circle);

            seed = Random.Range(0, 100);
            var fbm2 = new FractalBrownianMotionData(typeof (FractalBrownianMotionNode))
                           {
                               InputConnections = new OutputLink[0],
                               Inputs = new float[0][,],
                               WindowRect = new Rect(120, 10, 75, 126),
                               Seed = seed,
                               Range = Util.RandomVar(1),
                               Morph = FractalBrownianMotionNode.OutputMorph.Clamp
                           };
            fbm2.fBm.H = Util.RandomVar(2);
            fbm2.fBm.Gain = Util.RandomVar(0.5f);
            fbm2.fBm.Lacunarity = Util.RandomVar(2.0f);
            fbm2.fBm.SetSeed(seed);
            med.Nodes.Add(fbm2);

            var mul1 = new NodeData(typeof (Mul))
                           {
                               InputConnections = new OutputLink[2],
                               Inputs = new float[2][,],
                               WindowRect = new Rect(120, 150, 75, 144)
                           };
            med.Nodes.Add(mul1);

            var mul2 = new NodeData(typeof (Mul))
                           {
                               InputConnections = new OutputLink[2],
                               Inputs = new float[2][,],
                               WindowRect = new Rect(225, 100, 75, 144)
                           };
            med.Nodes.Add(mul2);

            var stretch = new StretchData(typeof (StretchNode))
                              {
                                  InputConnections = new OutputLink[1],
                                  Inputs = new float[1][,],
                                  WindowRect = new Rect(330, 100, 75, 126)
                              };
            med.Nodes.Add(stretch);

            var mul3 = new NodeData(typeof (Mul))
                           {
                               InputConnections = new OutputLink[2],
                               Inputs = new float[2][,],
                               WindowRect = new Rect(435, 100, 75, 144)
                           };
            med.Nodes.Add(mul3);

            var smooth = new SmoothData(typeof (SmoothNode))
                             {
                                 InputConnections = new OutputLink[1],
                                 Inputs = new float[1][,],
                                 WindowRect = new Rect(540, 100, 75, 126),
                                 Radius = 1
                             };
            med.Nodes.Add(smooth);

            var link1 = new OutputLink(mul1, 0, fbm1);
            fbm1.OutputConnections.Add(link1);
            mul1.InputConnections[0] = link1;

            var link2 = new OutputLink(mul1, 1, circle);
            circle.OutputConnections.Add(link2);
            mul1.InputConnections[1] = link2;

            var link3 = new OutputLink(mul2, 0, fbm2);
            fbm2.OutputConnections.Add(link3);
            mul2.InputConnections[0] = link3;

            var link4 = new OutputLink(mul2, 1, mul1);
            mul1.OutputConnections.Add(link4);
            mul2.InputConnections[1] = link4;

            var link5 = new OutputLink(stretch, 0, mul2);
            mul2.OutputConnections.Add(link5);
            stretch.InputConnections[0] = link5;

            var link6 = new OutputLink(mul3, 0, stretch);
            stretch.OutputConnections.Add(link6);
            mul3.InputConnections[0] = link6;

            var link7 = new OutputLink(mul3, 1, stretch);
            stretch.OutputConnections.Add(link7);
            mul3.InputConnections[1] = link7;

            var link8 = new OutputLink(smooth, 0, mul3);
            mul3.OutputConnections.Add(link8);
            smooth.InputConnections[0] = link8;

            var link9 = new OutputLink(med.Output, 0, smooth);
            smooth.OutputConnections.Add(link9);
            med.Output.InputConnections[0] = link9;

            return med;
        }
        public static MapEditorData Island2(int size)
        {
            Random.seed = Environment.TickCount;

            var med = new MapEditorData
            {
                Size = size,
                Dirty = true,
                Output = new NodeData(typeof(OutputNode))
                {
                    InputConnections = new OutputLink[1],
                    Inputs = new float[1][,],
                    WindowRect = new Rect(435, 150, 75, 107)
                }
            };

            var seed = Random.Range(0, 100);

            var fbm = new FractalBrownianMotionData(typeof (FractalBrownianMotionNode))
                          {
                              InputConnections = new OutputLink[0],
                              Inputs = new float[0][,],
                              WindowRect = new Rect(15, 60, 75, 126),
                              Seed = seed,
                              Range = Util.RandomVar(1f),
                              Morph = FractalBrownianMotionNode.OutputMorph.Abs,
                              fBm =
                                  {
                                      H = Util.RandomVar(2),
                                      Gain = Util.RandomVar(0.5f),
                                      Lacunarity = Util.RandomVar(2.0f)
                                  }
                          };
            fbm.fBm.SetSeed(seed);
            med.Nodes.Add(fbm);

            var circle = new CircleData(typeof(CircleNode))
            {
                InputConnections = new OutputLink[0],
                Inputs = new float[0][,],
                WindowRect = new Rect(15, 200, 75, 126),
                Size = Util.Vec2RandomVar(new Vector2(0.5f, 0.5f))
            };
            med.Nodes.Add(circle);

            var mul = new NodeData(typeof(Mul))
            {
                InputConnections = new OutputLink[2],
                Inputs = new float[2][,],
                WindowRect = new Rect(120, 150, 75, 144)
            };
            med.Nodes.Add(mul);

            var stretch = new StretchData(typeof(StretchNode))
            {
                InputConnections = new OutputLink[1],
                Inputs = new float[1][,],
                WindowRect = new Rect(225, 150, 75, 126)
            };
            med.Nodes.Add(stretch);

            var smooth = new SmoothData(typeof(SmoothNode))
            {
                InputConnections = new OutputLink[1],
                Inputs = new float[1][,],
                WindowRect = new Rect(330, 150, 75, 126),
                Radius = Random.Range(3,6)
            };
            med.Nodes.Add(smooth);

            var link1 = new OutputLink(mul, 0, fbm);
            fbm.OutputConnections.Add(link1);
            mul.InputConnections[0] = link1;

            var link2 = new OutputLink(mul, 1, circle);
            circle.OutputConnections.Add(link2);
            mul.InputConnections[1] = link2;

            var link3 = new OutputLink(stretch, 0, mul);
            mul.OutputConnections.Add(link3);
            stretch.InputConnections[0] = link3;

            var link4 = new OutputLink(smooth, 0, stretch);
            stretch.OutputConnections.Add(link3);
            smooth.InputConnections[0] = link4;

            var link5 = new OutputLink(med.Output, 0, smooth);
            smooth.OutputConnections.Add(link5);
            med.Output.InputConnections[0] = link5;

            return med;
        }
        public static MapEditorData River(int size)
        {
            Random.seed = Environment.TickCount;

            var med = new MapEditorData
            {
                Size = size,
                Dirty = true,
                Output = new NodeData(typeof(OutputNode))
                {
                    InputConnections = new OutputLink[1],
                    Inputs = new float[1][,],
                    WindowRect = new Rect(225, 60, 75, 107)
                }
            };

            var seed = Random.Range(0, 100);

            var fbm = new FractalBrownianMotionData(typeof (FractalBrownianMotionNode))
                          {
                              InputConnections = new OutputLink[0],
                              Inputs = new float[0][,],
                              WindowRect = new Rect(15, 60, 75, 126),
                              Seed = seed,
                              Range = Util.RandomVar(1f),
                              Morph = FractalBrownianMotionNode.OutputMorph.Abs,
                              fBm = {Lacunarity = Util.RandomVar(1.8f, 0.1f)}
                          };
            fbm.fBm.H = Util.RandomVar(2);
            fbm.fBm.Gain = Util.RandomVar(0.5f, 0.1f);
            fbm.fBm.SetSeed(seed);
            med.Nodes.Add(fbm);

            var stretch = new StretchData(typeof(StretchNode))
            {
                InputConnections = new OutputLink[1],
                Inputs = new float[1][,],
                WindowRect = new Rect(120, 60, 75, 126)
            };
            med.Nodes.Add(stretch);

            var link1 = new OutputLink(stretch, 0, fbm);
            fbm.OutputConnections.Add(link1);
            stretch.InputConnections[0] = link1;

            var link2 = new OutputLink(med.Output, 0, stretch);
            stretch.OutputConnections.Add(link2);
            med.Output.InputConnections[0] = link2;

            return med;
        }
        public static MapEditorData RollingHills(int size)
        {
            Random.seed = Environment.TickCount;

            var med = new MapEditorData
            {
                Size = size,
                Dirty = true,
                Output = new NodeData(typeof(OutputNode))
                {
                    InputConnections = new OutputLink[1],
                    Inputs = new float[1][,],
                    WindowRect = new Rect(435, 150, 75, 107)
                }
            };

            var seed = Random.Range(0, 100);

            var fbm = new FractalBrownianMotionData(typeof(FractalBrownianMotionNode))
            {
                InputConnections = new OutputLink[0],
                Inputs = new float[0][,],
                WindowRect = new Rect(15, 60, 75, 126),
                Seed = seed,
                Range = Util.RandomVar(1f),
                Morph = FractalBrownianMotionNode.OutputMorph.Abs,
                fBm =
                {
                    H = Util.RandomVar(2),
                    Gain = Util.RandomVar(0.5f),
                    Lacunarity = Util.RandomVar(2.0f)
                }
            };
            fbm.fBm.SetSeed(seed);
            med.Nodes.Add(fbm);

            seed = Random.Range(0, 100);
            var simplex = new SimplexData(typeof(SimplexNode))
            {
                InputConnections = new OutputLink[0],
                Inputs = new float[0][,],
                WindowRect = new Rect(15, 200, 75, 126),
                Range = Util.RandomVar(2.5f),
                Seed = seed
            };
            simplex.Noise.SetSeed(seed);
            med.Nodes.Add(simplex);

            var add = new AddData(typeof(Add))
            {
                InputConnections = new OutputLink[2],
                Inputs = new float[2][,],
                WindowRect = new Rect(120, 150, 75, 144)
            };
            med.Nodes.Add(add);

            var stretch = new StretchData(typeof(StretchNode))
            {
                InputConnections = new OutputLink[1],
                Inputs = new float[1][,],
                WindowRect = new Rect(225, 150, 75, 126)
            };
            med.Nodes.Add(stretch);

            var smooth = new SmoothData(typeof(SmoothNode))
            {
                InputConnections = new OutputLink[1],
                Inputs = new float[1][,],
                WindowRect = new Rect(330, 150, 75, 126),
                Radius = Random.Range(3, 6)
            };
            med.Nodes.Add(smooth);

            var link1 = new OutputLink(add, 0, fbm);
            fbm.OutputConnections.Add(link1);
            add.InputConnections[0] = link1;

            var link2 = new OutputLink(add, 1, simplex);
            simplex.OutputConnections.Add(link2);
            add.InputConnections[1] = link2;

            var link3 = new OutputLink(stretch, 0, add);
            add.OutputConnections.Add(link3);
            stretch.InputConnections[0] = link3;

            var link4 = new OutputLink(smooth, 0, stretch);
            stretch.OutputConnections.Add(link3);
            smooth.InputConnections[0] = link4;

            var link5 = new OutputLink(med.Output, 0, smooth);
            smooth.OutputConnections.Add(link5);
            med.Output.InputConnections[0] = link5;

            return med;
        }
    }
}