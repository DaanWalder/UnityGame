﻿using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using Ionic.Zip;
using UnityEngine;

namespace ProWorldEditor
{
    internal class FileOperations
    {
        public static void SaveToFile(string path)
        {
            using (var zipFile = new ZipFile())
            {
                zipFile.AlternateEncoding = Encoding.Unicode;

                //serialize item to memorystream
                using (var m = new MemoryStream())
                {
                    var formatter = new BinaryFormatter();
                    formatter.Serialize(m, ProWorld.World);
                    m.Position = 0;

                    var zipEntry = zipFile.AddEntry("entry", m);

                    zipEntry.AlternateEncoding = Encoding.Unicode;

                    zipFile.Save(path);
                }
            }
        }
        public static World LoadFromFile(string path)
        {
            using (var m = new MemoryStream())
            {
                using (var zipFile = new ZipFile(path))
                {
                    zipFile.AlternateEncoding = Encoding.Unicode;

                    // If no file found, just create a new grid
                    if (zipFile["entry"] == null) return new World();

                    ZipEntry e = zipFile["entry"];
                    e.AlternateEncoding = Encoding.Unicode;
                    //e.Password = _password;
                    e.Extract(m);
                    m.Position = 0;

                    //now serialize it back to the correct type
                    IFormatter formatter = new BinaryFormatter();
                    var world = (World) formatter.Deserialize(m);

                    HandleVersionChanges(world);

                    return world;
                }
            }

        }
        public static void SaveTemp()
        {
            if (Application.persistentDataPath == string.Empty)
            {
                Debug.Log("Application.persistentDataPath is empty.");
                return;
            }

            //var path = Application.dataPath + "/temp.pw";
            var path = Application.persistentDataPath + "/temp.pw";
            SaveToFile(path);
        }
        public static World LoadTemp()
        {
            if (Application.persistentDataPath == string.Empty)
            {
                Debug.Log("Application.persistentDataPath is empty.");
                return new World();
            }

            //var path = Application.dataPath + "/temp.pw";
            var path = Application.persistentDataPath + "/temp.pw";
            if (!File.Exists(path))
                return new World();

            var f = LoadFromFile(path);
            return f;
        }

        private static void HandleVersionChanges(World w)
        {
            if (w.Version == 1)
            {
                // Fix too many output connections
                foreach(var n in w.Map.Nodes)
                {
                    n.OutputConnections = new List<OutputLink>();
                }
                foreach (var n in w.Map.Nodes)
                {
                    foreach (var i in n.InputConnections)
                    {
                        i.OutputNode.OutputConnections.Add(i);
                    }
                }

                var ic = w.Map.Output.InputConnections[0];
                if (ic != null)
                {
                    ic.OutputNode.OutputConnections.Add(ic);
                }
            }
        }

        public static void SaveImage(float[,] data, string path)
        {
            var height = data.GetLength(0);
            var width = data.GetLength(1);

            var texture = new Texture2D(width, height);
            Util.ApplyMapToTexture(ref texture, data);

            var bytes = texture.EncodeToPNG();
            var file = File.Open(path, FileMode.Create);
            var binary = new BinaryWriter(file);
            binary.Write(bytes);
            file.Close();

            Object.DestroyImmediate(texture);
        }
        public static void SaveImage(Color[,] data, string path)
        {
            var height = data.GetLength(0);
            var width = data.GetLength(1);

            var texture = new Texture2D(width, height);

            var d = new Color[height*width];

            for (var y = 0; y < height; y++ )
            {
                for (var x = 0; y < height; x++)
                {
                    d[y*width + x] = data[y, x];
                }
            }

            texture.SetPixels(d);
            texture.Apply();

            var bytes = texture.EncodeToPNG();
            var file = File.Open(path, FileMode.Create);
            var binary = new BinaryWriter(file);
            binary.Write(bytes);
            file.Close();

            Object.DestroyImmediate(texture);
        }
    }
}