﻿using System;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public class SerializableRect
    {
        public float Left;
        public float Right;
        public float Width;
        public float Height;

        public SerializableRect(Rect rect)
        {
            Left = rect.x;
            Right = rect.y;
            Width = rect.width;
            Height = rect.height;
        }

        public Rect ToRect()
        {
            return new Rect(Left, Right, Width, Height);
        }
    }

    [Serializable]
    public class SerializableVector3
    {
        public float X;
        public float Y;
        public float Z;

        public SerializableVector3(Vector3 vec3)
        {
            X = vec3.x;
            Y = vec3.y;
            Z = vec3.z;
        }

        public Vector3 ToVector3()
        {
            return new Vector3(X, Y, Z);
        }
    }

    [Serializable]
    public class SerializableVector2
    {
        public float X;
        public float Y;

        public SerializableVector2(Vector2 vec2)
        {
            X = vec2.x;
            Y = vec2.y;
        }

        public SerializableVector2(int x, int y)
        {
            X = x;
            Y = y;
        }

        public Vector2 ToVector2()
        {
            return new Vector2(X, Y);
        }
    }
}