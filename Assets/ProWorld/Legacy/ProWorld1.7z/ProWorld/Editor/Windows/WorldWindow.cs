﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using UnityEngine;

namespace ProWorldEditor
{
    public sealed class WorldWindow : IWindowLayout
    {
        private Texture2D _outputTexture; // left heightmap texture
        private Texture2D[] _sectionTextures; // right watermap section textures
        //private int _currentSection;
        //private float[][,] _sectionData;

        private bool _waterUpdate;

        private int _sections = ProWorld.World.NumSections;
        private int _sectionHeightmap = ProWorld.World.SectionHmRes;
        private int _size = ProWorld.World.SizeOfTerrain;
        private int _height = ProWorld.World.HeightOfTerrain;

        private MapEditor _me;
        private bool _rebuild;

        private bool _showPremade;

        public WorldWindow()
        {
            _sections = ProWorld.World.NumSections;
            _sectionHeightmap = ProWorld.World.SectionHmRes;

            _outputTexture = new Texture2D(512, 512);

            Refresh();
        }

        public override void OnGUI()
        {
            if (_rebuild)
            {
                GUI.enabled = false;

                if (_me.CheckUpdating())
                {
                    _rebuild = false;
                    _me = null;

                    UpdateOutput(ProWorld.World.Map.Output.Output);
                    Refresh();
                }
            }
            else
            {
                GUI.enabled = true;
            }

            var extra = (ProWorld.World.NumSections - 1)*2;

            GUILayout.BeginArea(new Rect(0, 0, 523, 536 + extra), "HeightMap", GUI.skin.window);

            if (GUILayout.Button(_outputTexture, GUIStyle.none, GUILayout.Width(512), GUILayout.Height(512)))
            {
                ProWorld.World.Map.Update = UpdateOutput;
                ProWorld.Windows.Add(new MapEditor(ProWorld.World.Map, ProWorld.Window, ProWorld.BarHeight));
            }
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(523, 0, 523 + extra, 536 + extra), "World", GUI.skin.window);

            var style = new GUIStyle(GUIStyle.none);
            style.margin = new RectOffset(2, 2, 2, 2);

            for (var j = 0; j < ProWorld.World.NumSections; j++)
            {
                GUILayout.BeginHorizontal();
                for (var i = 0; i < ProWorld.World.NumSections; i++)
                {
                    // Because texture starts at bottom left corner we have to flip y

                    if (
                        GUILayout.Button(
                            _sectionTextures[(ProWorld.World.NumSections - j - 1)*ProWorld.World.NumSections + i], style,
                            GUILayout.Width(512/(float) ProWorld.World.NumSections),
                            GUILayout.Height(512/(float) ProWorld.World.NumSections)))
                    {
                        ProWorld.CurrentSection = (ProWorld.World.NumSections - j - 1)*ProWorld.World.NumSections + i;
                        ProWorld.NewWindow(new SectionWindow(ProWorld.World.Sections[ProWorld.CurrentSection]));
                    }
                }
                GUILayout.EndHorizontal();
            }
            GUILayout.EndArea();

            GUILayout.BeginArea(
                new Rect(ProWorld.Window.position.width - 200, 0, 200, ProWorld.Window.position.height/2f+100), "Setup",
                GUI.skin.window);
            Setup();
            GUILayout.EndArea();

            GUILayout.BeginArea(
                new Rect(ProWorld.Window.position.width - 200, ProWorld.Window.position.height/2f+100, 200,
                         ProWorld.Window.position.height/2f-120), "Settings", GUI.skin.window);
            Setting();
            GUILayout.EndArea();
        }

        private void Setup()
        {
            GUILayout.Label("Sections");
            GUILayout.BeginHorizontal();
            _sections = MyGUI.RoundSlider(_sections, 1, 5);
            GUILayout.Label(_sections.ToString(CultureInfo.InvariantCulture), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            GUILayout.Label("Warning: removes section data");
            if (GUILayout.Button("Update"))
            {
                ProWorld.World.SetSections(_sections);

                ProWorld.World.Setup();

                ProWorld.World.Map.Dirty = true;

                _me = new MapEditor(ProWorld.World.Map, null);

                _rebuild = true;

                Refresh();
            }

            GUILayout.Space(20);

            GUILayout.Label("Height Map Resolution");
            GUILayout.BeginHorizontal();
            var s = _sectionHeightmap - 1;
            var bits = 0;
            while (s > 1) // much more efficient than log10 / log2 
            {
                bits++;
                s >>= 1;
            }
            bits = MyGUI.RoundSlider(bits, 6, 12);
            _sectionHeightmap = (int) Mathf.Pow(2, bits) + 1;

            GUILayout.Label(_sectionHeightmap.ToString(CultureInfo.InvariantCulture), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            if (GUILayout.Button("Update"))
            {
                ProWorld.World.SetMapResolution(_sectionHeightmap);
                ProWorld.World.SetWorldHeightmap();

                ProWorld.World.Map.Dirty = true;

                _me = new MapEditor(ProWorld.World.Map, null);

                _rebuild = true;
            }

            GUILayout.Space(20);

            GUILayout.Label("Size of terrain");
            GUILayout.BeginHorizontal();
            var before = _size;
            _size = Mathf.RoundToInt(MyGUI.LogSlider(_size, 2, 4));
            if (_size != before)
                _size = RoundToLog(_size);

            var size = GUILayout.TextField(_size.ToString(CultureInfo.InvariantCulture), 5, GUILayout.Width(50));
            size = Regex.Replace(size, "^[^0-9]", "");
            int.TryParse(size, out _size);

            //GUILayout.Label(_size.ToString(CultureInfo.InvariantCulture), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            GUILayout.Label("Height of terrain");
            GUILayout.BeginHorizontal();
            var heightBefore = _height;
            _height = Mathf.RoundToInt(MyGUI.LogSlider(_height, 1, 3));
            if (_height != heightBefore)
                _height = RoundToLog(_height);

            var height = GUILayout.TextField(_height.ToString(CultureInfo.InvariantCulture), 4, GUILayout.Width(50));
            height = Regex.Replace(height, "^[^0-9]", "");
            int.TryParse(height, out _height);

            //GUILayout.Label(_height.ToString(CultureInfo.InvariantCulture), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            if (GUILayout.Button("Update"))
            {
                // Set all trees to dirty so that they'll be recalculated later.
                // No need to calculate right now as it'll be handled automatically
                if (ProWorld.World.SizeOfTerrain != _size)
                {
                    ProWorld.World.SizeOfTerrain = _size;
                    foreach (var section in ProWorld.World.Sections)
                    {
                        foreach(var tree in section.TreeSection)
                        {
                            tree.ColorOutput = null;
                            tree.IsDirty = true;
                        }

                        
                    }
                }

                if (ProWorld.World.HeightOfTerrain != _height)
                {
                    ProWorld.World.HeightOfTerrain = _height;

                    foreach(var section in ProWorld.World.Sections)
                    {
                        section.SectionSteepness = null;
                        section.GenerateSteepness();
                        for (int index = 0; index < section.TextureEditorData.Count; index++)
                        {
                            var t = section.TextureEditorData[index];
                            TextureEditor.GenerateCliffs(t, section);
                            var map = Util.ResizeArray(section.SectionsWithFade[index], section.TextureResolution);
                            //var map = Util.ResizeArray(section.Sections[index], section.TextureResolution);
                            TextureEditor.UpdateSections(section.TextureResolution, t, map);
                        }
                    }
                }               
            }

            GUILayout.Space(20);
            GUILayout.Label("World Heightmap: " + _sectionHeightmap * _sections);
            GUILayout.Label("Total World Size: " + _size * _sections);
            GUILayout.Space(10);
            GUILayout.Label("Current");
            GUILayout.Label("SectionsWithFade: " + ProWorld.World.NumSections);
            GUILayout.Label("Height Map Resolution: " + ProWorld.World.SectionHmRes);
            GUILayout.Label("Terrain Size: " + ProWorld.World.SizeOfTerrain);
            
        }

        private int RoundToLog(int val)
        {
            var pow = (int)Mathf.Log10(val)-1;
            var closest = Mathf.Pow(10, pow);

            return ((int)Mathf.Round(val / closest)) * (int)closest;
        }

        private void Setting()
        {
            if (_waterUpdate)
            {
                if (Event.current.type == EventType.mouseUp || Event.current.type == EventType.Ignore)
                {
                    GenerateSectionTextures();
                    _waterUpdate = false;
                }
            }

            GUILayout.Label("Sea Level");
            GUILayout.BeginHorizontal();
            var before = ProWorld.World.WaterLevel;
            ProWorld.World.WaterLevel = GUILayout.VerticalSlider(ProWorld.World.WaterLevel, 1, 0, GUILayout.Height(100));
            GUILayout.Label(ProWorld.World.WaterLevel.ToString("0.00"));

            if (Event.current.type == EventType.used && (Math.Abs(before - ProWorld.World.WaterLevel) > float.Epsilon))
            {
                _waterUpdate = true;
            }
            GUILayout.EndHorizontal();

            GUILayout.FlexibleSpace();

            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            //GUILayout.Label("Premade Terrains");
            _showPremade = GUILayout.Toggle(_showPremade, "Random Terrains");
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            GUI.enabled = _showPremade;

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Island", UnityEditor.EditorStyles.miniButtonLeft))
            {
                ProWorld.World.WaterLevel = 0.10f;
                ProWorld.World.Map = Demo.Island(ProWorld.World.WorldHmRes);
                _rebuild = true;
                _me = new MapEditor(ProWorld.World.Map, null);
            }
            if (GUILayout.Button("Island2", UnityEditor.EditorStyles.miniButtonMid))
            {
                ProWorld.World.WaterLevel = 0.10f;
                ProWorld.World.Map = Demo.Island2(ProWorld.World.WorldHmRes);
                _rebuild = true;
                _me = new MapEditor(ProWorld.World.Map, null);
            }
            if (GUILayout.Button("River", UnityEditor.EditorStyles.miniButtonMid))
            {
                ProWorld.World.WaterLevel = 0.05f;
                ProWorld.World.Map = Demo.River(ProWorld.World.WorldHmRes);
                _rebuild = true;
                _me = new MapEditor(ProWorld.World.Map, null);
            }
            if (GUILayout.Button("Hills", UnityEditor.EditorStyles.miniButtonRight))
            {
                ProWorld.World.WaterLevel = 0.10f;
                ProWorld.World.Map = Demo.RollingHills(ProWorld.World.WorldHmRes);
                _rebuild = true;
                _me = new MapEditor(ProWorld.World.Map, null);
            } 
            GUILayout.EndHorizontal();

            GUI.enabled = !_showPremade;
        }

        // Fed from map
        private void UpdateOutput(float[,] data)
        {
            var w = ProWorld.World;

            w.WorldHeightMap = data;
            // Generate main texture
            w.UpdateSections();
            w.SplitAreas();
        }

        private void UpdateHeightmapPreview()
        {
            var d = Util.ResizeArray(ProWorld.World.WorldHeightMap, 512);
            Util.ApplyMapToTexture(ref _outputTexture, d);
        }

        private void GenerateSectionTextures()
        {
            // Remove old textures
            if (_sectionTextures != null)
            {
                for (var i = 0; i < _sectionTextures.Length; i++)
                {
                    UnityEngine.Object.DestroyImmediate(_sectionTextures[i]);
                    _sectionTextures[i] = null;
                }
            }

            _sectionTextures = new Texture2D[ProWorld.World.NumSections*ProWorld.World.NumSections];
            var w = ProWorld.World;
            // Generate section textures
            for (var t = 0; t < w.NumSections; t++)
            {
                for (var s = 0; s < w.NumSections; s++)
                {
                    var index = t*w.NumSections + s;
                    // Create section texture
                    var sectionSize = (int) (512/(float) w.NumSections);
                    _sectionTextures[index] = new Texture2D(sectionSize, sectionSize);
                    var sd = Util.ResizeArray(w.Sections[index].SectionHeightMap, sectionSize);
                    Util.ApplyWaterToTexture(_sectionTextures[index], sd);
                }
            }
        }

        public override void Refresh()
        {
            UpdateHeightmapPreview();
            GenerateSectionTextures();
        }

        public override void Clean()
        {
            UnityEngine.Object.DestroyImmediate(_outputTexture);

            if (_sectionTextures != null)
            {
                for (var i = 0; i < _sectionTextures.Length; i++)
                {
                    UnityEngine.Object.DestroyImmediate(_sectionTextures[i]);
                }
            }
        }
    }
}