﻿using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace ProWorldEditor
{
    public sealed class SectionWindow : IWindowLayout
    {
        private readonly Section _section;
        private float[,] _resizedData;
        private Texture2D _outputTexture;
        private Texture2D _worldTexture;
        private readonly Texture2D _slide = new Texture2D(20, 180);

        private Vector2 _textureScroll;

        private int _areas;
        private int _resolution;
        private bool _update;
        private bool _updateAreas;
        private bool _updateResolution;

        private bool _switch;

        private bool _rebuildResolution;
        private MapEditor _me;
        private List<MapEditorData> _med = new List<MapEditorData>();

        public SectionWindow(Section section)
        {
            _section = section;
            _areas = _section.Areas;
            _resolution = _section.TextureResolution;

            _worldTexture = new Texture2D(512, 512);
            _outputTexture = new Texture2D(512, 512);

            Refresh();
        }

        private Color[] Colors()
        {
            var cutoffs = _section.Cutoffs;

            var colors = new Color[180*20];
            var last = 0;

            for (var y = 0; y < 180; y++)
            {
                var data = y/180f;

                for (var i = 0; i < cutoffs.Count; i++)
                {
                    if (data < cutoffs[i])
                    {
                        var d = i/(float) cutoffs.Count;

                        var r = Mathf.Abs(1 - 2*d);
                        var g = (Mathf.Abs(0.5f - d) + 0.5f);
                        var b = Mathf.Clamp01(2*d - 1);

                        if (data <= ProWorld.World.WaterLevel)
                        {
                            r = (1 - r);
                            g = (1 - g);
                            b = 1;
                        }

                        for (var x = 0; x < 20; x++)
                        {
                            // Add a black line between
                            colors[y*20 + x] = i != last ? Color.black : new Color(r, g, b);
                        }

                        last = i;
                        break;
                    }
                }
            }
            return colors;
        }

        private void Rebuild()
        {
            if (!_rebuildResolution) return;

            if (_me == null)
            {
                _me = new MapEditor(_med[0], null);
            }

            if (_me.CheckUpdating())
            {
                //_rebuild = false;
                _me = null;
                _med.RemoveAt(0);

                if (_med.Count == 0)
                {
                    _rebuildResolution = false;

                    for (var index = 0; index < _section.TextureEditorData.Count; index++)
                    {
                        var t = _section.TextureEditorData[index];
                        var map = Util.ResizeArray(_section.SectionsWithFade[index], _section.TextureResolution);

                        TextureEditor.UpdateSections(_section.TextureResolution, t, map);
                    }
                }

                //UpdateOutput(ProWorld.World.Map.Output.Output);
                //Refresh();
            }
        }

        public override void OnGUI()
        {
            Rebuild();

            var position = ProWorld.Window.position;

            var style = new GUIStyle(GUIStyle.none) {stretchHeight = true, stretchWidth = true};

            GUILayout.BeginArea(new Rect(0, 0, 523, 536), "World", GUI.skin.window);
            GUILayout.Box(_worldTexture, style, GUILayout.Width(512), GUILayout.Height(512));
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(523, 0, 523, 536), "Areas", GUI.skin.window);

            var colorButton = new GUIContent(_outputTexture);
            var rect = GUILayoutUtility.GetRect(colorButton, style, GUILayout.Width(512), GUILayout.Height(512));

            if (GUI.Button(rect, colorButton, style))
            {
                var pickpos = Event.current.mousePosition;
                var x = Convert.ToInt32(pickpos.x) - (int) rect.x;
                var y = Convert.ToInt32(pickpos.y) - (int) rect.y;

                var d = _resizedData[(int) rect.height - y, x];
                var cutoffs = _section.Cutoffs;

                for (var i = 0; i < cutoffs.Count; i++)
                {

                    if (d <= cutoffs[i])
                    {
                        ProWorld.Windows.Add(new AreaWindow(_section, i));
                        break;
                    }
                }
            }
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(position.width - 200, 0, 200, position.height - 130), "Options",
                                GUI.skin.window);
            if (Event.current.type == EventType.mouseUp || Event.current.type == EventType.Ignore)
            {
                /*if (_updateAreas || _update)
                {
                    if (_updateAreas)
                    {
                        _updateAreas = false;
                        _section.Areas = _areas;
                        _section.CreateAreas();
                    }
                    else
                    {
                        _section.SplitAreas();
                    }

                    UpdateTextures();
                    _updateAreas = false;
                    _update = false;
                }*/

                if (_updateAreas)
                {
                    _updateAreas = false;
                    _section.Areas = _areas;
                    _section.CreateAreas();
                    UpdateTextures();
                }

                if (_update)
                {
                    foreach(var ted in _section.TextureEditorData)
                    {
                        ted.Dirty = true;
                    }
                    _section.SplitAreas();
                    UpdateTextures();
                    _update = false;
                }

                if (_updateResolution)
                {
                    _section.TextureResolution = _resolution;

                    for (var index = 0; index < _section.Areas; index++)
                    {
                        var m = _section.TextureEditorData[index].Resize(_resolution, _section.SectionsWithFade[index]);
                        //var m = _section.TextureEditorData[index].Resize(_resolution, _section.Sections[index]);
                        _med.AddRange(m);
                    }
                    _updateResolution = false;

                    _rebuildResolution = true;
                }
            }

            Options();
            Slider();

            GUILayout.FlexibleSpace();
            GUILayout.EndArea();
        }

        private void Options()
        {
            GUILayout.Label("Texture Resolution");
            GUILayout.BeginHorizontal();

            var bits = 0;
            while (_resolution > 1) // much more efficient than log10 / log2 
            {
                bits++;
                _resolution >>= 1;
            }
            bits = MyGUI.RoundSlider(bits, 6, 12);
            _resolution = (int) Mathf.Pow(2, bits);

            GUILayout.Label(_resolution.ToString(CultureInfo.InvariantCulture), GUILayout.Width(40));
            GUILayout.EndHorizontal();
        }

        private void Slider()
        {
            if (Event.current.type == EventType.used && _resolution != _section.TextureResolution)
                // Don't do on the fly otherwise it'd cause lots of updates
            {
                _updateResolution = true;
            }

            GUILayout.Label("Areas");
            GUILayout.BeginHorizontal();
            _areas = MyGUI.RoundSlider(_areas, 1, 8);
            GUILayout.Label(_areas.ToString(CultureInfo.InvariantCulture), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            if (Event.current.type == EventType.used && _areas != _section.Areas)
                // Don't do on the fly otherwise it'd cause lots of updates
            {
                _updateAreas = true;
            }

            var style = new GUIStyle(GUIStyle.none);
            style.stretchHeight = true;
            style.stretchWidth = true;

            GUILayout.BeginHorizontal(); // Begin Hor 1
            var heightsBack = new GUIContent(_slide);
            GUILayout.BeginVertical(); // Begin Vert 1
            GUILayout.Space(5);
            var rect = GUILayoutUtility.GetRect(heightsBack, style, GUILayout.Width(20), GUILayout.Height(180));
            GUILayout.Space(5);
            GUILayout.EndVertical(); // End Vert 1
            GUI.Box(rect, heightsBack, style);

            var cutoffs = _section.Cutoffs;

            // -1 because we don't want to be able to change last element
            for (var i = 0; i < _section.Cutoffs.Count - 1; i++)
            {
                const float space = World.FadeSize*2 + 0.01f;

                var min = i - 1 >= 0 ? _section.Cutoffs[i - 1] + space : space; // check out of range
                var max = _section.Cutoffs[i + 1] - space; // check out of range

                var before = cutoffs[i];
                cutoffs[i] = GUILayout.VerticalSlider(cutoffs[i], 1, 0, GUILayout.Width(20), GUILayout.Height(190));
                cutoffs[i] = Mathf.Clamp(cutoffs[i], min, max);

                if (Event.current.type == EventType.used && Math.Abs(before - cutoffs[i]) > float.Epsilon)
                    // Don't do on the fly otherwise it'd cause lots of updates
                {
                    _update = true;
                }
            }
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal(); // End Hor 1
            GUILayout.BeginHorizontal(); // Begin Hor 2
            GUILayout.Space(20);
            for (var i = 0; i < _section.Cutoffs.Count - 1; i++)
            {
                GUILayout.Label((_section.Cutoffs[i] * 100).ToString("00"), GUILayout.Width(18));
            }
            GUILayout.EndHorizontal(); // End Hor 2
        }

        public override void Refresh()
        {
            // Update World Texture
            var whm = Util.ResizeArray(_section.SectionHeightMap, 512);
            Util.ApplyWaterToTexture(_worldTexture, whm);

            // Generate other textures
            UpdateTextures();
        }

        private void UpdateTextures()
        {
            _resizedData = Util.ResizeArray(_section.SectionHeightMap, 512);
            var c = Util.DivideAreas(_resizedData, _section.Cutoffs);
            _outputTexture.SetPixels(c);
            _outputTexture.Apply();

            var colors = Colors();
            _slide.SetPixels(colors);
            _slide.Apply();
        }

        public override void Clean()
        {
            UnityEngine.Object.DestroyImmediate(_outputTexture);
            UnityEngine.Object.DestroyImmediate(_worldTexture);
            UnityEngine.Object.DestroyImmediate(_slide);
        }
    }
}