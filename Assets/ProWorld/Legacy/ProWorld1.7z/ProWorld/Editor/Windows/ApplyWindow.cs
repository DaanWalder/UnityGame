﻿using System.Collections.Generic;
using System.Globalization;
using ProWorldEditor;
using UnityEditor;
using UnityEngine;

public class ApplyWindow : EditorWindow
{
    public World WorldA;
    public Section SectionA;
    public int SectionIndex;

    private List<Terrain> _terrains = new List<Terrain>();
    private bool _doMultiple;

    public Terrain TerrainA;
    private TerrainData _terrainData;
    private readonly bool[] _toggles = new bool[3];

    private readonly List<Worker> _workers = new List<Worker>();

    private bool _isSingle = true;

    public static ApplyWindow Window;

    public static void Init(World world, int section)
    {
        Window = GetWindow<ApplyWindow>("Apply");
        Window.WorldA = world;
        Window.SectionA = world.Sections[section];
        Window.SectionIndex = section;
        Window.minSize = new Vector2(350, 240);

        GetSelection(ref Window.TerrainA);
    }

    private void Update()
    {
        Repaint();

        if (EditorApplication.isCompiling)
        {
            WorldA = null;
            Close();
        }

        for (var index = 0; index < _workers.Count; index++)
        {
            var w = _workers[index];
            if (w.IsDone)
            {
                w.Done();
                _workers.Remove(w);
                index--; // just removed 1 from list, must lower index by 1
            }
        }

        if (_doMultiple)
        {
            if (_workers.Count == 0)
            {
                SectionIndex++;

                if (SectionIndex < WorldA.Sections.Length)
                {
                    SectionA = WorldA.Sections[SectionIndex];
                    TerrainA = _terrains[SectionIndex];

                    Apply();
                }
                else
                {
                    SectionIndex = 0;
                    _doMultiple = false;
                }
            }
        }
    }

    private void OnGUI()
    {
        GUI.enabled = _workers.Count == 0;

        GUILayout.BeginHorizontal();
        if(GUILayout.Button("Single"))
        {
            _isSingle = true;
        }
        if (WorldA.Sections.Length - 1 == 1)
            GUI.enabled = false;
        if (GUILayout.Button("Multiple"))
        {
            _isSingle = false;
        }
        GUI.enabled = true;
        GUILayout.EndHorizontal();

        GUILayout.Space(20);

        if (_isSingle)
        {
            Single();   
        }
        else
        {
            Multiple();
        }
    }

    private void Single()
    {
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUILayout.Label("Terrain", GUILayout.Width(60));
        TerrainA = (Terrain)EditorGUILayout.ObjectField(TerrainA, typeof(Terrain), true, GUILayout.Width(150));
        GUILayout.Space(10);
        if (GUILayout.Button("Selection", GUILayout.Width(80)))
        {
            GetSelection(ref TerrainA);
        }
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();

        GUILayout.Space(10);
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUILayout.Label("Section Index", GUILayout.Width(100));
        SectionIndex = MyGUI.RoundSlider(SectionIndex, 0, WorldA.Sections.Length - 1, GUILayout.Width(100));
        SectionA = WorldA.Sections[SectionIndex];
        GUILayout.Label(SectionIndex.ToString(CultureInfo.InvariantCulture), GUILayout.Width(100));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUILayout.Space(20);

        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        _toggles[0] = GUILayout.Toggle(_toggles[0], "Terrain", GUILayout.Width(80));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        _toggles[1] = GUILayout.Toggle(_toggles[1], "Textures", GUILayout.Width(80));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        _toggles[2] = GUILayout.Toggle(_toggles[2], "Trees", GUILayout.Width(80));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();

        GUILayout.Space(10);

        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();

        if (_workers.Count == 0)
        {
            if (GUILayout.Button("Apply", GUILayout.Width(150)))
            {
                Apply();
            }
        }
        else
        {
            GUI.enabled = true;
            if (GUILayout.Button("Cancel", GUILayout.Width(200)))
            {
                foreach (var w in _workers)
                {
                    w.Cancel();
                }
                _workers.Clear();
            }
        }

        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();

        GUILayout.Space(5);

        if (_workers.Count != 0)
        {
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Label("Calculating", GUILayout.Width(80));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
        }
    }
    private void Multiple()
    {
        if (!_doMultiple)
            _terrains = GetSelections();

        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        if (_terrains.Count == WorldA.Sections.Length)
        {
            GUILayout.Label("All textures selected");
        }
        else
        {
            var c = WorldA.Sections.Length - _terrains.Count;
            GUILayout.Label("Select " + c + " more terrain");
        }

        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUILayout.Space(20);

        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        _toggles[0] = GUILayout.Toggle(_toggles[0], "Terrain", GUILayout.Width(80));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        _toggles[1] = GUILayout.Toggle(_toggles[1], "Textures", GUILayout.Width(80));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        _toggles[2] = GUILayout.Toggle(_toggles[2], "Trees", GUILayout.Width(80));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();

        GUILayout.Space(10);

        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();

        if (_workers.Count == 0)
        {
            if (GUILayout.Button("Apply", GUILayout.Width(150)))
            {
                _doMultiple = true;

                SetTerrain(); // move terrain to position + set neighbours

                SectionIndex = 0;
                TerrainA = _terrains[SectionIndex];
                SectionA = WorldA.Sections[SectionIndex];

                Apply();
            }
        }
        else
        {
            GUI.enabled = true;
            if (GUILayout.Button("Cancel", GUILayout.Width(200)))
            {
                foreach (var w in _workers)
                {
                    w.Cancel();
                }
                _workers.Clear();
            }
        }

        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();

        GUILayout.Space(5);

        if (_workers.Count != 0 || _doMultiple)
        {
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Label("Calculating", GUILayout.Width(80));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
        }
    }

    private void OnLostFocus()
    {
        // Can't close in here as it throws an error
        // WindowLayouts are invalid. Please use 'Window -> Layouts -> Revert Factory Settings...' menu to fix it.
        //_close = true;
    }

    public static void GetSelection(ref Terrain terrain)
    {
        var active = Selection.activeGameObject;
        if (!active) return;

        var t = active.GetComponent<Terrain>();
        if (!t) return;

        terrain = t;
    }

    private static List<Terrain> GetSelections()
    {
        var l = new List<Terrain>();

        var active = Selection.gameObjects;
        if (active.Length == 0) return l;

        foreach(var a in active)
        {
            var t = a.GetComponent<Terrain>();
            if (t)
            {
                l.Add(t);
            }
        }

        return l;
    }

    private void SetTerrain()
    {
        var dim = WorldA.SizeOfTerrain;
        var count = WorldA.NumSections;

        // Set neighbours
        for (var j = 0; j < count; j++)
        {
            for (var i = 0; i < count; i++)
            {
                var index = j*count + i;

                var t = _terrains[index];
                t.transform.position = new Vector3(i * dim, 0, j * dim);

                SetNeighbours(index);
            }
        }
    }
    private void SetNeighbours(int index)
    {
        var width = WorldA.NumSections;
        var size = WorldA.Sections.Length;

        var left = index % width - 1 >= 0 ? _terrains[index - 1] : null;
        var top = index + width < size ? _terrains[index + width] : null;
        var right = index % width + 1 < width ? _terrains[index + 1] : null;
        var bottom = index - width >= 0 ? _terrains[index - width] : null;

        _terrains[index].SetNeighbors(left, top, right, bottom);
    }

    private void Apply()
    {
        if (!TerrainA)
        {
            Debug.Log("No terrain set");
            return;
        }

        _terrainData = TerrainA.terrainData;

        if (_toggles[0])
        {
            _terrainData.heightmapResolution = WorldA.SectionHmRes;
        }
        if (_toggles[1])
        {
            _terrainData.alphamapResolution = SectionA.TextureResolution;
        }

        _terrainData.size = new Vector3(WorldA.SizeOfTerrain, WorldA.HeightOfTerrain, WorldA.SizeOfTerrain);

        if (_toggles[0])
            _workers.Add(new TerrainWorker(TerrainA, SectionA));
        if (_toggles[1])
            _workers.Add(new TextureWorker(TerrainA, SectionA));
        if (_toggles[2])
            _workers.Add(new TreeWorker(TerrainA, SectionA));

        //_terrainData.baseMapResolution = 1024;

        // NOT IMPLEMENTED YET
        //_terrainData.SetDetailResolution(Section.Resolution, 16);
        //_terrainData.alphamapResolution = Section.Resolution;
    }
}