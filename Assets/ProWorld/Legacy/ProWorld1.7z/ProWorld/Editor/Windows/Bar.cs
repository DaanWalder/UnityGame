using UnityEditor;
using UnityEngine;

namespace ProWorldEditor
{
    public static class Bar
    {
        public static void OnGUI()
        {
            GUILayout.BeginHorizontal();
            for (var index = 0; index < ProWorld.Windows.Count; index++)
            {
                var name = ProWorld.Windows[index].GetType().Name;

                if (GUILayout.Button(name, EditorStyles.miniButtonMid, GUILayout.Width(100)))
                {
                    ProWorld.SetWindow(index);
                }
            }
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Assets", EditorStyles.miniButtonMid))
            {
                ProWorld.Windows.Add(new ImportAssets());
            }

            GUILayout.Space(20);

            if (GUILayout.Button("Import", EditorStyles.miniButtonMid))
            {
                ImportWindow.Init();
            }
            if (GUILayout.Button("New", EditorStyles.miniButtonMid))
            {
                ProWorld.Initialize();
                ProWorld.World = new World();
                ProWorld.Windows.Add(new WorldWindow());
            }

            GUILayout.Space(20);
            if (GUILayout.Button("Save", EditorStyles.miniButtonMid))
            {
                var path = EditorUtility.SaveFilePanel("Save to file", "", "proworld.pw", "pw");

                if (path.Length != 0)
                {
                    FileOperations.SaveToFile(path);
                }
            }
            if (GUILayout.Button("Load", EditorStyles.miniButtonMid))
            {
                var path = EditorUtility.OpenFilePanel("Save to file", "", "pw");

                if (path.Length != 0)
                {
                    ProWorld.World.Clean();
                    ProWorld.Initialize();
                    ProWorld.World = FileOperations.LoadFromFile(path);
                    ProWorld.Windows.Add(new WorldWindow());
                }

            }
            if (GUILayout.Button("Apply", EditorStyles.miniButtonMid))
            {
                ApplyWindow.Init(ProWorld.World, ProWorld.CurrentSection);
            }

            GUILayout.EndHorizontal();
        }
    }
}