﻿using System.ComponentModel;
using UnityEngine;

namespace ProWorldEditor
{
    public sealed class AreaWindow : IWindowLayout
    {
        private readonly Section _tsd;
        private readonly int _index;
        private readonly bool[,] _map;

        private Texture2D _inputTexture;
        private Texture2D _textureTexture;
        private Texture2D _treeTexture;

        private bool _updateTexture;

        private readonly BackgroundWorker _bw = new BackgroundWorker();

        public AreaWindow(Section tsd, int index)
        {
            _tsd = tsd;
            _index = index;

            _map = Util.ResizeArray(tsd.Sections[index], _tsd.TextureResolution);

            _inputTexture = new Texture2D(512, 512);
            _treeTexture = new Texture2D(256, 256);

            // Generate tree
            if (_tsd.TreeSection[index].IsDirty)
            {
                _tsd.TreeSection[index].IsDirty = false;

                TreesEditor.GenerateTrees(tsd, index);

                _bw.WorkerSupportsCancellation = true;
                _bw.DoWork += TreesEditor.CalculateTexture;
                _bw.RunWorkerCompleted += DoneCalculatingTree;
                _bw.RunWorkerAsync(_tsd.TreeSection[index]);
            }

            Refresh();
        }

        public override void OnGUI()
        {
            if (_bw.IsBusy) GUI.enabled = false;

            if (_updateTexture)
            {
                var small = Util.ResizeArray(_tsd.TreeSection[_index].ColorOutput, 256);

#if !A
                Util.ApplyIntMapToTexture(_treeTexture, small);
#endif

                //_treeTexture.SetPixels(small);
                //_treeTexture.Apply();
                _updateTexture = false;
            }

            //var position = ProWorld.Window.position;
            GUILayout.BeginArea(new Rect(0, 0, 525, 536), "Section", GUI.skin.window);
            GUILayout.Box(_inputTexture, GUIStyle.none, GUILayout.Width(512), GUILayout.Height(512));
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(525, 0, 265, 280), "Texture", GUI.skin.window);
            if (GUILayout.Button(_textureTexture, GUIStyle.none, GUILayout.Width(256), GUILayout.Height(256)))
            {
                ProWorld.Windows.Add(new TextureEditor(_tsd, _index));
            }
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(790, 0, 265, 280), "Tree", GUI.skin.window);
            if (GUILayout.Button(_treeTexture, GUIStyle.none, GUILayout.Width(256), GUILayout.Height(256)))
            {
                ProWorld.Windows.Add(new TreesEditor(_tsd, _index));
            }
            GUILayout.EndArea();

            GUI.enabled = true;
        }

        private void DoneCalculatingTree(object sender, RunWorkerCompletedEventArgs e)
        {
            _updateTexture = true;
        }

        public override void Refresh()
        {
            var map = Util.ResizeArray(_map, 512);
            Util.ApplyBoolMapToTexture(_inputTexture, map);

            if (_tsd.TreeSection[_index].ColorOutput == null)
                _tsd.TreeSection[_index].ColorOutput = new int[ProWorld.World.SizeOfTerrain, ProWorld.World.SizeOfTerrain];

            var small = Util.ResizeArray(_tsd.TreeSection[_index].ColorOutput, 256);

#if !A
            Util.ApplyIntMapToTexture(_treeTexture, small);
#endif

            TextureEditor.GenerateOutputTexture(_tsd.TextureEditorData[_index], ref _textureTexture);
        }

        public override void Clean()
        {
            Object.DestroyImmediate(_inputTexture);
            Object.DestroyImmediate(_textureTexture);
            Object.DestroyImmediate(_treeTexture);
        }
    }
}