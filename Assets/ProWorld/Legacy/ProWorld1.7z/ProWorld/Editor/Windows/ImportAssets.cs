﻿using UnityEditor;
using UnityEngine;

namespace ProWorldEditor
{
    public sealed class ImportAssets : IWindowLayout
    {
        private Vector2 _textureScroll;
        private Vector2 _treeScroll;

        private float _width;
        private float _height;

        public override void OnGUI()
        {
            _width = ProWorld.Window.position.width/2f;
            _height = ProWorld.Window.position.height - 20;

            GUILayout.BeginArea(new Rect(0, 0, _width, _height), "Textures", GUI.skin.window);
            TextureBar();
            GUILayout.EndArea();
            GUILayout.BeginArea(new Rect(_width, 0, _width, _height), "Trees", GUI.skin.window);
            TreeBar();
            GUILayout.EndArea();
        }

        private void TextureBar()
        {
            var style = new GUIStyle(GUIStyle.none)
                            {stretchHeight = true, stretchWidth = true, margin = new RectOffset(2, 2, 2, 2)};
            var textures = ProWorld.World.Textures;

            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Add", EditorStyles.miniButtonLeft, GUILayout.Width(150)))
            {
                var ntd = new TextureSplat();
                textures.Add(ntd);
                TextureSplatProperties.CreateTDP(ntd);
            }
            if (GUILayout.Button("Remove Last", EditorStyles.miniButtonRight, GUILayout.Width(150)))
            {
                var count = textures.Count;
                if (count != 0)
                    textures.RemoveAt(count - 1);
                /*else // don't want to drop below 1 so we just clear it 
                    textures[0] = new TextureSplat();*/

            }
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            _textureScroll = GUILayout.BeginScrollView(_textureScroll); // Begin Scroll

            var x = 13;
            GUILayout.BeginHorizontal(); // Begin Hor 2
            foreach (var t in textures)
            {
                var text = t.Texture ? t.Texture : Util.White;

                x += 66;
                if (x > _width)
                {
                    GUILayout.EndHorizontal();
                    GUILayout.BeginHorizontal();
                    x = 66;
                }

                if (GUILayout.Button(text, style, GUILayout.Width(64), GUILayout.Height(64)))
                {
                    TextureSplatProperties.CreateTDP(t);
                }
            }
            GUILayout.EndHorizontal(); // End Hor 2
            GUILayout.EndScrollView(); // End Scroll
        }

        private void TreeBar()
        {
            var style = new GUIStyle(GUIStyle.none)
                            {stretchHeight = true, stretchWidth = true, margin = new RectOffset(2, 2, 2, 2)};
            var tree = ProWorld.World.Trees;

            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Add", EditorStyles.miniButtonLeft, GUILayout.Width(150)))
            {
                var td = new TreeData();
                tree.Add(td);
                TreeDataProperties.CreateTDP(td);
            }
            if (GUILayout.Button("Remove Last", EditorStyles.miniButtonRight, GUILayout.Width(150)))
            {
                var count = tree.Count;
                if (count != 0)
                    tree.RemoveAt(count - 1);

            }
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            _treeScroll = GUILayout.BeginScrollView(_treeScroll); // Begin Scroll
            var x = 13;
            GUILayout.BeginHorizontal(); // Begin Hor 2

            foreach (var t in tree)
            {
#if UNITY_4_0
                var text = t.Prefab ? AssetPreview.GetAssetPreview(t.Prefab) : Util.White;
#else
                var text = t.Prefab ? EditorUtility.GetAssetPreview(t.Prefab) : Util.White;
#endif

                x += 66;
                if (x > _width)
                {
                    GUILayout.EndHorizontal();
                    GUILayout.BeginHorizontal();
                    x = 66;
                }

                if (GUILayout.Button(text, style, GUILayout.Width(64), GUILayout.Height(64)))
                {
                    TreeDataProperties.CreateTDP(t);
                }
            }
            GUILayout.EndHorizontal(); // End Hor 2
            GUILayout.EndScrollView(); // End Scroll
        }
    }
}