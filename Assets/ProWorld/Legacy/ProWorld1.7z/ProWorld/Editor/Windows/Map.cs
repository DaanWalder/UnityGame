﻿using System;
using ProWorldEditor;
using UnityEditor;
using UnityEngine;

[Serializable]
public class Map : EditorWindow
{
    [MenuItem("Window/ProWorld/Map")]
    public static void Init()
    {
        var window = GetWindow<Map>();
        window.minSize = new Vector2(1246, 646);
    }

    private MapEditor _me; //

    public void Update()
    {
        Repaint();

        if (_me == null)
        {
            var med = new MapEditorData();
            med.Update = delegate { }; // TRY

            _me = new MapEditor(med, this);
        }
    }

    public void OnGUI()
    {
        _me.OnGUI();
    }

    public void Apply(float[,] data)
    {

    }
}