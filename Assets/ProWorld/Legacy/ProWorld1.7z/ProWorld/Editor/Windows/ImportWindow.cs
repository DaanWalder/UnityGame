﻿using System;
using System.Collections.Generic;
using System.Globalization;
using ProWorldEditor;
using UnityEditor;
using UnityEngine;

public class ImportWindow : EditorWindow
{
    public Terrain TerrainA;
    private TerrainData _terrainData;
    private readonly bool[] _toggles = new bool[3];

    public static ImportWindow Window;

    public static void Init()
    {
        Window = GetWindow<ImportWindow>("Apply");
        Window.minSize = new Vector2(350, 200);

        GetSelection(ref Window.TerrainA);
    }

    private void Update()
    {
        Repaint();

        if (EditorApplication.isCompiling)
        {
            Close();
        }
    }

    private void OnGUI()
    {
        GUILayout.Space(20);

        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUILayout.Label("Terrain", GUILayout.Width(60));
        TerrainA = (Terrain)EditorGUILayout.ObjectField(TerrainA, typeof(Terrain), true, GUILayout.Width(150));
        GUILayout.Space(10);
        if (GUILayout.Button("Selection", GUILayout.Width(80)))
        {
            GetSelection(ref TerrainA);
        }
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();

        GUILayout.Space(20);

        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUILayout.Toggle(true, "Terrain", GUILayout.Width(80));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUI.enabled = false;
        _toggles[1] = GUILayout.Toggle(_toggles[1], "Textures", GUILayout.Width(80));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        _toggles[2] = GUILayout.Toggle(_toggles[2], "Trees", GUILayout.Width(80));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUI.enabled = true;

        GUILayout.Space(10);

        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();

        if (GUILayout.Button("Import", GUILayout.Width(200)))
        {
            if (TerrainA != null)
            {
                var path = Application.dataPath;

                do
                {
                    path = EditorUtility.SaveFolderPanel("Save assets to directory", Application.dataPath, "");

                } while (!ComparePath(path));

                if (path != string.Empty) // string empty is cancel case
                    Import(path);
            }
        }

        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
    }

    private bool ComparePath(string path)
    {
        if (path == string.Empty) return true;

        var l = Application.dataPath.Length;
        if (l > path.Length) return false;

        var sub = path.Substring(0, l);

        return Application.dataPath == sub;
    }

    public static void GetSelection(ref Terrain terrain)
    {
        var active = Selection.activeGameObject;
        if (!active) return;

        var t = active.GetComponent<Terrain>();
        if (!t) return;

        terrain = t;
    }

    private void Import(string path)
    {
        var w = new World();

        var td = TerrainA.terrainData;

        if (Math.Abs(td.size.x - td.size.z) > float.Epsilon)
        {
            Debug.Log("Width and length of terrain does not match. This is currently unsupported.");
            return;
        }

        w.SizeOfTerrain = (int)td.size.x;
        w.HeightOfTerrain = (int)td.size.y;
        w.SetMapResolution(td.heightmapResolution);

        var s = w.Sections[0];

        // We get the heightmap and save it as a png
        var map = td.GetHeights(0, 0, w.SectionHmRes, w.SectionHmRes);
        w.WorldHeightMap = map;
        s.SectionHeightMap = map;
        var heightMapPath = path + "/heightmap.png";
        FileOperations.SaveImage(map, heightMapPath);

        // We then create an import node with that png and link it to the output
        w.Map.Output = new NodeData(typeof(OutputNode));
        w.Map.Output.InputConnections = new OutputLink[1];
        w.Map.Output.Inputs = new float[1][,];

        var import = new ImportMapData(typeof(ImportMapNode));
        import.InputConnections = new OutputLink[0];
        import.Inputs = new float[0][,];
        var assetPath = heightMapPath.Substring(Application.dataPath.Length-6); // we want to start from the Assets/... part
        import.SetPath(assetPath);

        w.Map.Nodes.Add(import);
        var link = new OutputLink(w.Map.Output, 0, import);
        import.OutputConnections.Add(link);
        w.Map.Output.InputConnections[0] = link;

        ProWorld.World.Clean();
        ProWorld.World = w;
    }
}