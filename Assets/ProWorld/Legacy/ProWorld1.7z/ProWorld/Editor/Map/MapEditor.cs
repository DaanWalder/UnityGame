using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using UnityEditor;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public class MapEditorData : ISerializable, IClean
    {
        public int Size = 513;

        public List<NodeData> Nodes = new List<NodeData>();
        public NodeData Output;

        public delegate void UpdateOutput(float[,] data);

        [NonSerialized] public UpdateOutput Update;

        [NonSerialized] public bool Dirty;

        public MapEditorData()
        {

        }

        public MapEditorData(SerializationInfo info, StreamingContext context)
        {
            Size = info.GetInt32("Size");
            Nodes = (List<NodeData>) info.GetValue("Nodes", typeof (List<NodeData>));
            Output = (NodeData) info.GetValue("Output", typeof (NodeData));

            Dirty = true;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Size", Size);
            info.AddValue("Nodes", Nodes);
            info.AddValue("Output", Output);
        }

        public void Clean()
        {
            foreach(var n in Nodes)
            {
                n.Clean();
            }
            Nodes = null;

            if (Output != null)
                Output.Clean();
            Output = null;

            Update = null;
        }
    }

    public class MapEditor : IWindowLayout
    {
        public const int OptionWidth = 150;
        public const int Height = 300;
        public const int Preview = Height - 10;

        private Vector2 _scroll;

        private Node _currentOutputNode;
        private Node _currentInputNode;
        private int _currentInputNodeIndex;

        private OutputLink _lastLink;

        public Node CurrentNode;

        public MapEditorData Med;
        public EditorWindow Window;
        private float _offset;

        private readonly NodeList _nodeList;
        private readonly NodeOptions _nodeOptions;
        private readonly NodePreview _nodePreview;
        private readonly OutputPreview _outputPreview;

        private List<Node> _nodes = new List<Node>(); // { new OutputNode() };
        public OutputNode Output;

        private Stack<List<NodeData>> _dirtyStack;

        public MapEditor(MapEditorData med, EditorWindow window, float offset = 0)
        {
            Med = med;
            Window = window;
            _offset = offset;

            _nodeList = new NodeList(this);
            _nodeOptions = new NodeOptions(this);
            _nodePreview = new NodePreview(this);
            _outputPreview = new OutputPreview(this);

            if (Med.Output == null)
            {
                Output = new OutputNode(this);
                Med.Output = Output.Data;
            }
            else
            {
                Output = new OutputNode(this, Med.Output);
            }

            foreach (var nodeData in Med.Nodes)
            {
                var node = (Node) Activator.CreateInstance(nodeData.NodeType, this, nodeData);
                _nodes.Add(node);
            }

            if (Med.Dirty)
            {
                Rebuild();
                // TODO GET NON LINKED
            }

        }

        private void Rebuild()
        {
            _dirtyStack = new Stack<List<NodeData>>();

            var output = new List<NodeData> {Med.Output};
            _dirtyStack.Push(output);

            var data = FindConnections(output).ToList();

            while (data.Count != 0)
            {
                var tmp = new List<NodeData>();

                foreach (var d in data)
                {
                    var push = true;

                    foreach (var list in _dirtyStack)
                    {
                        if (list.Contains(d))
                        {
                            push = false;
                            break;
                        }
                    }

                    if (push)
                        tmp.Add(d);
                }
                _dirtyStack.Push(tmp);

                data = FindConnections(tmp).ToList();
            }

            // Start
            foreach (var node in _dirtyStack.Peek())
            {
                node.Owner.DoWorkNoChildren();
            }
        }

        private static IEnumerable<NodeData> FindConnections(IEnumerable<NodeData> nodes)
        {
            var newNodes = new HashSet<NodeData>();

            foreach (var node in nodes)
            {
                foreach (var input in node.InputConnections)
                {
                    // Check if an input is connected
                    if (input)
                        newNodes.Add(input.OutputNode);
                }
            }

            return newNodes;
        }

        public void CheckStack()
        {
            var nodes = _dirtyStack.Peek();
            var done = nodes.All(node => !node.Owner.Calculating);

            if (done)
            {
                _dirtyStack.Pop();

                if (_dirtyStack.Count == 0)
                {
                    Med.Dirty = false;
                }
                else
                {
                    nodes = _dirtyStack.Peek();

                    foreach (var node in nodes)
                    {
                        node.Owner.DoWorkNoChildren();
                    }
                }
            }
        }

        /// <summary>
        /// Keeps updating dirty calculations. 
        /// </summary>
        /// <returns></returns>
        public bool CheckUpdating()
        {
            CheckStack();

            if (!Med.Dirty)
            {
                var done = Med.Nodes.All(node => !node.Owner.Calculating);
                if (done)
                {
                    Clean(); // Clean up map editor because we want to delete it
                    return true;
                }
            }
            return false;
        }

        public override void OnGUI()
        {
            // Go through do calculations
            if (Med.Dirty)
            {
                CheckStack();
            }

            var width = Window.position.width;
            var height = Window.position.height - _offset;

            GUILayout.BeginArea(new Rect(width - OptionWidth, 0, OptionWidth, height), "Nodes", GUI.skin.window);
            _nodeList.OnGUI();
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(0, height - Height, width - OptionWidth - Preview - Preview, Height),
                                "Settings", GUI.skin.window);
            _nodeOptions.OnGUI();
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(width - OptionWidth - Preview - Preview, height - Height, Preview, Height),
                                "Preview", GUI.skin.window);
            _nodePreview.OnGUI();
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(width - OptionWidth - Preview, height - Height, Preview, Height), "Output",
                                GUI.skin.window);
            _outputPreview.OnGUI();
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(0, 0, width - OptionWidth, height - Height));

            foreach (var node in Med.Nodes)
            {
                foreach (var connection in node.InputConnections)
                {
                    if (connection != null)
                        CurveFromTo(connection, Color.red);
                }
            }
            foreach (var connection in Med.Output.InputConnections)
            {
                if (connection != null)
                    CurveFromTo(connection, Color.red);
            }

            Window.BeginWindows();

            foreach (var node in _nodes)
            {
                node.OnGUI();
            }
            Output.OnGUI();

            Window.EndWindows();

            GUILayout.EndArea();

            AttachingNode();
            Events();
        }

        public void DoUpdate()
        {

        }

        private void AttachingNode()
        {
            if (_currentOutputNode)
                CurveFromTo(_currentOutputNode.Data.WindowRect, Event.current.mousePosition, Color.red);
            else if (_currentInputNode)
                CurveFromTo(_currentInputNode.Data.WindowRect, _currentInputNodeIndex, Event.current.mousePosition,
                            Color.red);
        }

        private void Events()
        {
            if (Event.current.type == EventType.mouseDown)
            {
                _currentOutputNode = null;
                _currentInputNode = null;
            }
        }

        public void AddNode(Node node)
        {
            _nodes.Add(node);
            Med.Nodes.Add(node.Data);

            CurrentNode = node;
        }

        public void CloseWindow(Node node)
        {
            foreach (var input in node.Data.InputConnections.Where(input => input))
            {
                input.OutputNode.OutputConnections.Remove(input);
            }
            foreach (var output in node.Data.OutputConnections)
            {
                output.InputNode.InputConnections[output.InputIndex] = null;
            }

            if (CurrentNode == node)
                CurrentNode = null;

            _nodes.Remove(node);
            Med.Nodes.Remove(node.Data);
        }

        public void OutputLink(Node node)
        {
            _currentOutputNode = node;

            if (!_currentInputNode) return;

            Link();
        }

        public void InputLink(Node node, int index)
        {
            if (node.Data.InputConnections[index])
            {
                var ol = node.Data.InputConnections[index];
                ol.OutputNode.OutputConnections.Remove(ol);
                node.Data.InputConnections[index] = null;

            }

            _currentInputNode = node;
            _currentInputNodeIndex = index;

            if (!_currentOutputNode) return;

            Link();
        }

        private void Link()
        {
            if (_currentInputNode != _currentOutputNode)
            {
                _lastLink = new OutputLink(_currentInputNode.Data, _currentInputNodeIndex, _currentOutputNode.Data);

                _currentOutputNode.Data.OutputConnections.Add(_lastLink);
                _currentInputNode.Data.InputConnections[_currentInputNodeIndex] = _lastLink;

                // Check if the link causes an infinite loop
                if (CheckInfiniteLoop(_currentOutputNode.Data))
                {
                    _currentInputNode.DoWork();
                }
                else
                {
                    RemoveLastLink();
                }
            }

            _currentOutputNode = null;
            _currentInputNode = null;
        }

        public void RemoveLastLink()
        {
            _lastLink.InputNode.InputConnections[_lastLink.InputIndex] = null;
            _lastLink.OutputNode.OutputConnections.Remove(_lastLink);

            _currentInputNode = null;
            _currentOutputNode = null;
        }

        private bool CheckInfiniteLoop(NodeData node)
        {
            var nodeCalculate = new List<NodeData>();

            var output = new List<NodeData> {node};
            var data = FindConnections(output).ToList();

            while (data.Count != 0)
            {
                var tmp = new List<NodeData>();

                foreach (var d in data)
                {
                    if (!nodeCalculate.Contains(d))
                    {
                        nodeCalculate.Add(d);
                        tmp.Add(d);
                    }
                    else
                    {
                        return false;
                    }
                }

                data = FindConnections(tmp).ToList();
            }
            return true;
        }

        /*private void CurveFromTo(Rect wr, Rect wr2, Color color)
        {
            Drawing.bezierLine(
                new Vector2(wr.x + wr.width, wr.y + wr.height / 2),
                new Vector2(wr.x + wr.width + Mathf.Abs(wr2.x - (wr.x + wr.width)) / 2, wr.y + wr.height / 2),
                new Vector2(wr2.x, wr2.y + wr2.height / 2),
                new Vector2(wr2.x - Mathf.Abs(wr2.x - (wr.x + wr.width)) / 2, wr2.y + wr2.height / 2),
                color, 2, true, 20);
        }*/

        private void CurveFromTo(Rect wr, Vector2 point, Color color)
        {
            Drawing.BezierLine(
                new Vector2(wr.x + wr.width, wr.y + wr.height - 10),
                new Vector2(wr.x + wr.width + Mathf.Abs(point.x - (wr.x + wr.width))/2, wr.y + wr.height - 10),
                new Vector2(point.x, point.y),
                new Vector2(point.x - Mathf.Abs(point.x - (wr.x + wr.width))/2, point.y),
                color, 2, true, 20);
        }

        private void CurveFromTo(Rect wr2, int index, Vector2 point, Color color)
        {
            wr2.y += 25 + index*20;

            Drawing.BezierLine(
                new Vector2(point.x, point.y),
                new Vector2(point.x + Mathf.Abs(wr2.x - point.x)/2, point.y),
                new Vector2(wr2.x, wr2.y),
                new Vector2(wr2.x - Mathf.Abs(wr2.x - point.x)/2, wr2.y),
                color, 2, true, 20);
        }

        private void CurveFromTo(OutputLink link, Color color)
        {
            var wr = link.OutputNode.WindowRect;

            var point = new Vector2
                            {
                                x = link.InputNode.WindowRect.x,
                                y = link.InputNode.WindowRect.y + 25 + link.InputIndex*20
                            };

            Drawing.BezierLine(
                new Vector2(wr.x + wr.width, wr.y + wr.height - 10),
                new Vector2(wr.x + wr.width + Mathf.Abs(point.x - (wr.x + wr.width))/2, wr.y + wr.height - 10),
                new Vector2(point.x, point.y),
                new Vector2(point.x - Mathf.Abs(point.x - (wr.x + wr.width))/2, point.y),
                color, 2, true, 20);
        }

        public override void Clean()
        {
            // Remove all references to nodes so we can garbage collect them
            foreach (var data in Med.Nodes)
            {
                data.Owner = null;
            }
            Med.Output.Owner = null;
        }

        public override void Refresh()
        {
            foreach (var n in Med.Nodes)
            {
                n.Owner.UpdateTextures();
            }
            Med.Output.Owner.UpdateTextures();
        }
    }
}
