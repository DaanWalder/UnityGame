﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;
using ProWorldSDK;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class SubData : NodeData
    {
        public Combination.Morph Morph = Combination.Morph.Shift;

        public SubData(Type type)
            : base(type)
        {

        }

        public SubData(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            Morph = (Combination.Morph) info.GetValue("Morph", typeof (Combination.Morph));
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("Morph", Morph);
        }
    }

    public sealed class Sub : Node
    {
        private readonly SubData _data;

        public Sub(MapEditor mapEditor)
            : base(mapEditor, new SubData(typeof (Sub)))
        {
            _data = (SubData) Data;
            Title = "Sub";
            SetInputs(2);
        }

        public Sub(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            _data = (SubData) Data;
            Title = "Sub";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);

            OutputGUI();
        }

        public override void GUIOptions()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("Morph:", GUILayout.Width(50));
            _data.Morph =
                (Combination.Morph)
                MyGUI.EnumSlider((int) _data.Morph, Enum.GetNames(typeof (Combination.Morph)).Length - 1,
                                 GUILayout.Width(50));
            GUILayout.Label(_data.Morph.ToString(), GUILayout.Width(100));
            GUILayout.EndHorizontal();

            base.GUIOptions();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            for (var i = 0; i < Data.InputConnections.Length; i++)
            {
                if (!Data.InputConnections[i]) return;
                Data.Inputs[i] = Data.InputConnections[i].OutputNode.Output;
            }

            Data.Output = Combination.Sub(Data.Inputs[0], Data.Inputs[1], _data.Morph);
        }
    }
}