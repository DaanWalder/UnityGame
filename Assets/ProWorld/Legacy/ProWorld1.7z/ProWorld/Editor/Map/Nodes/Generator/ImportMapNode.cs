﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;
using UnityEditor;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class ImportMapData : NodeData
    {
        private string Path;// = string.Empty;
        [NonSerialized]public float[,] GreyArray;

        public ImportMapData(Type type)
            : base(type)
        {
            
        }

        public ImportMapData(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            SetPath(info.GetString("Path"));
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("Path", Path);
        }

        public void SetPath(string path)
        {
            Path = path;
            var image = (Texture2D)AssetDatabase.LoadAssetAtPath(Path, typeof(Texture2D));
            Util.CheckTexture(image);
            GreyArray = Util.ConvertToGrayscale(image);
        }
    }

    public sealed class ImportMapNode : Node
    {
        private readonly ImportMapData _data;

        public ImportMapNode(MapEditor mapEditor)
            : base(mapEditor, new ImportMapData(typeof (ImportMapNode)))
        {
            _data = (ImportMapData)Data;
            Title = "Import";
            SetInputs(0);
        }

        public ImportMapNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            _data = (ImportMapData)Data;
            Title = "Import";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);

            OutputGUI();
        }

        public override void GUIOptions()
        {
            var texture = (Texture2D)EditorGUILayout.ObjectField("Heightmap: ", OutputTexture, typeof(Texture2D), false, 
                                            GUILayout.Width(64), GUILayout.Height(64));
            GUILayout.Label("Warning: IsReadable will be set to true");

            if (texture != OutputTexture)
            {
                _data.SetPath(AssetDatabase.GetAssetPath(texture));
                DoWork();
            }
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            Data.Output = Util.ResizeArray(_data.GreyArray, MapEditor.Med.Size);
        }
    }
}