﻿using System;
using System.ComponentModel;
using ProWorldSDK;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class Mul : Node
    {
        public Mul(MapEditor mapEditor)
            : base(mapEditor, new NodeData(typeof (Mul)))
        {
            Title = "Mul";
            SetInputs(2);
        }

        public Mul(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            Data = data;
            Title = "Mul";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);

            OutputGUI();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            for (var i = 0; i < Data.InputConnections.Length; i++)
            {
                if (!Data.InputConnections[i]) return;
                Data.Inputs[i] = Data.InputConnections[i].OutputNode.Output;
            }

            Data.Output = Combination.Mul(Data.Inputs[0], Data.Inputs[1]);
        }
    }
}