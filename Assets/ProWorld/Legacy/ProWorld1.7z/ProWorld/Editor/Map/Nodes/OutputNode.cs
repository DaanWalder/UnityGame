﻿using System.ComponentModel;
using UnityEditor;
using UnityEngine;

namespace ProWorldEditor
{
    public class OutputNode : Node
    {
        public OutputNode(MapEditor mapEditor)
            : base(mapEditor, new NodeData(typeof (OutputNode)))
        {
            Title = "Output";
            SetInputs(1);
            ShowBar = false;
        }

        public OutputNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            Title = "Output";
            ShowBar = false;
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);

            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Box(OutputTexture, GUILayout.Width(PreviewSize), GUILayout.Height(PreviewSize));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
        }

        public override void GUIOptions()
        {
            if (GUILayout.Button("Save to File", GUILayout.Width(128)))
            {
                if (Data.InputConnections[0])
                {
                    var path = EditorUtility.SaveFilePanel("Save to file", "", "map.png", "png");

                    if (path.Length != 0)
                    {
                        FileOperations.SaveImage(Data.Inputs[0], path);
                    }
                }
            }
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            if (!Data.InputConnections[0]) return;

            Data.Inputs[0] = Data.InputConnections[0].OutputNode.Output;
            Data.Output = Data.Inputs[0];

            MapEditor.Med.Update(Data.Output);
        }
    }
}