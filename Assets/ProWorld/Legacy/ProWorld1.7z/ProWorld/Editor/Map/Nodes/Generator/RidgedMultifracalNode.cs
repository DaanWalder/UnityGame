﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.Serialization;
using ProWorldSDK;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class RidgedMultiData : NodeData
    {
        public RidgedMultifractal RM = new RidgedMultifractal();
        public float Range = 10;

        public RidgedMultiData(Type type)
            : base(type)
        {

        }

        public RidgedMultiData(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            RM = (RidgedMultifractal) info.GetValue("RM", typeof (RidgedMultifractal));
            Range = (float) info.GetValue("Range", typeof (float));
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("RM", RM);
            info.AddValue("Range", Range);
        }
    }

    public sealed class RidgedMultiNode : Node
    {
        private readonly RidgedMultiData _data;

        public RidgedMultiNode(MapEditor mapEditor)
            : base(mapEditor, new RidgedMultiData(typeof (RidgedMultiNode)))
        {
            _data = (RidgedMultiData) Data;
            Title = "RidgedMF";
            SetInputs(0);

            DoWork();
        }

        public RidgedMultiNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            _data = (RidgedMultiData) Data;
            Title = "RidgedMF";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);

            OutputGUI();
        }

        public override void GUIOptions()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("Range:", GUILayout.Width(50));
            _data.Range = MyGUI.LogSlider(_data.Range, -1, 3, GUILayout.Width(100));
            GUILayout.Label(_data.Range.ToString("0.00"), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("lacunarity:", GUILayout.Width(50));
            _data.RM.Lacunarity = MyGUI.LogSlider(_data.RM.Lacunarity, -1, 1.477121255f, GUILayout.Width(100));
            GUILayout.Label(_data.RM.Lacunarity.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Octaves:", GUILayout.Width(50));
            _data.RM.NumberOfOctaves =
                (int) GUILayout.HorizontalSlider(_data.RM.NumberOfOctaves, 1, 16, GUILayout.Width(100));
            GUILayout.Label(_data.RM.NumberOfOctaves.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Gain:", GUILayout.Width(50));
            _data.RM.Gain = GUILayout.HorizontalSlider(_data.RM.Gain, 0, 5f, GUILayout.Width(100));
            GUILayout.Label(_data.RM.Gain.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("offset:", GUILayout.Width(50));
            _data.RM.Offset = GUILayout.HorizontalSlider(_data.RM.Offset, -1, 1, GUILayout.Width(100));
            GUILayout.Label(_data.RM.Offset.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("hScale:", GUILayout.Width(50));
            _data.RM.HScale = GUILayout.HorizontalSlider(_data.RM.HScale, 0, 2f, GUILayout.Width(100));
            GUILayout.Label(_data.RM.HScale.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("vScale:", GUILayout.Width(50));
            _data.RM.VScale = GUILayout.HorizontalSlider(_data.RM.VScale, 0, 2f, GUILayout.Width(100));
            GUILayout.Label(_data.RM.VScale.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            base.GUIOptions();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            var min = float.PositiveInfinity;
            var max = float.NegativeInfinity;

            var size = MapEditor.Med.Size;

            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    Data.Output[y, x] = _data.RM.Noise(x/(float) size*_data.Range, y/(float) size*_data.Range);

                    Data.Output[y, x] += 1;
                    Data.Output[y, x] = Mathf.Clamp01(Data.Output[y, x]);

                    if (Data.Output[y, x] > max)
                        max = Data.Output[y, x];
                    if (Data.Output[y, x] < min)
                        min = Data.Output[y, x];
                }
            }
        }
    }
}