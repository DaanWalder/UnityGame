﻿using System.ComponentModel;
using ProWorldSDK;

namespace ProWorldEditor
{
    public sealed class Div : Node
    {
        public Div(MapEditor mapEditor)
            : base(mapEditor, new NodeData(typeof (Div)))
        {
            Title = "Div";
            SetInputs(2);
        }

        public Div(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            Title = "Div";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);
            OutputGUI();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            for (var i = 0; i < Data.InputConnections.Length; i++)
            {
                if (!Data.InputConnections[i]) return;
                Data.Inputs[i] = Data.InputConnections[i].OutputNode.Output;
            }

            Data.Output = Combination.Div(Data.Inputs[0], Data.Inputs[1]);
        }
    }
}