﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;
using ProWorldSDK;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class SquareData : NodeData
    {
        public Rect Size = new Rect(0, 0, 0.5f, 0.5f);

        public SquareData(Type type)
            : base(type)
        {

        }

        public SquareData(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            Size = ((SerializableRect) info.GetValue("Size", typeof (SerializableRect))).ToRect();
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("Size", new SerializableRect(Size));
        }
    }

    public sealed class SquareNode : Node
    {
        /*public enum Mode
        {
            Bell,
            Spherical,
            Linear,
        }*/

        private readonly SquareData _data;

        public SquareNode(MapEditor mapEditor)
            : base(mapEditor, new SquareData(typeof (SquareNode)))
        {
            _data = (SquareData) Data;
            Title = "Square";
            SetInputs(0);

            DoWork();
        }

        public SquareNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            _data = (SquareData) Data;
            Title = "Square";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);

            OutputGUI();
        }

        public override void GUIOptions()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("Mid X:", GUILayout.Width(50));
            _data.Size.x = GUILayout.HorizontalSlider(_data.Size.x, -1, 1, GUILayout.Width(200));
            GUILayout.Label(_data.Size.x.ToString("0.00"), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Mid Y:", GUILayout.Width(50));
            _data.Size.y = GUILayout.HorizontalSlider(_data.Size.y, -1, 1, GUILayout.Width(200));
            GUILayout.Label(_data.Size.y.ToString("0.00"), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Width:", GUILayout.Width(50));
            _data.Size.width = GUILayout.HorizontalSlider(_data.Size.width, 0, 1, GUILayout.Width(200));
            GUILayout.Label(_data.Size.width.ToString("0.00"), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Height:", GUILayout.Width(50));
            _data.Size.height = GUILayout.HorizontalSlider(_data.Size.height, 0, 1, GUILayout.Width(200));
            GUILayout.Label(_data.Size.height.ToString("0.00"), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            base.GUIOptions();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            Data.Output = new Square().Generate(MapEditor.Med.Size, _data.Size);
        }
    }
}