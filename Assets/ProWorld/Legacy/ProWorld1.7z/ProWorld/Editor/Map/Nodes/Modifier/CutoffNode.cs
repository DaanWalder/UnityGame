﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;
using ProWorldSDK;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class CutoffData : NodeData
    {
        public float MinConstant;
        public float MaxConstant = 1;

        public CutoffData(Type type)
            : base(type)
        {

        }

        public CutoffData(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            MinConstant = (float) info.GetValue("MinConstant", typeof (float));
            MaxConstant = (float) info.GetValue("MaxConstant", typeof (float));
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("MinConstant", MinConstant);
            info.AddValue("MaxConstant", MaxConstant);
        }
    }

    public sealed class CutoffNode : Node
    {
        private CutoffData _data;

        public CutoffNode(MapEditor mapEditor)
            : base(mapEditor, new CutoffData(typeof (CutoffNode)))
        {
            _data = (CutoffData) Data;
            Title = "Cutoff";
            SetInputs(1);
        }

        public CutoffNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            _data = (CutoffData) Data;
            Title = "Cutoff";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);
            OutputGUI();
        }

        public override void GUIOptions()
        {

            GUILayout.BeginHorizontal();
            GUILayout.Label("Min:", GUILayout.Width(50));
            _data.MinConstant = GUILayout.HorizontalSlider(_data.MinConstant, 0, 1, GUILayout.Width(100));
            GUILayout.Label(_data.MinConstant.ToString("0.00"), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Max:", GUILayout.Width(50));
            _data.MaxConstant = GUILayout.HorizontalSlider(_data.MaxConstant, 0, 1, GUILayout.Width(100));
            GUILayout.Label(_data.MaxConstant.ToString("0.00"), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            base.GUIOptions();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            for (var i = 0; i < Data.InputConnections.Length; i++)
            {
                if (!Data.InputConnections[i]) return;
                Data.Inputs[i] = Data.InputConnections[i].OutputNode.Output;
            }

            Data.Output = Modifier.Cutoff(Data.Inputs[0], _data.MinConstant, _data.MaxConstant);
        }
    }
}