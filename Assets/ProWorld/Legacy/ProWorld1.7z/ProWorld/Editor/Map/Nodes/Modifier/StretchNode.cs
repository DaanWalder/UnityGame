﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;
using ProWorldSDK;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class StretchData : NodeData
    {
        public float From = 0f;
        public float To = 1f;

        public StretchData(Type type)
            : base(type)
        {

        }

        public StretchData(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            From = (float) info.GetValue("From", typeof (float));
            To = (float) info.GetValue("To", typeof (float));
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("From", From);
            info.AddValue("To", To);
        }
    }

    public sealed class StretchNode : Node
    {
        private readonly StretchData _data;

        public StretchNode(MapEditor mapEditor)
            : base(mapEditor, new StretchData(typeof (StretchNode)))
        {
            _data = (StretchData) Data;
            Title = "Stretch";
            SetInputs(1);
        }

        public StretchNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            _data = (StretchData) Data;
            Title = "Stretch";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);
            OutputGUI();
        }

        public override void GUIOptions()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("From:", GUILayout.Width(50));
            _data.From = GUILayout.HorizontalSlider(_data.From, 0, 1, GUILayout.Width(100));
            GUILayout.Label(_data.From.ToString("0.00"), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            _data.From = Mathf.Min(_data.To - 0.01f, _data.From);

            GUILayout.BeginHorizontal();
            GUILayout.Label("To:", GUILayout.Width(50));
            _data.To = GUILayout.HorizontalSlider(_data.To, 0, 1, GUILayout.Width(100));
            GUILayout.Label(_data.To.ToString("0.00"), GUILayout.Width(30));

            _data.To = Mathf.Max(_data.To, _data.From + 0.01f);

            GUILayout.EndHorizontal();

            base.GUIOptions();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            for (var i = 0; i < Data.InputConnections.Length; i++)
            {
                if (!Data.InputConnections[i]) return;
                Data.Inputs[i] = Data.InputConnections[i].OutputNode.Output;
            }

            Data.Output = Modifier.Stretch(Data.Inputs[0], _data.From, _data.To);
        }
    }
}