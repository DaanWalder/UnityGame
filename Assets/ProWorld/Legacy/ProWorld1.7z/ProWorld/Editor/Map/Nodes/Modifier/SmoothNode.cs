﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.Serialization;
using UnityEngine;
using ProWorldSDK;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class SmoothData : NodeData
    {
        //public Smooth Smooth = new Smooth();
        public int Radius = 3;

        public SmoothData(Type type)
            : base(type)
        {

        }

        public SmoothData(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            Radius = info.GetInt32("Radius");
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("Radius", Radius);
        }
    }

    public sealed class SmoothNode : Node
    {
        private SmoothData _data;

        public SmoothNode(MapEditor mapEditor)
            : base(mapEditor, new SmoothData(typeof (SmoothNode)))
        {
            _data = (SmoothData) Data;
            Title = "Smooth";
            SetInputs(1);
        }

        public SmoothNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            _data = (SmoothData) Data;
            Title = "Smooth";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);
            OutputGUI();
        }

        public override void GUIOptions()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("Distance:", GUILayout.Width(50));
            _data.Radius = (int) GUILayout.HorizontalSlider(_data.Radius, 0, 30, GUILayout.Width(50));
            GUILayout.Label(_data.Radius.ToString(CultureInfo.InvariantCulture), GUILayout.Width(100));
            GUILayout.EndHorizontal();

            base.GUIOptions();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            for (var i = 0; i < Data.InputConnections.Length; i++)
            {
                if (!Data.InputConnections[i]) return;
                Data.Inputs[i] = Data.InputConnections[i].OutputNode.Output;
            }

            Data.Output = Smooth.SmoothGrayscale(Data.Inputs[0], _data.Radius);
        }
    }
}