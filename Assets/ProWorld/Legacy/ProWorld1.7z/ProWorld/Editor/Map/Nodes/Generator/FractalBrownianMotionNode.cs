﻿using System;
using System.Globalization;
using System.Runtime.Serialization;
using ProWorldSDK;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class FractalBrownianMotionData : NodeData
    {
        public FractalBrownianMotion fBm = new FractalBrownianMotion();
        public int Seed;
        public float Range = 1;
        public FractalBrownianMotionNode.OutputMorph Morph = FractalBrownianMotionNode.OutputMorph.Shift;

        public FractalBrownianMotionData(Type type)
            : base(type)
        {

        }

        public FractalBrownianMotionData(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            fBm = (FractalBrownianMotion) info.GetValue("fBm", typeof (FractalBrownianMotion));
            Seed = info.GetInt32("Seed");
            Range = (float) info.GetValue("Range", typeof (float));
            Morph =
                (FractalBrownianMotionNode.OutputMorph)
                info.GetValue("Morph", typeof (FractalBrownianMotionNode.OutputMorph));
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("fBm", fBm);
            info.AddValue("Seed", Seed);
            info.AddValue("Range", Range);
            info.AddValue("Morph", Morph);
        }
    }


    public sealed class FractalBrownianMotionNode : Node
    {
        public enum OutputMorph
        {
            Shift,
            Clamp,
            Abs
        }

        private FractalBrownianMotionData _data;

        public FractalBrownianMotionNode(MapEditor mapEditor)
            : base(mapEditor, new FractalBrownianMotionData(typeof (FractalBrownianMotionNode)))
        {
            _data = (FractalBrownianMotionData) Data;
            Title = "fBm";
            SetInputs(0);

            _data.Seed = UnityEngine.Random.Range(0, 99);
            _data.fBm.SetSeed(_data.Seed);

            DoWork();
        }

        public FractalBrownianMotionNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            _data = (FractalBrownianMotionData) Data;
            Title = "fBm";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);

            OutputGUI();
        }

        public override void GUIOptions()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("Seed:", GUILayout.Width(50));
            var oldSeed = _data.Seed;
            _data.Seed = (int) GUILayout.HorizontalSlider(_data.Seed, 0, 99, GUILayout.Width(100));
            GUILayout.Label(_data.Seed.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();
            if (_data.Seed != oldSeed)
                _data.fBm.SetSeed(_data.Seed);

            GUILayout.BeginHorizontal();
            GUILayout.Label("Range:", GUILayout.Width(50));
            _data.Range = MyGUI.LogSlider(_data.Range, -1, 3, GUILayout.Width(100));
            GUILayout.Label(_data.Range.ToString("0.00"), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("h:", GUILayout.Width(50));
            _data.fBm.H = MyGUI.LogSlider(_data.fBm.H, -1, 1.477121255f, GUILayout.Width(100));
            GUILayout.Label(_data.fBm.H.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Octaves:", GUILayout.Width(50));
            _data.fBm.Octaves = (int) GUILayout.HorizontalSlider(_data.fBm.Octaves, 1, 16, GUILayout.Width(100));
            GUILayout.Label(_data.fBm.Octaves.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Gain:", GUILayout.Width(50));
            _data.fBm.Gain = GUILayout.HorizontalSlider(_data.fBm.Gain, 0, 1.5f, GUILayout.Width(100));
            GUILayout.Label(_data.fBm.Gain.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Lacunarity:", GUILayout.Width(50));
            _data.fBm.Lacunarity = MyGUI.LogSlider(_data.fBm.Lacunarity, -1, 1, GUILayout.Width(100));
            GUILayout.Label(_data.fBm.Lacunarity.ToString(CultureInfo.InvariantCulture), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Morph:", GUILayout.Width(50));
            _data.Morph =
                (OutputMorph)
                MyGUI.EnumSlider((int) _data.Morph, Enum.GetNames(typeof (OutputMorph)).Length - 1, GUILayout.Width(50));
            GUILayout.Label(_data.Morph.ToString(), GUILayout.Width(80));
            GUILayout.EndHorizontal();

            base.GUIOptions();
        }

        public override void Calculate(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            var size = MapEditor.Med.Size;

            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    Data.Output[y, x] = _data.fBm.Noise(x/(float) size*_data.Range, y/(float) size*_data.Range);

                    switch (_data.Morph)
                    {
                        case OutputMorph.Shift:
                            Data.Output[y, x] = Mathf.Clamp01(Data.Output[y, x]*0.5f + 0.5f);
                            break;
                        case OutputMorph.Clamp:
                            Data.Output[y, x] = Mathf.Clamp01(Data.Output[y, x]);
                            break;
                        case OutputMorph.Abs:
                            Data.Output[y, x] = Mathf.Abs(Data.Output[y, x]);
                            break;
                    }
                }
            }
        }
    }
}