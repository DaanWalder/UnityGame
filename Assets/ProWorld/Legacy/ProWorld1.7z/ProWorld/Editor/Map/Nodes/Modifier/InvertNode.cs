﻿using System;
using System.ComponentModel;
using ProWorldSDK;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class InvertNode : Node
    {
        public InvertNode(MapEditor mapEditor)
            : base(mapEditor, new NodeData(typeof (InvertNode)))
        {
            Title = "Invert";
            SetInputs(1);
        }

        public InvertNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            Title = "Cutoff";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);

            OutputGUI();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            for (var i = 0; i < Data.InputConnections.Length; i++)
            {
                if (!Data.InputConnections[i]) return;
                Data.Inputs[i] = Data.InputConnections[i].OutputNode.Output;
            }

            Data.Output = Modifier.Invert(Data.Inputs[0]);
        }
    }
}