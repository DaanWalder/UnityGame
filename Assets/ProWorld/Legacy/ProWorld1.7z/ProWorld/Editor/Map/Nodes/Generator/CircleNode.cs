﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;
using ProWorldSDK;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class CircleData : NodeData
    {
        public Circle.Mode Mode = Circle.Mode.Bell;
        public Vector2 Center = Vector2.zero;
        public Vector2 Size = new Vector2(0.5f, 0.5f);

        public CircleData(Type type)
            : base(type)
        {

        }

        public CircleData(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            Mode = (Circle.Mode) info.GetValue("Mode", typeof (Circle.Mode));
            Center = ((SerializableVector2) info.GetValue("Center", typeof (SerializableVector2))).ToVector2();
            Size = ((SerializableVector2) info.GetValue("Size", typeof (SerializableVector2))).ToVector2();
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("Mode", Mode);
            info.AddValue("Center", new SerializableVector2(Center));
            info.AddValue("Size", new SerializableVector2(Size));
        }
    }

    public sealed class CircleNode : Node
    {
        /*public enum Mode
        {
            Bell,
            Spherical,
            Linear,
        }*/

        private readonly CircleData _data;

        public CircleNode(MapEditor mapEditor)
            : base(mapEditor, new CircleData(typeof (CircleNode)))
        {
            _data = (CircleData) Data;
            Title = "Circle";
            SetInputs(0);

            _data.Size = new Vector2(0.5f, 0.5f);

            DoWork();
        }

        public CircleNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            _data = (CircleData) Data;
            Title = "Circle";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);

            OutputGUI();
        }

        public override void GUIOptions()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("Mid X:", GUILayout.Width(50));
            _data.Center.x = GUILayout.HorizontalSlider(_data.Center.x, -1, 1, GUILayout.Width(100));
            GUILayout.Label(_data.Center.x.ToString("0.00"), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Mid Y:", GUILayout.Width(50));
            _data.Center.y = GUILayout.HorizontalSlider(_data.Center.y, -1, 1, GUILayout.Width(100));
            GUILayout.Label(_data.Center.y.ToString("0.00"), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Width:", GUILayout.Width(50));
            _data.Size.x = GUILayout.HorizontalSlider(_data.Size.x, 0, 1, GUILayout.Width(100));
            GUILayout.Label(_data.Size.x.ToString("0.00"), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Height:", GUILayout.Width(50));
            _data.Size.y = GUILayout.HorizontalSlider(_data.Size.y, 0, 1, GUILayout.Width(100));
            GUILayout.Label(_data.Size.y.ToString("0.00"), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Mode:", GUILayout.Width(50));
            _data.Mode =
                (Circle.Mode)
                MyGUI.EnumSlider((int) _data.Mode, Enum.GetNames(typeof (Circle.Mode)).Length - 1, GUILayout.Width(50));
            GUILayout.Label(_data.Mode.ToString(), GUILayout.Width(80));
            GUILayout.EndHorizontal();

            base.GUIOptions();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            Data.Output = new Circle().Generate(MapEditor.Med.Size, _data.Center, _data.Size, _data.Mode);
        }
    }
}