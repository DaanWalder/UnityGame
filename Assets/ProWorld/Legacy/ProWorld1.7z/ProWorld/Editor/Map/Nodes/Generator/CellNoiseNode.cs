using System;
using System.ComponentModel;
using System.Runtime.Serialization;
using ProWorldSDK;
using UnityEngine;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class CellNoiseData : NodeData
    {
        public CellNoise CNoise;
        public float Range = 100;

        public CellNoiseData(Type type)
            : base(type)
        {
            CNoise = new CellNoise(1, 3, DistType.Euclidean);
        }

        public CellNoiseData(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            Range = (float) info.GetValue("Range", typeof (float));
            CNoise = (CellNoise) info.GetValue("CellNoise", typeof (CellNoise));
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("Range", Range);
            info.AddValue("CellNoise", CNoise);
        }
    }

    public sealed class CellNoiseNode : Node
    {
        private CellNoiseData _data;

        public CellNoiseNode(MapEditor mapEditor)
            : base(mapEditor, new CellNoiseData(typeof (CellNoiseNode)))
        {
            _data = (CellNoiseData) Data;
            Title = "Cell Noise";
            SetInputs(0);

            DoWork();
        }

        public CellNoiseNode(MapEditor mapEditor, NodeData data)
            : base(mapEditor, data)
        {
            _data = (CellNoiseData) Data;
            Title = "Cell Noise";
            SetInput();
        }

        public override void DoWindow(int windowID)
        {
            base.DoWindow(windowID);

            OutputGUI();
        }

        public override void GUIOptions()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("Dimensions:", GUILayout.Width(50));
            _data.CNoise.Dim = MyGUI.RoundSlider(_data.CNoise.Dim, 2, 3, GUILayout.Width(100));
            GUILayout.Label(_data.CNoise.Dim.ToString("0"), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("MaxOrder:", GUILayout.Width(50));
            _data.CNoise.MaxOrder = MyGUI.RoundSlider(_data.CNoise.MaxOrder, 1, 10, GUILayout.Width(100));
            GUILayout.Label(_data.CNoise.MaxOrder.ToString("00"), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Dist Type:", GUILayout.Width(50));
            _data.CNoise.DistType =
                (DistType)
                MyGUI.EnumSlider((int) _data.CNoise.DistType, Enum.GetNames(typeof (DistType)).Length - 1,
                                 GUILayout.Width(50));
            GUILayout.Label(_data.CNoise.DistType.ToString(), GUILayout.Width(90));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Range:", GUILayout.Width(50));
            _data.Range = MyGUI.LogSlider(_data.Range, 1, 4, GUILayout.Width(100));
            GUILayout.Label(_data.Range.ToString("0"), GUILayout.Width(40));
            GUILayout.EndHorizontal();

            base.GUIOptions();
        }

        public override void Calculate(object sender, DoWorkEventArgs e)
        {
            _data.CNoise.UpdateArrays();

            var max = 0f;
            var min = float.PositiveInfinity;

            if (_data.CNoise.At.Length == 3)
                _data.CNoise.At[2] += 0.07;

            var size = MapEditor.Med.Size;

            for (var x = 0; x < size; x++)
            {
                var xx = x/(float) size*_data.Range;

                _data.CNoise.At[0] = 0.05*(xx + 20);
                for (var y = 0; y < size; y++)
                {
                    var yy = y/(float) size*_data.Range;

                    _data.CNoise.At[1] = 0.04*(yy + 700);
                    _data.CNoise.Noise();

                    var outval = (float) _data.CNoise.F[0];
                    if (outval < min)
                        min = outval;
                    if (outval > max)
                        max = outval;

                    Data.Output[y, x] = Mathf.Clamp01((float) _data.CNoise.F[0]/2f);
                }
            }
        }
    }
}