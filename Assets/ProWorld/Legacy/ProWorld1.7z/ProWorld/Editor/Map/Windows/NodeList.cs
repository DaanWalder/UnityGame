﻿using UnityEngine;

namespace ProWorldEditor
{
    public class NodeList : Area
    {
        private readonly MapEditor _mapEditor;

        public NodeList(MapEditor mapEditor)
        {
            _mapEditor = mapEditor;
        }

        public override void OnGUI()
        {
            if (GUILayout.Button("Simplex"))
            {
                _mapEditor.AddNode(new SimplexNode(_mapEditor));
            }
            if (GUILayout.Button("fBm"))
            {
                _mapEditor.AddNode(new FractalBrownianMotionNode(_mapEditor));
            }
            if (GUILayout.Button("Cell Noise"))
            {
                _mapEditor.AddNode(new CellNoiseNode(_mapEditor));
            }
            if (GUILayout.Button("Ridged Mutli"))
            {
                _mapEditor.AddNode(new RidgedMultiNode(_mapEditor));
            }
            if (GUILayout.Button("Circle"))
            {
                _mapEditor.AddNode(new CircleNode(_mapEditor));
            }
            if (GUILayout.Button("Square"))
            {
                _mapEditor.AddNode(new SquareNode(_mapEditor));
            }
            if (GUILayout.Button("Import"))
            {
                _mapEditor.AddNode(new ImportMapNode(_mapEditor));
            }
            if (GUILayout.Button("Add"))
            {
                _mapEditor.AddNode(new Add(_mapEditor));
            }
            if (GUILayout.Button("Sub"))
            {
                _mapEditor.AddNode(new Sub(_mapEditor));
            }
            if (GUILayout.Button("Mul"))
            {
                _mapEditor.AddNode(new Mul(_mapEditor));
            }
            if (GUILayout.Button("Div"))
            {
                _mapEditor.AddNode(new Div(_mapEditor));
            }
            if (GUILayout.Button("Cutoff"))
            {
                _mapEditor.AddNode(new CutoffNode(_mapEditor));
            }
            if (GUILayout.Button("Stretch"))
            {
                _mapEditor.AddNode(new StretchNode(_mapEditor));
            }
            if (GUILayout.Button("Invert"))
            {
                _mapEditor.AddNode(new InvertNode(_mapEditor));
            }
            if (GUILayout.Button("Smooth"))
            {
                _mapEditor.AddNode(new SmoothNode(_mapEditor));
            }
        }

        private bool _update;
    }
}