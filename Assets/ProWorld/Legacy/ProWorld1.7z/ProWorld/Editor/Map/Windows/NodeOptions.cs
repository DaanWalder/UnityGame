﻿using UnityEngine;

namespace ProWorldEditor
{
    public class NodeOptions : Area
    {
        private readonly MapEditor _mapEditor;

        public NodeOptions(MapEditor mapEditor)
        {
            _mapEditor = mapEditor;
        }

        public override void OnGUI()
        {
            if (_mapEditor.CurrentNode)
            {
                _mapEditor.CurrentNode.CheckCalcReady();
                _mapEditor.CurrentNode.GUIOptions();
                GUILayout.FlexibleSpace();
                _mapEditor.CurrentNode.CheckCalc();
            }
        }
    }
}