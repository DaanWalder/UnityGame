﻿namespace ProWorldEditor
{
    public abstract class IWindowLayout
    {
        public abstract void OnGUI();
        public virtual void Refresh() { }
        public virtual void Clean() { }
        public virtual void Apply() { }
    }
}