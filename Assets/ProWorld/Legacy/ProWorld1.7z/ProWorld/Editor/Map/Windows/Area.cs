﻿namespace ProWorldEditor
{
    public abstract class Area
    {
        public virtual void Update() { }
        public virtual void OnInspectorUpdate() { }
        public abstract void OnGUI();
        public static implicit operator bool(Area exists) { return exists != null; }
    }
}