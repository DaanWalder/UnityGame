﻿using UnityEngine;

namespace ProWorldEditor
{
    public class NodePreview : Area
    {
        private readonly MapEditor _mapEditor;

        public NodePreview(MapEditor mapEditor)
        {
            _mapEditor = mapEditor;
        }

        public override void OnGUI()
        {
            var node = _mapEditor.CurrentNode;

            if (node)
            {
                var dimensions = MapEditor.Preview - 12;
                if (MapEditor.Height - 22 < dimensions)
                    dimensions = MapEditor.Height - 22;

                GUILayout.Box(node.OutputTexture, GUILayout.Width(dimensions), GUILayout.Height(dimensions));
            }
        }
    }
}