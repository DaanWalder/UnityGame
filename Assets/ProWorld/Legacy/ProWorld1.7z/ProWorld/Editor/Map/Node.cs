using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.Serialization;
using ProWorldSDK;
using UnityEngine;
using UnityEditor;

namespace ProWorldEditor
{
    [Serializable]
    public class NodeData : ISerializable, IClean
    {
        public Rect WindowRect;

        public OutputLink[] InputConnections; // each input is limted to 1 source
        public float[][,] Inputs;

        public List<OutputLink> OutputConnections = new List<OutputLink>(); // 1 output can go to many inputs
        [NonSerialized] public float[,] Output;

        public Type NodeType;

        [NonSerialized] public Node Owner;

        public NodeData(Type type)
        {
            NodeType = type;
        }

        public NodeData(SerializationInfo info, StreamingContext context)
        {
            WindowRect = ((SerializableRect) info.GetValue("WindowRect", typeof (SerializableRect))).ToRect();
            InputConnections = (OutputLink[]) info.GetValue("InputConnections", typeof (OutputLink[]));
            OutputConnections = (List<OutputLink>) info.GetValue("OutputConnections", typeof (List<OutputLink>));
            NodeType = (Type) info.GetValue("NodeType", typeof (Type));

            Inputs = new float[InputConnections.Length][,];
        }

        public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("WindowRect", new SerializableRect(WindowRect));
            info.AddValue("InputConnections", InputConnections);
            info.AddValue("OutputConnections", OutputConnections);
            info.AddValue("NodeType", NodeType);
        }

        public virtual void Clean()
        {
            InputConnections = null;
            Inputs = null;
            OutputConnections = null;
            Output = null;
            NodeType = null;
            if (Owner != null)
                Owner.Clean();
            Owner = null;
        }
    }

    public abstract class Node : IClean
    {
        protected const int PreviewSize = 64;

        private readonly int _windowID;
        protected bool ShowBar = true;
        private bool _recalculate;

        protected string Title = string.Empty;

        public NodeData Data;

        private bool _update;
        private bool _updateChildren = true;

        public Texture2D OutputTexture;

        protected MapEditor MapEditor;

        public bool Calculating;

        public static implicit operator bool(Node exists)
        {
            return exists != null;
        }

        protected Node(MapEditor mapEditor, NodeData data)
        {
            MapEditor = mapEditor;

            Data = data;
            Data.Owner = this;

            if (Data.Output == null || Data.Output.GetLength(0) != MapEditor.Med.Size)
                Data.Output = new float[MapEditor.Med.Size,MapEditor.Med.Size];

            _windowID = WindowID.ID++;

            OutputTexture = Util.BlackTexture(256);
            var d = Util.ResizeArray(Data.Output, 256);
            Util.ApplyMapToTexture(ref OutputTexture, d);
        }

        public virtual void Rebuild()
        {
            Data.Output = new float[MapEditor.Med.Size,MapEditor.Med.Size];
            SetInput();
        }

        protected void SetInputs(int i)
        {
            Data.InputConnections = new OutputLink[i];
            Data.Inputs = new float[i][,];
            SetInput();
        }

        protected void SetInput()
        {
            for (var index = 0; index < Data.Inputs.Length; index++)
            {
                Data.Inputs[index] = new float[MapEditor.Med.Size,MapEditor.Med.Size];
            }
        }

        public void OnGUI()
        {
            Data.WindowRect = GUILayout.Window(_windowID, Data.WindowRect, DoWindow, Title);

            Data.WindowRect.x = Mathf.Max(Data.WindowRect.xMin, 0);
            Data.WindowRect.y = Mathf.Max(Data.WindowRect.yMin, 0);

            if (_update)
            {
                UpdateTextures();
                CheckChildren();
                _update = false;
            }
        }

        public virtual void GUIOptions()
        {

        }

        public void CheckCalcReady()
        {
            if (_recalculate)
            {
                if (Event.current.type == EventType.mouseUp || Event.current.type == EventType.Ignore)
                {
                    DoWork();
                    _recalculate = false;
                }
            }
        }

        public void CheckCalc()
        {
            if (Event.current.type == EventType.used)
            {
                _recalculate = true;
            }
        }

        public virtual void DoWindow(int windowID)
        {
            if ((Event.current.button == 0) && (Event.current.type == EventType.mouseUp))
            {
                MapEditor.CurrentNode = this;
            }

            GUI.DragWindow(new Rect(0, 0, 10000, 15));

            InputsBarGUI();
        }

        protected void InputsBarGUI()
        {
            if (ShowBar && Data.Inputs.Length == 0)
            {
                GUILayout.BeginHorizontal();
                GUILayout.FlexibleSpace();

                GUI.color = Color.red;
                if (GUILayout.Button("X", EditorStyles.miniButton))
                {
                    MapEditor.CloseWindow(this);
                }
                GUI.color = Color.white;
                GUILayout.EndHorizontal();
            }

            for (var index = 0; index < Data.Inputs.Length; index++)
            {
                GUILayout.BeginHorizontal();

                if (GUILayout.Button("In", EditorStyles.miniButton))
                {
                    MapEditor.InputLink(this, index);
                }
                GUILayout.FlexibleSpace();

                if (index == 0 && ShowBar)
                {
                    GUI.color = Color.red;
                    if (GUILayout.Button("X", EditorStyles.miniButton))
                    {
                        MapEditor.CloseWindow(this);
                    }
                    GUI.color = Color.white;
                }
                GUILayout.EndHorizontal();
            }
        }

        protected void OutputGUI()
        {
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Box(OutputTexture, GUILayout.Width(PreviewSize), GUILayout.Height(PreviewSize));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Out", EditorStyles.miniButton))
            {
                _recalculate = false;
                MapEditor.OutputLink(this);
            }
            GUILayout.EndHorizontal();
        }

        public abstract void Calculate(object sender, DoWorkEventArgs e);

        private void Completed(object sender, RunWorkerCompletedEventArgs e)
        {
            _update = true;
            Calculating = false;
        }

        // Need to run this in main thread
        public void UpdateTextures()
        {
            var d = Util.ResizeArray(Data.Output, 256);
            Util.ApplyMapToTexture(ref OutputTexture, d);
        }

        private void CheckChildren()
        {
            if (_updateChildren)
            {
                foreach (var output in Data.OutputConnections)
                {
                    output.InputNode.Owner.DoWork();
                }
            }

            _updateChildren = true;
        }

        public void DoWork()
        {
            Calculating = true;
            var bw = new BackgroundWorker();
            bw.DoWork += Calculate;
            bw.RunWorkerCompleted += Completed;
            bw.RunWorkerAsync();
        }

        public void DoWorkNoChildren()
        {
            _updateChildren = false;
            DoWork();
        }

        public void SetInput(int input, float[,] data)
        {
            Data.Inputs[input] = data;
            DoWork();
        }

        public bool Contains(Vector2 vector2)
        {
            return Data.WindowRect.Contains(vector2);
        }

        public void Clean()
        {
            Data = null;
            UnityEngine.Object.DestroyImmediate(OutputTexture);
            OutputTexture = null;
            MapEditor = null;
        }
    }

    [Serializable]
    public class OutputLink
    {
        public NodeData InputNode;
        public int InputIndex;

        public NodeData OutputNode;

        public static implicit operator bool(OutputLink exists)
        {
            return exists != null;
        }

        public OutputLink(NodeData input, int index, NodeData output)
        {
            InputNode = input;
            InputIndex = index;
            OutputNode = output;
        }

    }
}
