﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using ProWorldSDK;
using UnityEngine;

namespace ProWorldEditor
{
    public class TextureWorker : Worker
    {
        private readonly TextureSplat[] _splatPrototypes;
        private float[,,] _alphaMapData;
        private readonly bool _update = true;

        public TextureWorker(Terrain terrain, Section section)
            : base(terrain, section)
        {
            var sp = new HashSet<TextureSplat>();

            foreach (var ted in section.TextureEditorData)
            {
                var found = false;
                foreach (var t in ted.Textures)
                {
                    if (t.Splat.Texture)
                    {
                        sp.Add(t.Splat);
                        found = true;
                    }
                }
                if (ted.Cliff.Splat.Texture)
                    sp.Add(ted.Cliff.Splat);

                if (!found)
                {
                    _update = false;
                    IsDone = true;
                    Debug.Log("Warning: One or more texture layers do not have textures assigned.");
                    return;
                }
            }

            _splatPrototypes = sp.ToArray(); // TODO REMOVE

            ThreadWorker.DoWork += Fade;
            ThreadWorker.RunWorkerAsync();
        }

        private void Fade(object sender, DoWorkEventArgs e)
        {
            // Rebuild any outdated texture sections before proceeding
            for (var index = 0; index < SectionW.TextureEditorData.Count; index++)
            {
                var t = SectionW.TextureEditorData[index];

                if (t.Dirty)
                {
                    var map = Util.ResizeArray(SectionW.SectionsWithFade[index], SectionW.TextureResolution);

                    TextureEditor.UpdateSections(SectionW.TextureResolution, t, map);
                    t.Dirty = false;
                }
            }

            // Set texture and alpha map resolutions
            if (_splatPrototypes.Length == 0)
            {
                Debug.Log("No textures assigned.");
                return;
            }

            // Calculate alphas within layers
            UpdateAlphas();
            UpdateHeights();

            IsDone = true;
        }

        
        private void UpdateAlphas()
        {
            var size = SectionW.TextureResolution;

            foreach (var ted in SectionW.TextureEditorData)
            {
                var textures = new List<TextureData>(ted.Textures) {ted.Cliff};

                // recreate the total section area
                var combined = new bool[size,size];
                for (var y = 0; y < size; y++)
                {
                    for (var x = 0; x < size; x++)
                    {
                        foreach (var t in textures)
                        {
                            combined[y, x] |= t.MaskSection[y,x];
                        }
                    }
                }

                // Blur each layer
                foreach (var t in textures)
                {
                    var ms = Util.BoolToFloat(t.MaskSection);
                    t.Alpha = Smooth.SmoothGrayscale(ms, 5);
                }
                
                // Average it out so it adds to 1
                for (var y = 0; y < size; y++)
                {
                    for (var x = 0; x < size; x++)
                    {
                        // only do it within our layer
                        if (combined[y, x])
                        {
                            var sum = 0f;
                            foreach(var t in textures)
                            {
                                sum += t.Alpha[y, x];
                            }
                            //var sum = textures.Sum(t => t.Alpha[y, x]);

                            foreach (var t in textures)
                            {
                                t.Alpha[y, x] = t.Alpha[y, x]/sum;
                            }
                        }
                        else
                        {
                            // cleanup blur outside layer
                            foreach (var t in textures)
                            {
                                t.Alpha[y, x] = 0;
                            }
                        }
                    }
                }
            }
        }

        private void UpdateHeights()
        {
            var size = SectionW.TextureResolution;
            var textures = _splatPrototypes.ToList(); // TODO REMOVE

            _alphaMapData = new float[size,size,_splatPrototypes.Length];

            // used to store any cells that are trying to fade with the same layer to fix at a later point
            var updateFade = new List<FadeUpdate>();

            // Calculate fading between sections
            for (var index = 0; index < SectionW.TextureEditorData.Count; index++)
            {
                var heightSection = SectionW.TextureEditorData[index];
                var cutoffs = SectionW.Cutoffs;

                var min = index - 1 >= 0 ? cutoffs[index - 1] - World.FadeSize : -World.FadeSize*2;
                var max = index + 1 < cutoffs.Count ? cutoffs[index] + World.FadeSize : 1 + World.FadeSize*2;

                var combinedTextures = new List<TextureData>(heightSection.Textures) {heightSection.Cliff};

                var heights = Util.ResizeArray(SectionW.SectionHeightMap, size);

                foreach (var texture in combinedTextures)
                {
                    var splat = texture.Splat;
                    var layer = textures.FindIndex(s => s == splat);

                    if (layer < 0)
                    {
                        //No texture found, must be empty layer.
                        //Debug.Log("Layer not found. This shouldn't happen");
                        continue;
                    }

                    for (var y = 0; y < size; y++)
                    {
                        for (var x = 0; x < size; x++)
                        {
                            // TODO
                            var height = heights[y, x];

                            // Calculate any fading between sections
                            float fade = 1;
                            if (height < min + World.FadeSize*2)
                            {
                                fade = (height - min)/(World.FadeSize*2);
                            }
                            else if (height > max - World.FadeSize*2)
                            {
                                fade = (max - height)/(World.FadeSize*2);
                            }

                            // If no value set, we don't want to apply anything. This avoids overriding previous data
                            if (Mathf.Abs(texture.Alpha[y, x]) > float.Epsilon)
                            {
                                // If we've already set a value it means we're trying to fade between the same texture so record this instead and fix it later
                                if (Mathf.Abs(_alphaMapData[y, x, layer]) > float.Epsilon)
                                {
                                    //alphaMapData[y, x, layer] = 1f;//fade * texture.Alpha[y, x];
                                    updateFade.Add(new FadeUpdate(x, y, layer));
                                }
                                else
                                    _alphaMapData[y, x, layer] = fade*texture.Alpha[y, x];

                            }
                        }
                    }
                }
            }

            // Fix all the same fades
            foreach (var f in updateFade)
            {
                var fadeValue = 0f;

                for (var l = 0; l < _splatPrototypes.Length; l++)
                {
                    if (f.Layer != l)
                    {
                        fadeValue += _alphaMapData[f.Y, f.X, l];
                    }
                }

                _alphaMapData[f.Y, f.X, f.Layer] = 1 - fadeValue;
            }
        }

        public override void Done()
        {
            if (!_update) return;

            TerrainDataW.splatPrototypes = _splatPrototypes.Select(s => s.ToSplatPrototype()).ToArray();
            TerrainDataW.SetAlphamaps(0, 0, _alphaMapData);
        }

        private class FadeUpdate
        {
            public readonly int X;
            public readonly int Y;
            public readonly int Layer;

            public FadeUpdate(int x, int y, int layer)
            {
                X = x;
                Y = y;
                Layer = layer;
            }
        }
    }
}