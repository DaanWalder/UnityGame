﻿using System.ComponentModel;
using UnityEngine;

namespace ProWorldEditor
{
    public abstract class Worker
    {
        protected Terrain TerrainW;
        protected TerrainData TerrainDataW;
        protected Section SectionW;
        protected BackgroundWorker ThreadWorker;

        protected Worker(Terrain td, Section section)
        {
            TerrainW = td;
            TerrainDataW = td.terrainData;
            SectionW = section;

            ThreadWorker = new BackgroundWorker
                               {
                                   WorkerSupportsCancellation = true,
                               };
        }

        public bool IsDone;
        public abstract void Done();

        public virtual void Cancel()
        {
            ThreadWorker.CancelAsync();
        }
    }
}