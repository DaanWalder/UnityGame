﻿using UnityEngine;

namespace ProWorldEditor
{
    public class TerrainWorker : Worker
    {
        public TerrainWorker(Terrain terrain, Section section)
            : base(terrain, section)
        {
            IsDone = true;
        }

        public override void Done()
        {
            TerrainDataW.SetHeights(0, 0, SectionW.SectionHeightMap);
        }
    }
}