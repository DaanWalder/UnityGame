﻿using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;

namespace ProWorldEditor
{
    public class TreeWorker : Worker
    {
        private Section _section;
        private List<int> tdpIndex = new List<int>();

        public TreeWorker(Terrain terrain, Section section)
            : base(terrain, section)
        {
            _section = section;

            for(var i = 0; i < section.TreeSection.Count; i++)
            {
                if(section.TreeSection[i].IsDirty)
                    tdpIndex.Add(i);
            }

            ThreadWorker.DoWork += GenerateTrees;
            ThreadWorker.RunWorkerAsync();
        }

        private void GenerateTrees(object sender, DoWorkEventArgs e)
        {
            foreach (var t in tdpIndex)
            {
                TreesEditor.GenerateTrees(_section, t);
            }
            IsDone = true;
        }

        public override void Done()
        {
            // TODO CHANGE SO ONLY NEEDED TREES
            var trees = ProWorld.World.Trees;
            var tps = new TreePrototype[trees.Count];

            for (var i = 0; i < trees.Count; i++)
            {
                tps[i] = new TreePrototype();
                tps[i].prefab = trees[i].Prefab;
            }

            TerrainDataW.treePrototypes = tps;
            TerrainDataW.RefreshPrototypes();

            // Clear any previous trees
            TerrainDataW.treeInstances = new TreeInstance[0];

            var treeSections = SectionW.TreeSection;

            foreach (var tsd in treeSections)
            {
                foreach (var box in tsd.Boxes)
                {
                    foreach (var tree in box.Objects)
                    {
                        var pos = tree.Position;
                        pos /= TerrainDataW.size.x;

                        pos.y = 0.5f;

                        var index = trees.FindIndex(t => t == tree.Data);

                        var ti = new TreeInstance
                                     {
                                         color = new Color(0.973f, 0.973f, 0.973f, 1.000f),
                                         heightScale = 1,
                                         lightmapColor = new Color(1.000f, 1.000f, 1.000f, 1.000f),
                                         widthScale = 1,
                                         position = pos,
                                         prototypeIndex = index
                                     };

                        TerrainW.AddTreeInstance(ti);
                    }
                }
            }
        }
    }
}