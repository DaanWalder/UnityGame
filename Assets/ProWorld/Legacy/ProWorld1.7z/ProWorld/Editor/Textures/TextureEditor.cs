using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using ProWorldSDK;
using UnityEngine;
using UnityEditor;

namespace ProWorldEditor
{
    [Serializable]
    public class TextureEditorData : ISerializable, IClean
    {
        public List<TextureData> Textures = new List<TextureData>();
        public TextureData Cliff; // = new TextureData();
        public float Steepness = 60;

        [NonSerialized] public bool Dirty;

        public TextureEditorData(bool[,] maskSection, int resolution)
        {
            var map = Util.ResizeArray(maskSection, resolution);

            Textures.Add(new TextureData(map, resolution));
            Cliff = new TextureData(map, resolution);
        }

        public TextureEditorData(SerializationInfo info, StreamingContext context)
        {
            Textures = (List<TextureData>) info.GetValue("Textures", typeof (List<TextureData>));
            Cliff = (TextureData) info.GetValue("Cliff", typeof (TextureData));
            Steepness = (float) info.GetValue("Steepness", typeof (float));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Textures", Textures);
            info.AddValue("Cliff", Cliff);
            info.AddValue("Steepness", Steepness);
        }

        public List<MapEditorData> Resize(int resolution, bool[,] maskSection)
        {
            var med = new List<MapEditorData>();

            var map = Util.ResizeArray(maskSection, resolution);

            foreach(var t in Textures)
            {
                med.Add(t.Resize(map, resolution));
            }
            med.Add(Cliff.Resize(map, resolution));

            return med;

            // UPDATE SECTION TEXTURES
        }

        public void Clean()
        {
            foreach(var td in Textures)
            {
                td.Clean();
            }
            Textures = null;
            Cliff.Clean();
            Cliff = null;
        }
    }

    [Serializable]
    public class TextureData : ISerializable, IClean
    {
        public TextureSplat Splat;
        public bool Active;

        public MapEditorData Med = new MapEditorData();

        public bool[,] Mask; // Mask from map data
        [NonSerialized] public Texture2D MaskTexture;
        public bool[,] MaskSection; // Mask from section
        [NonSerialized] public Texture2D MaskSectionTexture;

        [NonSerialized] public float[,] Alpha;

        public TextureData(bool[,] maskSection, int size)
            : this(new TextureSplat(), maskSection, size)
        {
            
        }

        public TextureData(TextureSplat splat, bool[,] maskSection, int size)
        {
            //var size = maskSection.GetLength(0);
            //var size = ProWorld.World.t

            Mask = Util.SetArrayValue(size, true);
            MaskTexture = Util.White;

            Splat = splat;

            MaskSection = new bool[size, size];
            Array.Copy(maskSection, MaskSection, maskSection.Length);

            Med.Size = size;
            Med.Update = UpdateMask;
            Med.Dirty = true;

            // Set output node
            Med.Output = new NodeData(typeof(OutputNode));
            Med.Output.InputConnections = new OutputLink[1];
            Med.Output.Inputs = new float[1][,];
            Med.Output.Output = Util.SetArrayValue(size, 1f);

            var square = new SquareData(typeof(SquareNode));
            square.InputConnections = new OutputLink[0];
            square.Inputs = new float[0][,];
            square.Size = new Rect(0,0,1.1f,1.1f);

            Med.Nodes.Add(square);
            var link = new OutputLink(Med.Output, 0, square);
            square.OutputConnections.Add(link);
            Med.Output.InputConnections[0] = link;

        }

        public TextureData(SerializationInfo info, StreamingContext context)
        {
            Splat = (TextureSplat) info.GetValue("Splat", typeof (TextureSplat));
            Active = info.GetBoolean("Active");
            Med = (MapEditorData) info.GetValue("Med", typeof (MapEditorData));
            Med.Update = UpdateMask;

            Mask = (bool[,]) info.GetValue("Mask", typeof (bool[,]));
            MaskSection = (bool[,]) info.GetValue("MaskSection", typeof (bool[,]));

            var small = Util.ResizeArray(Mask, 64);
            MaskTexture = new Texture2D(64, 64);
            Util.ApplyBoolMapToTexture(MaskTexture, small);

            var smallSection = Util.ResizeArray(MaskSection, 64);
            MaskSectionTexture = new Texture2D(64, 64);
            Util.ApplyBoolMapToTexture(MaskSectionTexture, smallSection);
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Splat", Splat);
            info.AddValue("Active", Active);

            info.AddValue("Mask", Mask);
            info.AddValue("MaskSection", MaskSection);
            info.AddValue("Med", Med);
        }

        public void UpdateTextures()
        {
            if (!MaskSectionTexture) // only create texture if we need to
                MaskSectionTexture = new Texture2D(64, 64);

            var ms = Util.ResizeArray(MaskSection, 64);
            Util.ApplyBoolMapToTexture(MaskSectionTexture, ms);
        }

        public void UpdateMask(float[,] data)
        {
            Mask = Util.GrayToBlackArray(data);
        }

        public MapEditorData Resize(bool[,] maskSection, int size)
        {
            // Mask will be handled by update

            MaskSection = new bool[size, size];
            Array.Copy(maskSection, MaskSection, maskSection.Length);

            Med.Size = size;
            Med.Dirty = true;
            Med.Update = UpdateMask;

            return Med;
        }

        public void Clean()
        {
            Splat = null;
            Med.Clean();
            Med = null;

            Mask = null;
            MaskTexture = null;
            MaskSection = null;
            MaskSectionTexture = null;
            Alpha = null;
        }
    }

    [Serializable]
    public class TextureSplat : ISerializable, IClean
    {
        [NonSerialized]
        public Texture2D Texture;
        public SerializableVector2 TileSize;
        public SerializableVector2 TileOffset;
        [NonSerialized]
        public bool Valid; // we have a valid flag so we can compare in alternate thread

        public TextureSplat()
        {
            Texture = null; // Util.White;
            Valid = Texture; // bool
            TileSize = new SerializableVector2(15, 15);
            TileOffset = new SerializableVector2(0, 0);
        }

        public TextureSplat(TextureSplat td)
        {
            Texture = td.Texture;
            Valid = Texture; // bool
            TileSize = td.TileSize;
            TileOffset = td.TileOffset;
        }

        public SplatPrototype ToSplatPrototype()
        {
            return new SplatPrototype { texture = Texture, tileSize = TileSize.ToVector2(), tileOffset = TileSize.ToVector2() };
        }

        public TextureSplat(SerializationInfo info, StreamingContext context)
        {
            var path = info.GetString("Texture");

            if (path == string.Empty)
            {
                Texture = null;
            }
            else
            {
                try
                {
                    Texture = (Texture2D)AssetDatabase.LoadAssetAtPath(path, typeof(Texture2D));
                }
                catch (Exception) // If texture missing just set a blank texture
                {
                    Debug.Log("No texture found at " + path + "\nSetting blank");
                    Texture = null;
                }
            }

            Valid = Texture;

            TileSize = (SerializableVector2)info.GetValue("TileSize", typeof(SerializableVector2));
            TileOffset = (SerializableVector2)info.GetValue("TileOffset", typeof(SerializableVector2));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            // we store the texture path rather than the texture
            info.AddValue("Texture", AssetDatabase.GetAssetPath(Texture));
            info.AddValue("TileSize", TileSize);
            info.AddValue("TileOffset", TileOffset);
        }

        public void Clean()
        {
            Texture = null;
            Valid = Texture;
            TileSize = null;
            TileOffset = null;
        }
    }

    public class TextureEditor : IWindowLayout
    {
        private readonly Section _section;
        private readonly TextureEditorData _ted;
        private readonly bool[,] _map;
        private readonly bool[,] _mapSmall;

        private readonly Texture2D _inputTexture;
        private readonly List<Texture2D> _combinedMask = new List<Texture2D>();
        private Texture2D _outputTexture;

        private Vector2 _textureScroll;

        private int _currentMask;

        private List<MapEditor> _me = new List<MapEditor>();

        private bool _rebuild;
        private bool _updateSteepness;

        public TextureEditor(Section section, int index)
        {
            _section = section;
            _ted = section.TextureEditorData[index];

            _map = Util.ResizeArray(section.SectionsWithFade[index], _section.TextureResolution);
            //_map = Util.ResizeArray(section.Sections[index], _section.TextureResolution);

            _inputTexture = new Texture2D(256, 256);
            var map = Util.ResizeArray(_map, 256);
            Util.ApplyBoolMapToTexture(_inputTexture, map);

            _outputTexture = new Texture2D(256, 256);

            _mapSmall = Util.ResizeArray(map, 64);

            foreach (var texture in _ted.Textures)
            {
                var t = new Texture2D(64, 64);

                // Convert to to blackwhite for preview
                var small = Util.ResizeArray(texture.Mask, 64);

                var combined = Util.AndArrays(small, _mapSmall);

                Util.ApplyBoolMapToTexture(t, combined);

                _combinedMask.Add(t);
            }

            var steepness = _section.SectionSteepness;
            if (steepness == null)
                _section.GenerateSteepness();

            GenerateCliffs(_ted, _section);

            UpdateSections();

            // Rebuild maps if they're dirty
            foreach (var m in _ted.Textures)
            {
                if (m.Med.Dirty)
                {
                    _rebuild = true;
                    _me.Add(new MapEditor(m.Med, null));
                }
            }
        }

        public override void OnGUI()
        {
            if (_rebuild)
            {
                GUI.enabled = false;

                for (var index = 0; index < _me.Count; index++)
                {
                    var m = _me[index];
                    if (m.CheckUpdating())
                    {
                        _me.Remove(m);
                        index--;
                    }
                }

                if (_me.Count == 0)
                {
                    _rebuild = false;
                }
            }
            else
            {
                GUI.enabled = true;
            }


            var position = ProWorld.Window.position;

            GUILayout.BeginArea(new Rect(0, 0, position.width, position.height - 20), "Textures", GUI.skin.window);
            Area();
            GUILayout.EndArea();

            // Check if texture updated and was previously not set
            foreach (var t in _ted.Textures)
            {
                if (!t.Active && t.Splat.Texture != null)
                {
                    UpdateSections();
                    break;
                }
            }
            if (!_ted.Cliff.Active && _ted.Cliff.Splat.Texture != null)
            {
                UpdateSections();
            }
        }

        private void Area()
        {
            GUILayout.BeginHorizontal(); // Start Hor 1

            GUILayout.Box(_inputTexture, GUIStyle.none, GUILayout.Width(256), GUILayout.Height(256));

            GUILayout.BeginVertical(GUILayout.Width(354)); // Start Vert 2

            if (GUILayout.Button("Add"))
            {
                AddNewTexture();
            }

            GUILayout.BeginHorizontal();
            GUILayout.Label("Texture", GUILayout.Width(64));
            GUILayout.Label("Mask", GUILayout.Width(64));
            GUILayout.Label("Combined", GUILayout.Width(64));
            GUILayout.Label("Actual", GUILayout.Width(64));
            GUILayout.EndHorizontal();

            _textureScroll = GUILayout.BeginScrollView(_textureScroll, false, false);

            for (var i = 0; i < _ted.Textures.Count; i++)
            {
                var t = _ted.Textures[i];
                var c = _combinedMask[i];

                GUILayout.BeginHorizontal(); // Start Hor 2
                TextureLayer(c, i, t);

                GUILayout.BeginVertical();
                if (_ted.Textures.Count == 1) GUI.enabled = false;
                if (GUILayout.Button("X", GUILayout.Width(50)))
                {
                    _ted.Textures.Remove(t);
                    _combinedMask.Remove(c);
                    if (i == 0 && _ted.Textures.Count > 0) // Set new top tier layer to all white
                    {
                        SetWhite(0);
                    }

                    i--;

                    UnityEngine.Object.DestroyImmediate(c);

                    UpdateSections();
                }
                if (i == 0) GUI.enabled = false;
                if (GUILayout.Button("Up", GUILayout.Width(50)))
                {
                    _ted.Textures.Remove(t);
                    _ted.Textures.Insert(i - 1, t);
                    _combinedMask.Remove(c);
                    _combinedMask.Insert(i - 1, c);

                    if (i == 1)
                    {
                        SetWhite(0);
                        SetNormal(1);
                    }

                    UpdateSections();
                }
                GUI.enabled = true;
                if (i == _ted.Textures.Count - 1) GUI.enabled = false;
                if (GUILayout.Button("Down", GUILayout.Width(50)))
                {
                    _ted.Textures.Remove(t);
                    _ted.Textures.Insert(i + 1, t);
                    _combinedMask.Remove(c);
                    _combinedMask.Insert(i + 1, c);

                    if (i == 0)
                    {
                        SetWhite(0);
                        SetNormal(1);
                    }

                    UpdateSections();
                }
                GUI.enabled = true;
                GUILayout.EndVertical();

                GUILayout.EndHorizontal();
            }

            GUILayout.Label("Cliff");
            GUILayout.BeginHorizontal();
            CliffLayer();
            GUILayout.EndHorizontal();

            GUILayout.EndScrollView();

            GUILayout.FlexibleSpace();
            GUILayout.EndVertical(); // End Vert 2
            GUILayout.Box(_outputTexture, GUIStyle.none, GUILayout.Width(256), GUILayout.Height(256));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal(); // End Hor 1

            GUILayout.FlexibleSpace();
        }

        private void TextureLayer(Texture2D combined, int index, TextureData td)
        {
            if (GUILayout.Button(td.Splat.Texture, GUI.skin.box, GUILayout.Width(64), GUILayout.Height(64)))
            {
                TextureDataProperties.CreateTDP(td, _ted, TextureRemove);
            }
            if (index == 0) // Top tier is not editable
                GUILayout.Box(td.MaskTexture, GUILayout.Width(64), GUILayout.Height(64));
            else
            {
                if (GUILayout.Button(td.MaskTexture, GUI.skin.box, GUILayout.Width(64), GUILayout.Height(64)))
                {
                    _currentMask = index;
                    ProWorld.Windows.Add(new MapEditor(td.Med, ProWorld.Window, ProWorld.BarHeight));
                }
            }

            GUILayout.Box(combined, GUILayout.Width(64), GUILayout.Height(64));

            GUILayout.Box(td.MaskSectionTexture, GUILayout.Width(64), GUILayout.Height(64));
        }

        private void CliffLayer()
        {
            if (_updateSteepness)
            {
                if (Event.current.type == EventType.mouseUp || Event.current.type == EventType.Ignore)
                {
                    GenerateCliffs(_ted, _section);
                    UpdateSections();
                    _updateSteepness = false;
                }
            }

            var cliff = _ted.Cliff;

            if (GUILayout.Button(cliff.Splat.Texture, GUI.skin.box, GUILayout.Width(64), GUILayout.Height(64)))
            {
                TextureDataProperties.CreateTDP(cliff, _ted, TextureRemove);
            }
            GUILayout.Box(cliff.MaskTexture, GUILayout.Width(64), GUILayout.Height(64));

            /*GUILayout.BeginVertical(GUILayout.Width(64));
            GUILayout.Label("Angle");
            _ted.Steepness = GUILayout.HorizontalSlider(_ted.Steepness, 0, 90);
            GUILayout.EndVertical();*/

            var gc = new GUIContent("");
            var rect = GUILayoutUtility.GetRect(gc, GUI.skin.box, GUILayout.Width(64), GUILayout.Height(64));

            GUI.Label(new Rect(rect.x, rect.y, rect.width, 20), "Angle: " + _ted.Steepness.ToString("0"));
            var steepness = _ted.Steepness;
            _ted.Steepness = GUI.HorizontalSlider(new Rect(rect.x, rect.y + 20, rect.width, 20), _ted.Steepness, 0, 90);

            if (Event.current.type == EventType.used && Math.Abs(steepness - _ted.Steepness) > float.Epsilon)
            {
                _updateSteepness = true;
            }

            GUILayout.Box(cliff.MaskSectionTexture, GUILayout.Width(64), GUILayout.Height(64));
        }

        private void TextureRemove()
        {
            UpdateSections();
        }

        private void SetWhite(int index)
        {
            _ted.Textures[index].Mask = Util.SetArrayValue(_section.TextureResolution, true);

            if (_ted.Textures[index].MaskTexture != Util.White) // destroy if not white
                UnityEngine.Object.DestroyImmediate(_ted.Textures[index].MaskTexture);

            _ted.Textures[index].MaskTexture = Util.White;

            var bw = Util.ResizeArray(_ted.Textures[index].Mask, 64);

            var combined = Util.AndArrays(bw, _mapSmall);

            Util.ApplyBoolMapToTexture(_combinedMask[index], combined);
        }

        private void SetNormal(int index)
        {
            if (_ted.Textures[index].Med.Output == null)
                _ted.Textures[index].Med.Output = new NodeData(typeof (OutputNode));//.Output

            _ted.Textures[index].UpdateMask(_ted.Textures[index].Med.Output.Output);
            UpdateMaskTexture(index);
        }

        private void AddNewTexture()
        {
            var newtd = new TextureData(_map, _section.TextureResolution);
            _ted.Textures.Add(newtd);

            var texture = new Texture2D(64, 64);
            var bw = Util.ResizeArray(newtd.Mask, 64);

            var combined = Util.AndArrays(bw, _mapSmall);

            Util.ApplyBoolMapToTexture(texture, combined);

            _combinedMask.Add(texture);

            UpdateSections();
        }

        private void UpdateSections()
        {
            UpdateSections(_section.TextureResolution, _ted, _map);
            UpdateSectionTextures(_ted);
            GenerateOutputTexture(_ted, ref _outputTexture);
        }
        public static void UpdateSections(int resolution, TextureEditorData ted, bool[,] map)
        {
            var size = resolution;

            //var left = Util.ResizeArray(map, size);

            var left = new bool[resolution,resolution];
            Array.Copy(map, left, map.Length);

            // Only do cliff if a texture is assigned otherwise clear it
            if (!ted.Cliff.Splat.Valid)
            {
                ted.Cliff.MaskSection = new bool[size,size];
                ted.Cliff.Active = false;
            }
            else
            {
                ted.Cliff.Active = true;

                for (var y = 0; y < size; y++)
                {
                    for (var x = 0; x < size; x++)
                    {
                        var val = left[y, x] && ted.Cliff.Mask[y, x];

                        ted.Cliff.MaskSection[y, x] = val;

                        if (val)
                            left[y, x] = false;
                    }
                }
            }

            for (var i = ted.Textures.Count - 1; i >= 0; i--)
            {
                var t = ted.Textures[i];

                if (!t.Splat.Valid)
                {
                    t.MaskSection = new bool[size,size];
                    t.Active = false;
                }
                else
                {
                    t.Active = true;

                    for (var y = 0; y < size; y++)
                    {
                        for (var x = 0; x < size; x++)
                        {
                            var val = left[y, x] && t.Mask[y, x];

                            t.MaskSection[y, x] = val;

                            if (val)
                                left[y, x] = false;
                        }
                    }
                }
            }
        }

        public static void GenerateCliffs(TextureEditorData ted, Section section)
        {
            var size = section.TextureResolution;

            var ratio = ProWorld.World.SectionHmRes/size;

            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var xx = x*ratio;
                    var yy = y*ratio;

                    ted.Cliff.Mask[y, x] = section.SectionSteepness[yy, xx] > ted.Steepness;
                }
            }

            var bw = Util.ResizeArray(ted.Cliff.Mask, 64);
            ted.Cliff.MaskTexture = new Texture2D(64, 64);
            Util.ApplyBoolMapToTexture(ted.Cliff.MaskTexture, bw);
        }

        public static Texture2D GenerateOutputTexture(TextureEditorData ted, ref Texture2D texture)
        {
            var td = ted.Textures;
            var cliff = ted.Cliff;

            var size = 0;
            if (td.Count > 0)
                size = td[0].MaskSection.GetLength(0);

            UnityEngine.Object.DestroyImmediate(texture);
            texture = new Texture2D(256, 256);

            var c = new Color[size*size];

            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    c[y*size + x] = Color.black;
                    var count = td.Count;

                    // Check if cliff
                    if (cliff.MaskSection[y, x])
                    {
                        c[y*size + x] = new Color(0, 1, 0);
                    }
                    else // else go through all textures
                    {
                        for (var i = td.Count - 1; i >= 0; i--)
                        {
                            if (td[i].MaskSection[y, x])
                            {
                                var r = (i + 1f)/count;

                                c[y*size + x] = new Color(r, 0, 0);
                                break;
                            }
                        }
                    }
                }
            }

            var resizedArray = Util.ResizeArray(c, 256);

            texture.SetPixels(resizedArray);
            texture.Apply();

            return texture;
        }

        public override void Refresh()
        {
            UpdateMaskTexture(_currentMask);
            UpdateSections();
        }

        private void UpdateMaskTexture(int index)
        {
            if (index >= _ted.Textures.Count) return;

            var t = _ted.Textures[index];

            var bw = Util.ResizeArray(t.Mask, 64);

            if (t.MaskTexture == Util.White) // don't want to override white
            {
                t.MaskTexture = new Texture2D(64, 64);
            }
            Util.ApplyBoolMapToTexture(t.MaskTexture, bw);

            var combined = Util.AndArrays(bw, _mapSmall);
            Util.ApplyBoolMapToTexture(_combinedMask[index], combined);
        }

        private static void UpdateSectionTextures(TextureEditorData ted)
        {
            var cliff = ted.Cliff;
            var sCliff = Util.ResizeArray(cliff.MaskSection, 64);
            Util.ApplyBoolMapToTexture(cliff.MaskSectionTexture, sCliff);

            // MaskSection
            foreach (var t in ted.Textures)
            {
                var small = Util.ResizeArray(t.MaskSection, 64);
                Util.ApplyBoolMapToTexture(t.MaskSectionTexture, small);
            }

            // Update all masks/etc
            foreach (var t in ted.Textures)
                t.UpdateTextures();
        }

        public override void Clean()
        {
            UnityEngine.Object.DestroyImmediate(_inputTexture);
            UnityEngine.Object.DestroyImmediate(_outputTexture);

            foreach (var t in _combinedMask)
            {
                UnityEngine.Object.DestroyImmediate(t);
            }
        }
    }
}
