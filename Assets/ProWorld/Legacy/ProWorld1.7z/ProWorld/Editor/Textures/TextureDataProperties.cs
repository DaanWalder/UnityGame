﻿using ProWorldEditor;
using UnityEditor;
using UnityEngine;

public class TextureDataProperties : ScriptableWizard
{
    public TextureData TextureD;
    public TextureEditorData Ted;
    private Vector2 _scroll = Vector2.zero;
    private bool _close;

    public delegate void OnRemoveDelegate();

    public OnRemoveDelegate OnRemove;

    public static void CreateTDP(TextureData textureData, TextureEditorData ted, OnRemoveDelegate onRemove)
    {
        var tdp = DisplayWizard<TextureDataProperties>("Create Texture", "Apply");
        tdp.TextureD = textureData;
        tdp.Ted = ted;
        tdp.OnRemove = onRemove;
    }

    private void Update()
    {
        if (_close || EditorApplication.isCompiling)
            Close();
    }

    private void OnGUI()
    {
        var width = position.width;
        var x = 5;

        var textures = ProWorld.World.Textures;

        _scroll = GUILayout.BeginScrollView(_scroll);
        GUILayout.BeginHorizontal();

        foreach (var td in textures)
        {
            x += 64;
            if (x > width - 20)
            {
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                x = 5;
                x += 64;
            }

            if (TextureD.Splat == td) GUI.color = Color.red;
            if (GUILayout.Button(td.Texture, GUIStyle.none, GUILayout.Width(64), GUILayout.Height(64)))
            {
                TextureD.Splat = td;
            }
            GUI.color = Color.white;
        }
        GUILayout.EndHorizontal();
        GUILayout.EndScrollView();

        GUILayout.FlexibleSpace();

        GUILayout.BeginHorizontal();

        if (Ted != null)
            if (GUILayout.Button("Remove"))
            {
                TextureD.Splat = new TextureSplat();
                OnRemove();
                Close();
            }
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
    }

    private void OnLostFocus()
    {
        // Can't close in here as it throws an error
        // WindowLayouts are invalid. Please use 'Window -> Layouts -> Revert Factory Settings...' menu to fix it.
        _close = true;
    }
}