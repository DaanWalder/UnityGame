﻿using ProWorldEditor;
using UnityEditor;
using UnityEngine;

public class TextureSplatProperties : ScriptableWizard
{
    public TextureSplat TextureSplatOld;
    public TextureSplat TextureSplatNew;
    //private bool _close;

    public static void CreateTDP(TextureSplat textureSplat)
    {
        var tdp = DisplayWizard<TextureSplatProperties>("Create Splat Prototype", "Apply");
        tdp.TextureSplatOld = textureSplat;
        tdp.TextureSplatNew = new TextureSplat(textureSplat);
    }

    private void Update()
    {
        if (EditorApplication.isCompiling)
            Close();
    }

    private void OnGUI()
    {
        TextureSplatNew.Texture = EditorGUILayout.ObjectField("Splat", TextureSplatNew.Texture, typeof (Texture), false, GUILayout.MaxHeight(10)) as Texture2D;

        TextureSplatNew.TileSize.X = EditorGUILayout.FloatField("Tile Size X", TextureSplatNew.TileSize.X);
        TextureSplatNew.TileSize.Y = EditorGUILayout.FloatField("Tile Size Y", TextureSplatNew.TileSize.Y);
        TextureSplatNew.TileOffset.X = EditorGUILayout.FloatField("Tile Offset X", TextureSplatNew.TileOffset.X);
        TextureSplatNew.TileOffset.Y = EditorGUILayout.FloatField("Tile Offset Y", TextureSplatNew.TileOffset.Y);

        GUILayout.FlexibleSpace();

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Remove"))
        {
            var textures = ProWorld.World.Textures;
            var count = textures.Count;
            if (count != 1)
                textures.Remove(TextureSplatOld);
            else // don't want to drop below 1 so we just clear it 
                textures[0] = new TextureSplat();

            Close();
        }
        GUILayout.FlexibleSpace();
        if (GUILayout.Button("Apply"))
        {
            TextureSplatOld.Texture = TextureSplatNew.Texture;
            TextureSplatOld.Valid = TextureSplatOld.Texture;
            TextureSplatOld.TileSize = TextureSplatNew.TileSize;
            TextureSplatOld.TileOffset = TextureSplatNew.TileOffset;

            Close();
        }
        GUILayout.EndHorizontal();
    }

    private void OnLostFocus()
    {
        // Can't close in here as it throws an error
        // WindowLayouts are invalid. Please use 'Window -> Layouts -> Revert Factory Settings...' menu to fix it.
        //_close = true;
    }
}