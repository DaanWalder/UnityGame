﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using UnityEditor;
using UnityEngine;
using ProWorldSDK;

namespace ProWorldEditor
{
    [Serializable]
    public class TreeSectionData : ISerializable, IClean
    {
        public int Density = 2000;
        public int Seed;
        public List<Tree> Trees = new List<Tree>();

        [NonSerialized] public int MaxTries = 20; // don't need this
        [NonSerialized] public Box[] Boxes;
        [NonSerialized] public int[,] ColorOutput; // Output texture data

        [NonSerialized] public bool IsDirty = true;

        public TreeSectionData()
        {
            SetDefaults();
        }

        private void SetDefaults()
        {
            IsDirty = true;
            MaxTries = 20;
            Boxes = new Box[0];
        }

        public TreeSectionData(SerializationInfo info, StreamingContext context)
        {
            Trees = (List<Tree>) info.GetValue("Trees", typeof (List<Tree>));
            Density = info.GetInt32("Density");
            Seed = info.GetInt32("Seed");

            SetDefaults();
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Trees", Trees);
            info.AddValue("Density", Density);
            info.AddValue("Seed", Seed);
        }

        public void Clean()
        {
            Trees = null;
            foreach(var b in Boxes)
            {
                b.Clean();
            }
            Boxes = null;
            ColorOutput = null; // Output texture data
        }
    }

    [Serializable]
    public class TreeData : ISerializable, IClean
    {
        public GameObject Prefab;
        public float[] Radius = new float[2] {0.2f, 1}; // 0 is trunk or shrub radius, 1 is top tree radius

        public TreeData()
        {

        }

        public TreeData(TreeData td)
        {
            Prefab = td.Prefab;
            Radius = td.Radius;
        }

        public TreeData(SerializationInfo info, StreamingContext context)
        {
            var path = info.GetString("Prefab");

            try
            {
                Prefab = (GameObject) AssetDatabase.LoadAssetAtPath(path, typeof (GameObject));
            }
            catch (Exception)
            {
                Debug.Log("No prefab found at " + path + "\nSetting blank");
                Prefab = null;
            }

            Radius = (float[]) info.GetValue("Radius", typeof (float[]));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Prefab", AssetDatabase.GetAssetPath(Prefab));
            info.AddValue("Radius", Radius);
        }

        public void Clean()
        {
            Prefab = null;
            Prefab = null;
            Radius = null;
        }
    }

    [Serializable]
    public class Tree : ISerializable
    {
        public TreeData Data;
        public Vector3 Position;
        public float Density = 1;

        public Tree(TreeData td)
        {
            Data = td;
        }

        public Tree(SerializationInfo info, StreamingContext context)
        {
            Position = ((SerializableVector3) info.GetValue("Position", typeof (SerializableVector3))).ToVector3();
            Data = (TreeData) info.GetValue("Data", typeof (TreeData));
            try
            {
                Density = (float) info.GetValue("Density", typeof (float));
            }
            catch (Exception)
            {
                Density = 1f;
            }
            
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Data", Data);
            info.AddValue("Position", new SerializableVector3(Position));
            info.AddValue("Density", Density);
        }
    }

    [Serializable]
    public sealed class TreesEditor : IWindowLayout
    {
        [Flags]
        private enum BoxPosition
        {
            None = 0,
            Left = 1,
            Right = 2,
            Up = 4,
            UpLeft = Up | Left,
            UpRight = Up | Right,
            Down = 8,
            DownLeft = Down | Left,
            DownRight = Down | Right,
        }

        private readonly Section _section;
        private readonly int _index;
        private Vector2 _treeScroll = Vector2.zero;
        private Vector2 _activeScroll = Vector2.zero;

        // Tree stuff
        private readonly TreeSectionData _tsd;

        private readonly Texture2D _outputTexture;

        private bool _updateTexure;
        private BackgroundWorker _bw;

        private struct OverflowData
        {
            public int NumOfBoxes;
            public float BoxSize;
            public float MaxOverflow;
        }

        public TreesEditor(Section section, int index)
        {
            _section = section;
            _index = index;
            _tsd = section.TreeSection[index];

            var size = ProWorld.World.SizeOfTerrain;
            _outputTexture = new Texture2D(size, size);

            _bw = new BackgroundWorker
                      {
                          WorkerSupportsCancellation = true
                      };
            _bw.DoWork += CalculateTexture;
            _bw.RunWorkerCompleted += DoneCalculatingTexture;

            Refresh();
        }
        
        // Use this for initialization
        public static void GenerateTrees(Section section, int sectionIndex)
        {
            var tsd = section.TreeSection[sectionIndex];
            var map = section.Sections[sectionIndex];

            var ofd = new OverflowData();
            ofd.NumOfBoxes = Mathf.Max(ProWorld.World.SizeOfTerrain/200, 1);
            ofd.BoxSize = ProWorld.World.SizeOfTerrain/(float) ofd.NumOfBoxes;

            tsd.Boxes = new Box[ofd.NumOfBoxes*ofd.NumOfBoxes];

            //Random.seed = tsd.Seed;
            var r = new System.Random(tsd.Seed);

            //var startTime = Time.realtimeSinceStartup;

            // Sort trees by canopy size (Place big trees first)
            var trees = tsd.Trees;
            trees = trees.OrderByDescending(x => x.Data.Radius[1]).ThenByDescending(x => x.Data.Radius[0]).ToList();

            // Get max radius
            ofd.MaxOverflow = trees.Select(t => t.Data.Radius[1]).Concat(new[] {0f}).Max();

            for (var h = 0; h < ofd.NumOfBoxes; h++)
            {
                for (var w = 0; w < ofd.NumOfBoxes; w++)
                {
                    // No Overflow yet
                    tsd.Boxes[w + h*ofd.NumOfBoxes] = new Box();
                }
            }

            var placed = 0;

            var totalDensity = trees.Sum(t => t.Density);
            var density = tsd.Density/totalDensity;

            foreach (var treeData in trees)
            {
                for (var i = 0; i < density*treeData.Density; i++)
                {
                    for (var j = 0; j < tsd.MaxTries; j++)
                    {
                        var pos = new Vector3((float)r.NextDouble() * ProWorld.World.SizeOfTerrain, 0,
                                              (float)r.NextDouble()*ProWorld.World.SizeOfTerrain);
                        var boxIndex = GetRelevantBoxIndex(pos.x, pos.z, ofd);

                        if (CheckCollision(boxIndex, pos.x, pos.z, treeData.Data, tsd, ofd)) continue;

                        //var tree = new Tree(index, treeData.Radius0)
                        var tree = new Tree(treeData.Data)
                                       {
                                           Position = pos
                                       };
                        tsd.Boxes[boxIndex].AddObject(tree);
                        placed++;
                        break;
                    }
                }
            }

            var mapLength = map.GetLength(0);
            var nfactor = mapLength/(float) ProWorld.World.SizeOfTerrain; // size > maplength in general

            // Cleanup
            // Remove trees in water
            // Remove trees in other sections
            foreach (var box in tsd.Boxes)
            {
                for (var index = 0; index < box.Objects.Count; index++)
                {
                    var remove = false;
                    var tree = box.Objects[index];
                    var height = GetHeightAtRoundedPosition(tree.Position.x, tree.Position.z, section);

                    // Check if we are in water
                    if (height < ProWorld.World.WaterLevel)
                    {
                        remove = true;
                    }
                        // If not check if we are in the right region
                    else
                    {
                        var yy = (int) (tree.Position.z*nfactor);
                        var xx = tree.Position.x;

                        var count = 0;
                        var current = false;

                        for (var x = 0; x < xx*nfactor; x++)
                        {
                            if (map[yy, x] != current)
                            {
                                current = !current;
                                count++;
                            }
                        }

                        if (count%2 == 0)
                        {
                            remove = true;
                        }
                    }

                    if (remove)
                    {
                        box.Objects.Remove(tree);
                        index--;
                    }
                }
            }

            //var timeTaken = Time.realtimeSinceStartup - startTime;
            //var total = tsd.Density;
            //Debug.Log(placed + " of " + total + " trees were placed in " + timeTaken + "seconds using " + ofd.NumOfBoxes * ofd.NumOfBoxes + " boxes");
        }

        private static float GetHeightAtRoundedPosition(float x, float y, Section section)
        {
            var ratio = ProWorld.World.SectionHmRes/(float) ProWorld.World.SizeOfTerrain;
            x *= ratio;
            y *= ratio;

            //var xCeil = (int) Mathf.Ceil(x);
            var xFloor = (int) x;
            //var yCeil = (int) Mathf.Ceil(y);
            var yFloor = (int) y;

            //var xRemain = x%xFloor;
            //var yRemain = y%yFloor;

            //var xx = xRemain < 0.5f ? xFloor : xCeil;
            //var yy = yRemain < 0.5f ? yFloor : yCeil;
            var xx = xFloor;
            var yy = yFloor;

            var r = section.SectionHeightMap[yy, xx];
            return r;
        }

        /// <summary>
        /// Function to check if tree collides with any other tree
        /// </summary>
        /// <param name="index">Box index</param>
        /// <param name="x">X position of tree</param>
        /// <param name="y">Y position of tree</param>
        /// <param name="td">Tree data</param>
        /// <param name="tsd">Tree section data</param>
        /// <param name="ofd"> </param>
        /// <returns></returns>
        private static bool CheckCollision(int index, float x, float y, TreeData td, TreeSectionData tsd,
                                           OverflowData ofd)
        {
            // Find the largest radius
            var rad = td.Radius[0] > td.Radius[1] ? 0 : 1;

            // Check box
            if ((from obj in tsd.Boxes[index].Objects
                 let pos = obj.Position
                 where InCircle(pos.x, pos.z, obj.Data.Radius[rad], x, y, td.Radius[rad])
                 select obj
                ).Any())
            {
                return true;
            }

            var overflowArea = GetOverflowBoxes(index, x, y, td.Radius[rad], tsd, ofd);

            // Check overflow areas
            return (from box in overflowArea
                    from obj in box.Objects
                    let pos = obj.Position
                    where InCircle(pos.x, pos.z, obj.Data.Radius[rad], x, y, td.Radius[rad])
                    select obj
                   ).Any();
        }

        private static int GetRelevantBoxIndex(float x, float y, OverflowData ofd)
        {
            var w = Mathf.Clamp((int) (x/ofd.BoxSize), 0, ofd.NumOfBoxes - 1);
                // We clamp on rare case we are exactly at max position
            var h = Mathf.Clamp((int) (y/ofd.BoxSize), 0, ofd.NumOfBoxes - 1);

            return w + h*ofd.NumOfBoxes;
        }

        private static IEnumerable<Box> GetOverflowBoxes(int box, float x, float y, float radius, TreeSectionData tsd,
                                                         OverflowData ofd)
        {
            var overflow = ofd.MaxOverflow + radius;

            // Box index in x/y coords
            var boxX = box%ofd.NumOfBoxes;
            var boxY = box/ofd.NumOfBoxes;

            // Remainder to check if we are overflowing
            var posX = x%ofd.BoxSize;
            var posY = y%ofd.BoxSize;

            var boxes = new List<Box>();
            var newBoxes = BoxPosition.None;

            if (posX < overflow && boxX != 0)
                newBoxes |= BoxPosition.Left;
            if (posX > ofd.BoxSize - overflow && boxX != ofd.NumOfBoxes - 1)
                newBoxes |= BoxPosition.Right;
            if (posY < overflow && boxY != 0)
                newBoxes |= BoxPosition.Down;
            if (posY > ofd.BoxSize - overflow && boxY != ofd.NumOfBoxes - 1)
                newBoxes |= BoxPosition.Up;

            if ((newBoxes & BoxPosition.Left) == BoxPosition.Left)
            {
                boxes.Add(tsd.Boxes[boxX - 1 + boxY*ofd.NumOfBoxes]);
            }
            if ((newBoxes & BoxPosition.Right) == BoxPosition.Right)
            {
                boxes.Add(tsd.Boxes[boxX + 1 + boxY*ofd.NumOfBoxes]);
            }
            if ((newBoxes & BoxPosition.Down) == BoxPosition.Down)
            {
                boxes.Add(tsd.Boxes[boxX + (boxY - 1)*ofd.NumOfBoxes]);
            }
            if ((newBoxes & BoxPosition.Up) == BoxPosition.Up)
            {
                boxes.Add(tsd.Boxes[boxX + (boxY + 1)*ofd.NumOfBoxes]);
            }
            if ((newBoxes & BoxPosition.DownLeft) == BoxPosition.DownLeft)
            {
                boxes.Add(tsd.Boxes[boxX - 1 + (boxY - 1)*ofd.NumOfBoxes]);
            }
            if ((newBoxes & BoxPosition.DownRight) == BoxPosition.DownRight)
            {
                boxes.Add(tsd.Boxes[boxX + 1 + (boxY - 1)*ofd.NumOfBoxes]);
            }
            if ((newBoxes & BoxPosition.UpLeft) == BoxPosition.UpLeft)
            {
                boxes.Add(tsd.Boxes[boxX - 1 + (boxY + 1)*ofd.NumOfBoxes]);
            }
            if ((newBoxes & BoxPosition.UpRight) == BoxPosition.UpRight)
            {
                boxes.Add(tsd.Boxes[boxX + 1 + (boxY + 1)*ofd.NumOfBoxes]);
            }

            return boxes;
        }

        private static bool InCircle(float x1, float y1, float r1, float x2, float y2, float r2)
        {
            var squareDist = Mathf.Pow(x1 - x2, 2) + Mathf.Pow(y1 - y2, 2);
            return squareDist < Mathf.Pow(r1 + r2, 2);
        }



        public override void OnGUI()
        {
            if (_updateTexure)
            {
                UpdateTexture();
            }

            var textureRect = new Rect(0, 0, 0.25f, 0.25f);

            var position = ProWorld.Window.position;

            GUILayout.BeginArea(new Rect(0, 0, 523, 536), "Overall", GUI.skin.window);
            GUILayout.Box(_outputTexture, GUIStyle.none, GUILayout.Width(512), GUILayout.Height(512));
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(523, 0, 523, 536), "Zoom", GUI.skin.window);
            var rect = GUILayoutUtility.GetRect(new GUIContent(), GUIStyle.none, GUILayout.Width(512),
                                                GUILayout.Height(512));

            var pickpos = Event.current.mousePosition;
            var x = Convert.ToInt32(pickpos.x); // -(int)rect.x;
            var y = Convert.ToInt32(pickpos.y); // - (int) rect.y;

            if (rect.Contains(new Vector2(x, y)))
            {
                var xx = x - (int) rect.x;
                var yy = 512 - (y - (int) rect.y);

                var dim = 512f/ProWorld.World.SizeOfTerrain;

                textureRect.x = xx/512f*(1 - dim);
                textureRect.y = yy/512f*(1 - dim);
                textureRect.width = dim;
                textureRect.height = dim;
            }

            if (Event.current.type == EventType.Repaint)
            {
                Graphics.DrawTexture(rect, _outputTexture, textureRect, 0, 0, 0, 0);
            }
            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(position.width - 200, 0, 200, position.height - 130), "Options",
                                GUI.skin.window);
            Options();

            GUILayout.EndArea();

            GUILayout.BeginArea(new Rect(0, position.height - 130, position.width, 110), "Trees", GUI.skin.window);
            TreeBar();
            GUILayout.EndArea();
        }

        private void Options()
        {
            GUILayout.Label("Density");
            GUILayout.BeginHorizontal();
            _tsd.Density = (int) MyGUI.LogSlider(_tsd.Density, 0, 5);
            GUILayout.Label(_tsd.Density.ToString(CultureInfo.InvariantCulture), GUILayout.Width(50));
            GUILayout.EndHorizontal();

            GUILayout.Label("Seed");
            GUILayout.BeginHorizontal();
            _tsd.Seed = MyGUI.RoundSlider(_tsd.Seed, 0, 50);
            GUILayout.Label(_tsd.Seed.ToString(CultureInfo.InvariantCulture), GUILayout.Width(50));
            GUILayout.EndHorizontal();

            if (GUILayout.Button("Generate"))
            {
                GenerateTrees(_section, _index);
                _bw.CancelAsync();
                _bw.RunWorkerAsync(_tsd);
            }

            _activeScroll = GUILayout.BeginScrollView(_activeScroll);

            for (int index = 0; index < _tsd.Trees.Count; index++)
            {
                var t = _tsd.Trees[index];

#if UNITY_4_0
                var text = t.Data.Prefab ? AssetPreview.GetAssetPreview(t.Data.Prefab) : Util.White;
#else
                var text = t.Data.Prefab ? EditorUtility.GetAssetPreview(t.Data.Prefab) : Util.White;
#endif

                GUILayout.BeginHorizontal();
                GUILayout.Box(text, GUILayout.Width(64), GUILayout.Height(64));

                GUILayout.BeginVertical();

                GUILayout.BeginHorizontal();
                GUILayout.Label("Density");
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("X"))
                {
                    _tsd.Trees.Remove(t);
                    index--;
                }
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                t.Density = MyGUI.LogSlider(t.Density, -1, 1);
                GUILayout.Label(t.Density.ToString("0.00"), GUILayout.Width(40));
                GUILayout.EndHorizontal();


                GUILayout.EndVertical();
                GUILayout.EndHorizontal();
            }

            GUILayout.EndScrollView();
        }

        private void TreeBar()
        {
            var style = new GUIStyle(GUIStyle.none)
                            {stretchHeight = true, stretchWidth = true, margin = new RectOffset(2, 2, 2, 2)};

            _treeScroll = GUILayout.BeginScrollView(_treeScroll); // Begin Scroll
            GUILayout.BeginHorizontal(); // Begin Hor 2

            var trees = ProWorld.World.Trees;

            foreach (var t in trees)
            {
                // Check if tree is in scene already
                var enabled = _tsd.Trees.All(tree => tree.Data != t);

                if (enabled)
                {
#if UNITY_4_0
                    var text = t.Prefab ? AssetPreview.GetAssetPreview(t.Prefab) : Util.White;
#else
                    var text = t.Prefab ? EditorUtility.GetAssetPreview(t.Prefab) : Util.White;
#endif
                    if (GUILayout.Button(text, style, GUILayout.Width(64), GUILayout.Height(64)))
                    {
                        _tsd.Trees.Add(new Tree(t));
                    }
                }
            }
            GUILayout.EndHorizontal(); // End Hor 2
            GUILayout.EndScrollView(); // End Scroll
        }

        public override void Apply()
        {
            var selection = Selection.activeGameObject;
            if (!selection) return;
            var terrain = selection.GetComponent<Terrain>();
            if (!terrain) return;

            var terrainData = terrain.terrainData;

            //var time = DateTime.Now;

            var trees = ProWorld.World.Trees;
            var tps = new TreePrototype[trees.Count];

            for (var i = 0; i < trees.Count; i++)
            {
                tps[i] = new TreePrototype
                             {
                                 prefab = trees[i].Prefab
                             };
            }

            terrainData.treePrototypes = tps;
            terrainData.RefreshPrototypes();

            // Clear any previous trees
            terrainData.treeInstances = new TreeInstance[0];

            foreach (var box in _tsd.Boxes)
            {
                foreach (var tree in box.Objects)
                {
                    var position = tree.Position;
                    position /= terrainData.size.x;
                    position.y = 0.5f;

                    var index = trees.FindIndex(t => t == tree.Data);

                    var ti = new TreeInstance
                                 {
                                     color = new Color(0.973f, 0.973f, 0.973f, 1.000f),
                                     heightScale = 1,
                                     lightmapColor = new Color(1.000f, 1.000f, 1.000f, 1.000f),
                                     widthScale = 1,
                                     position = position,
                                     prototypeIndex = index
                                 };

                    terrain.AddTreeInstance(ti);
                }
            }

            //Debug.Log("Took " + (DateTime.Now - time).TotalSeconds + " seconds to place trees");
        }

        public override void Refresh()
        {
            UpdateTexture();
        }

        public static void CalculateTexture(object sender, DoWorkEventArgs e)
        {
            var tsd = (TreeSectionData) e.Argument;
            var size = ProWorld.World.SizeOfTerrain;

            tsd.ColorOutput = new int[size, size];

            var trees = ProWorld.World.Trees;

            foreach (var box in tsd.Boxes)
            {
                foreach (var tree in box.Objects)
                {
                    var index = trees.FindIndex(t => t == tree.Data);

                    var x = (int) tree.Position.x;
                    var y = (int) tree.Position.z;
                    var r = (int) Mathf.Max(tree.Data.Radius[0], tree.Data.Radius[1], 1);

                    for (var j = y - r; j <= y + r; j++)
                    {
                        if (j >= 0 && j < ProWorld.World.SizeOfTerrain)
                        {
                            for (var i = x - r; i <= x + r; i++)
                            {
                                if (i >= 0 && i < ProWorld.World.SizeOfTerrain)
                                {
                                    tsd.ColorOutput[j, i] = GetColor(index);
                                }
                            }
                        }
                    }
                }
            }

            // Remove edges
            for (var i = 0; i < size; i++)
            {
                tsd.ColorOutput[0, i] = 0;
                tsd.ColorOutput[i, 0] = 0;
                tsd.ColorOutput[size - 1, i] = 0;
                tsd.ColorOutput[i, size - 1] = 0;
            }

            //var smooth = (int) Mathf.Clamp(8.970827136f*Mathf.Pow(1.00114602f, tsd.Density), 10, 50);
            //tsd.ColorOutput = Smooth.SmoothColor(tsd.ColorOutput, smooth);

            //StretchIgnore(ref tsd.ColorOutput);
        }

        public void DoneCalculatingTexture(object sender, RunWorkerCompletedEventArgs e)
        {
            _updateTexure = true;
        }

        private void UpdateTexture()
        {
#if !A
            Util.ApplyIntMapToTexture(_outputTexture, _tsd.ColorOutput);
#endif

            //_outputTexture.SetPixels(_tsd.ColorOutput);
            //_outputTexture.Apply();
            _updateTexure = false;
        }

        private static void StretchIgnore(ref int[,] a)
        {
            var y = a.GetLength(0);
            var x = a.GetLength(1);

            var max = int.MinValue;
            for (var j = 0; j < y; j++)
            {
                for (var i = 0; i < x; i++)
                {
                    var c = a[j, i];

                    var r = (c & 0xff0000) >> 16;
                    var g = (c & 0x00ff00) >> 8;
                    var b = (c & 0x0000ff);

                    var tempMax = Mathf.Max(r, g, b);

                    if (tempMax > max) max = tempMax;
                }
            }

            var mul = 255 / max;

            for (var j = 0; j < y; j++)
            {
                for (var i = 0; i < x; i++)
                {
                    var r = (a[j, i] & 0xff0000) >> 16;
                    var g = (a[j, i] & 0x00ff00) >> 8;
                    var b = (a[j, i] & 0x0000ff);

                    a[j, i] = (r * mul) << 16 | (g * mul) << 8 | (b*mul);
                }
            }
        }


        public override void Clean()
        {
            UnityEngine.Object.DestroyImmediate(_outputTexture);
        }
        private static int GetColor(int index)
        {
            switch (index)
            {
                case 0:
                    return 255 << 16;
                case 1:
                    return 255 << 8;
                case 2:
                    return 255;
                default:
                    return 255 << 8;
            }
        }
    }

    [Serializable]
    public class Box : ISerializable, IClean
    {
        public List<Tree> Objects = new List<Tree>();

        public Box()
        {

        }

        public void AddObject(Tree go)
        {
            Objects.Add(go);
        }

        public Box(SerializationInfo info, StreamingContext context)
        {
            Objects = (List<Tree>) info.GetValue("Objects", typeof (List<Tree>));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Objects", Objects);
        }

        public void Clean()
        {
            Objects = null;
        }
    }
}