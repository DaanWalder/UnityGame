﻿using ProWorldEditor;
using UnityEditor;
using UnityEngine;

public class TreeDataProperties : ScriptableWizard
{
    public TreeData TreeOld;
    public TreeData TreeNew;
    //private bool _close;

    public static void CreateTDP(TreeData treeData)
    {
        var tdp = DisplayWizard<TreeDataProperties>("Create Tree", "Apply");
        tdp.TreeOld = treeData;
        tdp.TreeNew = new TreeData(treeData);
    }

    private void Update()
    {
        if (EditorApplication.isCompiling)
            Close();
    }

    private void OnGUI()
    {
        TreeNew.Prefab =
            EditorGUILayout.ObjectField("Splat", TreeNew.Prefab, typeof (GameObject), false) as GameObject;
        TreeNew.Radius[0] = EditorGUILayout.FloatField("Trunk/Shrub Radius", TreeNew.Radius[0]);
        TreeNew.Radius[1] = EditorGUILayout.FloatField("Canopy Radius", TreeNew.Radius[1]);

        if (TreeNew.Radius[0] >= TreeNew.Radius[1])
            TreeNew.Radius[1] = 0;

        GUILayout.FlexibleSpace();

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Remove"))
        {
            var trees = ProWorld.World.Trees;
            var count = trees.Count;
            if (count != 1)
                trees.Remove(TreeOld);
            else // don't want to drop below 1 so we just clear it 
                trees[0] = new TreeData();

            Close();
        }
        GUILayout.FlexibleSpace();
        if (GUILayout.Button("Apply"))
        {
            TreeOld.Prefab = TreeNew.Prefab;
            TreeOld.Radius[0] = TreeNew.Radius[0];
            TreeOld.Radius[1] = TreeNew.Radius[1];

            Close();
        }
        GUILayout.EndHorizontal();
    }

    private void OnLostFocus()
    {
        // Can't close in here as it throws an error
        // WindowLayouts are invalid. Please use 'Window -> Layouts -> Revert Factory Settings...' menu to fix it.
        //_close = true;
    }
}