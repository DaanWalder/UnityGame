using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace ProWorldEditor
{
    [Serializable]
    public sealed class Save : ISerializable
    {
        public List<Node> Nodes = new List<Node>();

        public Save(IEnumerable<Node> nodes)
        {
            Nodes = new List<Node>(nodes);
        }

        #region ISerializable Fields

        private Save(SerializationInfo info, StreamingContext context)
        {
            Nodes = (List<Node>) info.GetValue("Nodes", typeof (List<Node>));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Nodes", Nodes);
        }

        #endregion

        public static void SerializeObject(string filename, Save save)
        {
            Stream stream = File.Open(filename, FileMode.Create);
            var bFormatter = new BinaryFormatter();
            bFormatter.Serialize(stream, save);
            stream.Close();
        }

        public static Save DeSerializeObject(string filename)
        {
            Stream stream = File.Open(filename, FileMode.Open);
            var bFormatter = new BinaryFormatter();
            var save = (Save) bFormatter.Deserialize(stream);
            stream.Close();
            return save;
        }
    }
}