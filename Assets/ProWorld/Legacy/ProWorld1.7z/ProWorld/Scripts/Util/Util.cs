﻿using System;
using System.IO;
using UnityEngine;

namespace ProWorldSDK
{
    public static class Util
    {
        public static Texture2D White;

        public static void ApplyMapToTexture(ref Texture2D texture, float[,] color)
        {
            // Much more efficient to use SetPixels than loop through and SetPixel 
            if (color == null)
                throw new UnityException("Color data is empty");

            if (!texture)
                throw new UnityException("Texture doesn't exist");

            var width = color.GetLength(1);
            var height = color.GetLength(0);

            var colors = new Color[width*height];
            for (var y = 0; y < height; y++)
            {
                for (var x = 0; x < width; x++)
                {
                    var c = color[y, x];
                    colors[y*width + x] = new Color(c, c, c);
                }
            }

            try
            {
                texture.SetPixels(colors);
                texture.Apply();
            }
            catch (Exception e)
            {
                Debug.Log(e);
            }
        }

        public static void ApplyBoolMapToTexture(Texture2D texture, bool[,] data)
        {
            // Much more efficient to use SetPixels than loop through and SetPixel 
            if (data == null)
                throw new UnityException("Data is empty");

            var width = data.GetLength(1);
            var height = data.GetLength(0);

            var colors = new Color[width*height];
            for (var y = 0; y < height; y++)
            {
                for (var x = 0; x < width; x++)
                {
                    var c = data[y, x] ? 1 : 0;
                    colors[y*width + x] = new Color(c, c, c);
                }
            }

            if (!texture)
            {
                texture = new Texture2D(width, height);
            }

            try
            {
                texture.SetPixels(colors);
                texture.Apply();
            }
            catch (Exception e)
            {
                Debug.Log(e);
            }
        }

        public static bool[,] GrayToBlackWhite(float[,] data)
        {
            var size = data.GetLength(0);

            var b = new bool[size,size];

            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var d = data[y, x];

                    b[y, x] = d >= 0.5f;
                }
            }

            return b;
        }

        public static Texture2D BlackTexture(int size)
        {
            var texture = new Texture2D(size, size);
            var colors = new Color[size*size];

            for (var j = 0; j < size; j++)
            {
                for (var i = 0; i < size; i++)
                {
                    colors[j*size + i] = Color.black;
                }
            }

            texture.SetPixels(colors);
            texture.Apply();

            return texture;
        }

        /*public static Texture2D WhiteTexture(int size)
        {
            var texture = new Texture2D(size, size);
            var colors = new Color[size * size];

            for (var j = 0; j < size; j++)
            {
                for (var i = 0; i < size; i++)
                {
                    colors[j * size + i] = Color.white;
                }
            }

            texture.SetPixels(colors);
            texture.Apply();

            return texture;
        }*/

        public static T[,] SetArrayValue<T>(int size, T val)
        {
            var array = new T[size,size];

            for (var j = 0; j < size; j++)
            {
                for (var i = 0; i < size; i++)
                {
                    array[j, i] = val;
                }
            }

            return array;
        }

        // Based off work by http://www.codeproject.com/Articles/2122/Image-Processing-for-Dummies-with-C-and-GDI-Part-4
        public static T[,] ResizeArray<T>(T[,] oldArray, int size)
        {
            var oldSizeX = oldArray.GetLength(1);
            var oldSizeY = oldArray.GetLength(0);

            //if (size > oldSize) return oldArray; // no need to scale up

            var newArray = new T[size,size];
            var xFactor = oldSizeX/(float) size;
            var yFactor = oldSizeY/(float) size;

            for (var x = 0; x < size; ++x)
                for (var y = 0; y < size; ++y)
                {
                    newArray[y, x] = oldArray[(int) Math.Floor(y*yFactor), (int) Math.Floor(x*xFactor)];
                }

            return newArray;
        }

        public static T[] ResizeArray<T>(T[] oldArray, int size)
        {
            if (oldArray.Length == 0)
                return new T[size*size];

            var dim = Mathf.Sqrt(oldArray.Length);
            if (Math.Abs(oldArray.Length%dim) > float.Epsilon)
            {
                throw new UnityException("Array isn't square");
            }
            var oldSize = (int) dim;

            //if (size > oldSize) return oldArray; // no need to scale up

            var newArray = new T[size*size];
            var nFactor = oldSize/(float) size;

            for (var x = 0; x < size; ++x)
                for (var y = 0; y < size; ++y)
                {
                    newArray[y*size + x] = oldArray[(int) Math.Floor(y*nFactor)*oldSize + (int) Math.Floor(x*nFactor)];
                }

            return newArray;
        }

        public static T[] MultiToArray<T>(T[,] oldArray)
        {
            var width = oldArray.GetLength(1);
            var height = oldArray.GetLength(0);

            var output = new T[width*height];

            for (var j = 0; j < height; j++)
            {
                for (var i = 0; i < width; i++)
                {
                    output[j*width + i] = oldArray[j, i];
                }
            }

            return output;
        }

        public static T[,] ArrayToMulti<T>(T[] oldArray, int width, int height)
        {
            var output = new T[width,height];

            for (var j = 0; j < height; j++)
            {
                for (var i = 0; i < width; i++)
                {
                    output[j, i] = oldArray[j*width + i];
                }
            }

            return output;
        }

        public static bool PointInMask(Vector2 point, float[,] mask)
        {
            var x = Mathf.RoundToInt(point.x);
            var y = Mathf.RoundToInt(point.y);
            var width = mask.GetLength(1);

            var last = false;
            var count = 0;

            for (var xx = 0; xx < width; xx++)
            {
                if (xx > x)
                    break;

                var m = mask[y, xx] > 0.5f;

                if (m != last)
                {
                    last = m;
                    count++;
                }
            }

            return count%2 != 0;
        }

        public static float[,] ConvertToGrayscale(Texture2D texture)
        {
            if (!texture) return new float[1,1];

            var width = texture.width;
            var height = texture.height;

            var colors = texture.GetPixels();

            var gray = new float[height,width];

            for (var y = 0; y < height; y++)
            {
                for (var x = 0; x < width; x++)
                {
                    gray[y, x] = colors[y*width + x].grayscale;
                }
            }

            return gray;
        }

        public static bool[,] ConvertToBlackWhite(Texture2D texture)
        {
            if (!texture) return new bool[1,1];

            var width = texture.width;
            var height = texture.height;

            var colors = texture.GetPixels();

            var bw = new bool[height,width];

            for (var y = 0; y < height; y++)
            {
                for (var x = 0; x < width; x++)
                {
                    var gray = colors[y*width + x].grayscale;

                    bw[y, x] = gray >= 0.5f;
                }
            }

            return bw;
        }

        public static bool[,] AndArrays(bool[,] array1, bool[,] array2)
        {
            if (array1.GetLength(0) != array2.GetLength(0) || array1.GetLength(1) != array2.GetLength(1))
                throw new UnityException("Array sizes don't match");

            var width = array1.GetLength(1);
            var height = array1.GetLength(0);

            var array0 = new bool[height,width];

            for (var y = 0; y < height; y++)
            {
                for (var x = 0; x < width; x++)
                {
                    array0[y, x] = array1[y, x] && array2[y, x];
                }
            }

            return array0;
        }

        public static bool[,] FloatToBoolArray(float[,] data)
        {
            var width = data.GetLength(1);
            var height = data.GetLength(0);

            var b = new bool[height,width];

            for (var y = 0; y < height; y++)
            {
                for (var x = 0; x < width; x++)
                {
                    b[y, x] = data[y, x] >= 0.5f;
                }
            }

            return b;
        }

        public static float[,] BoolToFloat(bool[,] data)
        {
            var width = data.GetLength(1);
            var height = data.GetLength(0);

            var f = new float[height,width];

            for (var y = 0; y < height; y++)
            {
                for (var x = 0; x < width; x++)
                {
                    f[y, x] = data[y, x] ? 1f : 0f;
                }
            }

            return f;
        }

        public static int UpperPowerOfTwo(int v)
        {
            v--;
            v |= v >> 1;
            v |= v >> 2;
            v |= v >> 4;
            v |= v >> 8;
            v |= v >> 16;
            v++;
            return v;

        }
    }
}