﻿using System.IO;
using UnityEngine;

namespace ProWorldSDK
{
    internal class FileOperations
    {
        public static void SaveImage(float[,] data, string path)
        {
            var height = data.GetLength(0);
            var width = data.GetLength(1);

            var texture = new Texture2D(width, height);
            Util.ApplyMapToTexture(ref texture, data);

            var bytes = texture.EncodeToPNG();
            var file = File.Open(path, FileMode.Create);
            var binary = new BinaryWriter(file);
            binary.Write(bytes);
            file.Close();

            Object.DestroyImmediate(texture);
        }
        public static void SaveImage(Color[,] data, string path)
        {
            var height = data.GetLength(0);
            var width = data.GetLength(1);

            var texture = new Texture2D(width, height);

            var d = new Color[height * width];

            for (var y = 0; y < height; y++)
            {
                for (var x = 0; y < height; x++)
                {
                    d[y * width + x] = data[y, x];
                }
            }

            texture.SetPixels(d);
            texture.Apply();

            var bytes = texture.EncodeToPNG();
            var file = File.Open(path, FileMode.Create);
            var binary = new BinaryWriter(file);
            binary.Write(bytes);
            file.Close();

            Object.DestroyImmediate(texture);
        }
    }
}