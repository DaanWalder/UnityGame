using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace ProWorldSDK
{
    [Serializable]
    public abstract class NodeData : IDeserializationCallback 
    {
        public Link[] InputConnections; // each input is limted to 1 source
        [NonSerialized] public float[][,] InputData;

        public List<Link> OutputConnections = new List<Link>(); // 1 output can go to many inputs
        [NonSerialized] public float[,] OutputData;

        public static implicit operator bool(NodeData exists)
        {
            return exists != null;
        }

        public abstract void Calculate(int resolution, float offsetX, float offsetY);

        protected void SetInput(int i)
        {
            InputConnections = new Link[i];
            InputData = new float[i][,];
        }

        public void OnDeserialization(object sender)
        {
            InputData = new float[InputConnections.Length][,];
        }
    }

    [Serializable]
    public class Link
    {
        public NodeData To;
        public int ToIndex;

        public NodeData From;

        public static implicit operator bool(Link exists)
        {
            return exists != null;
        }

        public Link()
        {
            
        }
        public Link(NodeData from, NodeData to, int toIndex)
        {
            To = to;
            ToIndex = toIndex;
            From = from;
        }
    }
}