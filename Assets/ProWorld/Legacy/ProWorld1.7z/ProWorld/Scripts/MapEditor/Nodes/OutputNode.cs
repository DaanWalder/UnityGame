﻿using System;

namespace ProWorldSDK
{
    [Serializable]
    public class OutputNode : NodeData
    {
        public OutputNode()
        {
            SetInput(1);
        }
        public override void Calculate(int resolution, float offsetX, float offsetY)
        {
            if (!InputConnections[0]) return;

            InputData[0] = InputConnections[0].From.OutputData;
            OutputData = InputData[0];
        }
    }
}
