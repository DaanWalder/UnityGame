﻿using System;
using UnityEngine;

namespace ProWorldSDK
{
    [Serializable]
    public class AddNode : NodeData
    {
        public Combination.Morph Morph = Combination.Morph.Shift;

        public AddNode()
        {
            SetInput(2);
        }

        public override void Calculate(int resolution, float offsetX, float offsetY)
        {
            for (var i = 0; i < InputConnections.Length; i++)
            {
                if (!InputConnections[i]) return;
                InputData[i] = InputConnections[i].From.OutputData;
            }

            OutputData = Combination.Add(InputData[0], InputData[1], Morph);
        }
    }
}
