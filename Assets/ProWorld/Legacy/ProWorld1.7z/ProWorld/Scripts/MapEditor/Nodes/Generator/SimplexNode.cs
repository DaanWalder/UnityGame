﻿using System;
using UnityEngine;

namespace ProWorldSDK
{
    [Serializable]
    class SimplexNode : NodeData
    {
        public enum OutputMorph
        {
            Shift,
            Clamp,
            Abs
        }

        public SimplexNoise Sn = new SimplexNoise();
        public float Range = 1;
        public OutputMorph Morph = OutputMorph.Shift;

        public SimplexNode()
        {
            SetInput(0);
        }

        public override void Calculate(int resolution, float offsetX, float offsetY)
        {
            OutputData = new float[resolution, resolution];

            // We calc 1 extra position if stitching
            var nFactor = (resolution + 1) / (float)resolution;

            var oX = offsetX * Range;
            var oY = offsetY * Range;

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    OutputData[y, x] = (float)Sn.Noise((x / (float)resolution * Range) * nFactor + oX, (y / (float)resolution * Range) * nFactor + oY);

                    switch (Morph)
                    {
                        case OutputMorph.Shift:
                            OutputData[y, x] = Mathf.Clamp01(OutputData[y, x] * 0.5f + 0.5f);
                            break;
                        case OutputMorph.Clamp:
                            OutputData[y, x] = Mathf.Clamp01(OutputData[y, x]);
                            break;
                        case OutputMorph.Abs:
                            OutputData[y, x] = Mathf.Abs(OutputData[y, x]);
                            break;
                    }
                }
            }
        }
    }
}
