using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

namespace ProWorldSDK
{
    public delegate float[,] MapFunction(int offsetX = 0, int offsetY = 0);

    [Serializable]
    public class MapManager
    {
        public List<NodeData> Nodes = new List<NodeData>();
        public OutputNode OutputNode = new OutputNode();

        public int Resolution;

        [NonSerialized] private Link _lastLink;

        public MapManager(int resolution)
        {
            Resolution = resolution;
        }

        private MapManager DeepClone()
        {
            lock (this)
            {
                using (var ms = new MemoryStream())
                {
                    var formatter = new BinaryFormatter();
                    formatter.Serialize(ms, this);
                    ms.Position = 0;

                    return (MapManager) formatter.Deserialize(ms);
                }
            }
        }

        public bool LinkNodes(NodeData from, NodeData to, int index)
        {
            if (from != to)
            {
                _lastLink = new Link(from, to, index);

                from.OutputConnections.Add(_lastLink);
                if (index >= to.InputConnections.Length)
                    throw new UnityException("Input doesn't exist");
                to.InputConnections[index] = _lastLink;

                // TODO CHECK INFINITE LOOP
                /*
                // Check if the link causes an infinite loop
                if (CheckInfiniteLoop(_currentOutputNode.Data))
                {
                    _currentInputNode.DoWork();
                }
                else
                {
                    RemoveLastLink();
                }*/
                return true;
            }

            return false;
        }

        // Run this in alternate thread
        public float[,] GetArea(int offsetX = 0, int offsetY = 0)
        {
            var map = DeepClone();
            var stack = map.Rebuild();

            while (stack.Count > 0)
            {
                var nodes = stack.Pop();
                foreach(var node in nodes)
                {
                    node.Calculate(Resolution, offsetX, offsetY);
                }
            }

            return map.OutputNode.OutputData;
        }

        private Stack<List<NodeData>> Rebuild()
        {
            var stack = new Stack<List<NodeData>>();

            var output = new List<NodeData> { OutputNode };
            stack.Push(output);

            var data = FindConnections(output).ToList();

            while (data.Count != 0)
            {
                var tmp = new List<NodeData>();

                foreach (var d in data)
                {
                    var push = true;

                    foreach (var list in stack)
                    {
                        if (list.Contains(d))
                        {
                            push = false;
                            break;
                        }
                    }

                    if (push)
                        tmp.Add(d);
                }
                stack.Push(tmp);

                data = FindConnections(tmp).ToList();
            }

            return stack;
        }
        private static IEnumerable<NodeData> FindConnections(IEnumerable<NodeData> nodes)
        {
            var newNodes = new HashSet<NodeData>();

            foreach (var node in nodes)
            {
                foreach (var input in node.InputConnections)
                {
                    // Check if an input is connected
                    if (input)
                        newNodes.Add(input.From);
                }
            }

            return newNodes;
        }
    }
}