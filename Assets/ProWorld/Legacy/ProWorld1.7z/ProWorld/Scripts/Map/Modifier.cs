﻿using System;

namespace ProWorldSDK
{
	public static class Modifier
	{
        public static float[,] Invert(float[,] a)
        {
            var y = a.GetLength(0);
            var x = a.GetLength(1);

            var b = new float[y,x];

            for (var j = 0; j < y; j++)
            {
                for (var i = 0; i < x; i++)
                {
                    b[j, i] = 1 - a[j, i];
                }
            }

            return b;
        }

        public static float[,] Cutoff(float[,] a, float min, float max)
        {
            var y = a.GetLength(0);
            var x = a.GetLength(1);

            var b = new float[y, x];

            for (var j = 0; j < y; j++)
            {
                for (var i = 0; i < x; i++)
                {
                    b[j, i] = Math.Min(a[j, i], max);
                    b[j, i] = Math.Max(b[j, i], min);
                }
            }

            return b;
        }

        public static float[,] Stretch(float[,] a, float from, float to)
        {
            var y = a.GetLength(0);
            var x = a.GetLength(1);

            var b = new float[y, x];

            var min = float.PositiveInfinity;
            var max = float.NegativeInfinity;

            for (var j = 0; j < y; j++)
            {
                for (var i = 0; i < x; i++)
                {
                    if (a[j, i] > max) max = a[j, i];
                    if (a[j, i] < min) min = a[j, i];
                }
            }

            var dif = max - min;
            var newDif = to - from;

            for (var j = 0; j < y; j++)
            {
                for (var i = 0; i < x; i++)
                {
                    b[j, i] = ((a[j, i] - min) / dif) * newDif + from;
                }
            }

            return b;
        }
	}


}
