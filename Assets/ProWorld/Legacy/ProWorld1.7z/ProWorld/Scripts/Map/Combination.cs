﻿using System;

namespace ProWorldSDK
{
	public static class Combination
	{
        public enum Morph
        {
            Shift,
            Clamp
        }

        public static float[,] Add(float[,] a, float[,] b, Morph morph)
        {
            var y = a.GetLength(0);
            var x = a.GetLength(1);

            if (b.GetLength(0) != y || b.GetLength(1) != x)
                throw new Exception("ARray sizes don't match");

            var c = new float[y, x];

            for (var j = 0; j < y; j++)
            {
                for (var i = 0; i < x; i++)
                {
                    c[j, i] = a[j, i] + b[j, i];

                    switch (morph)
                    {
                        case Morph.Shift:
                            c[j, i] /= 2f;
                            break;
                        case Morph.Clamp:
                            c[j, i] = Math.Min(c[j, i], 1);
                            break;
                    }
                }
            }

            return c;
        }

        public static float[,] Sub(float[,] a, float[,] b, Morph morph)
        {
            var y = a.GetLength(0);
            var x = a.GetLength(1);

            if (b.GetLength(0) != y || b.GetLength(1) != x)
                throw new Exception("ARray sizes don't match");

            var c = new float[y, x];

            for (var j = 0; j < y; j++)
            {
                for (var i = 0; i < x; i++)
                {
                    c[j, i] = a[j, i] - b[j, i];

                    switch (morph)
                    {
                        case Morph.Shift:
                            c[j, i] = c[j, i] * 0.5f + 0.5f;
                            break;
                        case Morph.Clamp:
                            c[j, i] = Math.Max(c[j, i], 0);
                            break;
                    }
                }
            }

            return c;
        }

        public static float[,] Mul(float[,] a, float[,] b)
        {
            var y = a.GetLength(0);
            var x = a.GetLength(1);

            if (b.GetLength(0) != y || b.GetLength(1) != x)
                throw new Exception("ARray sizes don't match");

            var c = new float[y, x];

            for (var j = 0; j < y; j++)
            {
                for (var i = 0; i < x; i++)
                {
                    c[j, i] = a[j, i] * b[j, i];
                }
            }

            return c;
        }

        public static float[,] Div(float[,] a, float[,] b)
        {
            var y = a.GetLength(0);
            var x = a.GetLength(1);

            if (b.GetLength(0) != y || b.GetLength(1) != x)
                throw new Exception("ARray sizes don't match");

            var c = new float[y, x];

            for (var j = 0; j < y; j++)
            {
                for (var i = 0; i < x; i++)
                {
                    c[j, i] = a[j, i] / b[j, i];
                    c[j, i] = Math.Min(c[j, i], 1);
                }
            }

            return c;

        }
	}
}
