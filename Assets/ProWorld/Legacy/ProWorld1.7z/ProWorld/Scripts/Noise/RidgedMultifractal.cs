﻿// Based off java version by 
// http://www.hayles.demon.co.uk/perlin/ridgedmf.html

using System;
using System.Runtime.Serialization;

namespace ProWorldSDK
{
    [Serializable]
    public class RidgedMultifractal : ISerializable
    {
        public float Lacunarity = 1;
        public float Gain = 1;
        public float Offset = 1;
        public int NumberOfOctaves = 3;
        public float HScale = 0.5f;
        public float VScale = 0.666666667f;

        private readonly SimplexNoise _sn = new SimplexNoise();

        public float Noise(double x, double z)
        {
            var sum = 0.0;
            var amplitude = 0.5f;
            var frequency = 1.0f;
            var prev = 1.0;
            var octaves = NumberOfOctaves;

            x *= HScale;
            z *= HScale;

            for (var i = 0; i < octaves; i++)
            {
                var n = Ridge(InterpolatedNoise((float) (x*frequency), (float) (z*frequency)), Offset);
                sum += n*amplitude*prev;
                prev = n;
                frequency *= Lacunarity;
                amplitude *= Gain;
            }

            return (float) -sum*VScale;
        }

        private static double Ridge(double h, float offset)
        {
            h = Math.Abs(h);
            h = offset - h;
            h = h*h;
            return h;
        }

        private float GetNoise(int x, int y)
        {
            var n = x + y*57;
            n = (n << 13) ^ n;
            return (1.0f - ((n*(n*n*15731 + 789221) + 1376312589) & 0x7fffffff)/1073741824f);
        }

        private float InterpolatedNoise(float x, float y)
        {
            var integerX = (int) x;
            var fractionalX = x - integerX;

            var integerY = (int) y;
            var fractionalY = y - integerY;

            var v1 = GetNoise(integerX, integerY);
            var v2 = GetNoise(integerX + 1, integerY);
            var v3 = GetNoise(integerX, integerY + 1);
            var v4 = GetNoise(integerX + 1, integerY + 1);

            var i1 = Interpolate(v1, v2, fractionalX);
            var i2 = Interpolate(v3, v4, fractionalX);

            return Interpolate(i1, i2, fractionalY);
        }

        private static float Interpolate(float a, float b, float x)
        {
            var ft = x*3.1415927f;
            var f = (float) ((1 - Math.Cos(ft))*0.5f);
            return a*(1 - f) + b*f;
        }

        public RidgedMultifractal()
        {

        }

        public RidgedMultifractal(SerializationInfo info, StreamingContext context)
        {
            Lacunarity = (float) info.GetValue("Lacunarity", typeof (float));
            Gain = (float) info.GetValue("Gain", typeof (float));
            Offset = (float) info.GetValue("Offset", typeof (float));
            NumberOfOctaves = info.GetInt32("NumberOfOctaves");
            HScale = (float) info.GetValue("HScale", typeof (float));
            VScale = (float) info.GetValue("VScale", typeof (float));
            _sn = new SimplexNoise(info.GetInt32("Seed"));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Lacunarity", Lacunarity);
            info.AddValue("Gain", Gain);
            info.AddValue("Offset", Offset);
            info.AddValue("NumberOfOctaves", NumberOfOctaves);
            info.AddValue("HScale", HScale);
            info.AddValue("VScale", VScale);
            info.AddValue("Seed", _sn.Seed);
        }
    }
}