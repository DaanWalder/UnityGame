﻿using System;
using System.Runtime.Serialization;
using UnityEngine;

namespace ProWorldSDK
{
    public enum OutputMorph
    {
        Shift,
        Clamp,
        Abs
    }

    [Serializable]
    public class FractalBrownianMotion : ISerializable
    {
        private SimplexNoise _simplex;

        public float H = 2;
        public int Octaves = 8;
        public float Gain = 0.5f;
        public float Lacunarity = 2.0f;

        public OutputMorph Morph = OutputMorph.Shift;

        private bool _stitch;

        //public delegate float NoiseDelegate(float x, float y);

        public FractalBrownianMotion()
            : this(0) { }
        public FractalBrownianMotion(int seed)
        {
            _simplex = new SimplexNoise(seed);
        }

        /*public float[,] GetArea(int resolution, float range, int offsetX = 0, int offsetY = 0, bool stitch = true)
        {
            var data = new float[resolution, resolution];

            // We calc 1 extra position if stitching
            var nFactor = stitch ? (resolution + 1)/(float)resolution : 1;

            var oX = offsetX * range;
            var oY = offsetY * range;

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    data[y, x] = Noise((x / (float)resolution * range) * nFactor + oX, (y / (float)resolution * range) * nFactor + oY);

                    switch (Morph)
                    {
                        case OutputMorph.Shift:
                            data[y, x] = Mathf.Clamp01(data[y, x] * 0.5f + 0.5f);
                            break;
                        case OutputMorph.Clamp:
                            data[y, x] = Mathf.Clamp01(data[y, x]);
                            break;
                        case OutputMorph.Abs:
                            data[y, x] = Mathf.Abs(data[y, x]);
                            break;
                    }
                }
            }
            return data;
        }*/

        public void SetSeed(int seed)
        {
            _simplex = new SimplexNoise(seed);
        }

        public float Noise(float x, float y)
        {
            var total = 0.0f;
            var frequency = 1.0f / H;
            var amplitude = Gain;

            for (var k = 0; k < Octaves; ++k)
            {
                total += (float)_simplex.Noise(x * frequency, y * frequency) * amplitude;
                frequency *= Lacunarity;
                amplitude *= Gain;
            }

            return total;
        }

        public FractalBrownianMotion(SerializationInfo info, StreamingContext context)
        {
            H = (float) info.GetValue("H", typeof (float));
            Octaves = info.GetInt32("Octaves");
            Gain = (float)info.GetValue("Gain", typeof(float));
            Lacunarity = (float)info.GetValue("Lacunarity", typeof(float));
            _simplex = new SimplexNoise(info.GetInt32("Seed"));
        }

        public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("H", H);
            info.AddValue("Octaves", Octaves);
            info.AddValue("Gain", Gain);
            info.AddValue("Lacunarity", Lacunarity);
            info.AddValue("Seed", _simplex.Seed);
        }
    }
}